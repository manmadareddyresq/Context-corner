import type { Config } from 'tailwindcss'

const config: Config = {
  content: [
    './pages/**/*.{js,ts,jsx,tsx,mdx}',
    './components/**/*.{js,ts,jsx,tsx,mdx}',
    './app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      fontFamily: {
        serif: ['var(--font-playfair)', 'Georgia', 'serif'],
        sans: ['var(--font-outfit)', 'system-ui', 'sans-serif'],
        mono: ['var(--font-dm-mono)', 'monospace'],
      },
      colors: {
        ink: {
          DEFAULT: '#0F0E0C',
          light: '#2A2825',
          muted: '#6B6860',
        },
        cream: {
          DEFAULT: '#FAF8F4',
          dark: '#F0EDE6',
          border: '#E5E1D8',
        },
        accent: {
          DEFAULT: '#C2402A',
          light: '#E8533A',
          dark: '#9E2E1A',
        },
      },
    },
  },
  plugins: [],
}
export default config