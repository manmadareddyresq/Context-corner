import Link from 'next/link'
import { Search } from 'lucide-react'

export default function Navbar() {
  return (
    <nav className="sticky top-0 z-50 border-b border-cream-border bg-cream/80 backdrop-blur-md">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex h-20 items-center justify-between">
          <Link href="/" className="font-serif text-2xl font-black uppercase tracking-tighter text-ink">
            Context <span className="text-accent">Corner</span>
          </Link>
          <div className="hidden space-x-8 font-sans text-sm font-medium uppercase tracking-widest md:flex">
            <Link href="#" className="hover:text-accent">Essays</Link>
            <Link href="#" className="hover:text-accent">Discourse</Link>
            <Link href="#" className="hover:text-accent">Culture</Link>
          </div>
          <div className="flex items-center space-x-4">
            <button className="p-2 text-ink-muted hover:text-ink"><Search size={20} /></button>
            <Link href="/admin" className="rounded-full bg-ink px-5 py-2 text-xs font-bold uppercase tracking-widest text-cream transition-colors hover:bg-accent">Write</Link>
          </div>
        </div>
      </div>
    </nav>
  )
}