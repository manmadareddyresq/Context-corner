import Image from 'next/image'
import Link from 'next/link'
import { motion } from 'framer-motion'

export default function ArticleCard({ article, variant = 'standard' }: any) {
  const isFeatured = variant === 'featured'
  return (
    <motion.article initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} className={`group flex flex-col ${isFeatured ? 'md:flex-row md:gap-8' : ''}`}>
      <div className={`relative overflow-hidden bg-cream-dark ${isFeatured ? 'md:w-2/3' : 'aspect-[16/10] mb-4'}`}>
        <Image src={article.image_url || 'https://picsum.photos/800/500'} alt={article.title} width={800} height={500} className="object-cover transition-transform duration-700 group-hover:scale-105" />
      </div>
      <div className={isFeatured ? 'md:w-1/3 py-4' : ''}>
        <span className="font-mono text-[10px] uppercase tracking-[0.2em] text-accent">{article.category}</span>
        <Link href={`/articles/${article.slug}`}><h2 className={`mt-2 font-serif group-hover:underline ${isFeatured ? 'text-4xl' : 'text-xl'}`}>{article.title}</h2></Link>
        <p className="mt-3 line-clamp-3 font-sans text-sm leading-relaxed text-ink-muted">{article.excerpt}</p>
      </div>
    </motion.article>
  )
}