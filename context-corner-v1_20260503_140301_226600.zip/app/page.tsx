import Navbar from '@/components/Navbar'
import ArticleCard from '@/components/ArticleCard'

export default function Home() {
  const articles = [
    { title: "The Architecture of Silence", excerpt: "Exploring minimalism...", category: "ESSAY", slug: "arch-silence" },
    { title: "Digital Stoicism", excerpt: "How to remain grounded...", category: "CULTURE", slug: "digital-stoicism" },
  ]
  return (
    <main className="min-h-screen">
      <Navbar />
      <section className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <div className="mb-20"><ArticleCard article={articles[0]} variant="featured" /></div>
        <div className="grid gap-12 md:grid-cols-2 lg:grid-cols-3">
          {articles.map((art) => <ArticleCard key={art.slug} article={art} />)}
        </div>
      </section>
    </main>
  )
}