create table public.articles (
  id uuid default gen_random_uuid() primary key,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null,
  title text not null,
  slug text unique not null,
  content text not null,
  excerpt text,
  image_url text,
  category text default 'Uncategorized',
  published boolean default false,
  author_id uuid references auth.users(id)
);
alter table public.articles enable row level security;
create policy "Public can read published articles" on public.articles for select using (published = true);