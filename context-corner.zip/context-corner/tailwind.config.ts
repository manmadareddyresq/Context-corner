import type { Config } from 'tailwindcss'

const config: Config = {
  content: [
    './pages/**/*.{js,ts,jsx,tsx,mdx}',
    './components/**/*.{js,ts,jsx,tsx,mdx}',
    './app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      fontFamily: {
        serif: ['var(--font-playfair)', 'Georgia', 'serif'],
        sans: ['var(--font-dm-sans)', 'system-ui', 'sans-serif'],
        mono: ['var(--font-dm-mono)', 'monospace'],
      },
      colors: {
        ink: {
          DEFAULT: '#0f0e0d',
          50: '#faf9f8',
          100: '#f0ede9',
          200: '#ddd8d0',
          300: '#c4bcb0',
          400: '#a99d8e',
          500: '#8e8070',
          600: '#756858',
          700: '#5f5447',
          800: '#4a4137',
          900: '#332e28',
          950: '#1a1714',
        },
        amber: {
          DEFAULT: '#c8973a',
          light: '#e8b355',
          dark: '#9b7228',
        },
        cream: '#fdf8f2',
        parchment: '#f5ede0',
      },
      typography: {
        DEFAULT: {
          css: {
            maxWidth: 'none',
            color: '#0f0e0d',
            a: { color: '#c8973a', '&:hover': { color: '#9b7228' } },
          },
        },
      },
      animation: {
        'fade-up': 'fadeUp 0.6s ease forwards',
        'fade-in': 'fadeIn 0.4s ease forwards',
        shimmer: 'shimmer 1.5s infinite',
      },
      keyframes: {
        fadeUp: {
          from: { opacity: '0', transform: 'translateY(24px)' },
          to: { opacity: '1', transform: 'translateY(0)' },
        },
        fadeIn: {
          from: { opacity: '0' },
          to: { opacity: '1' },
        },
        shimmer: {
          '0%': { backgroundPosition: '-200% 0' },
          '100%': { backgroundPosition: '200% 0' },
        },
      },
    },
  },
  plugins: [],
}

export default config
