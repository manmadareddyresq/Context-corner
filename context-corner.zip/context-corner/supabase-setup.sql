-- ============================================================
-- CONTEXT CORNER — Complete Supabase Setup
-- Run this entire file in the Supabase SQL Editor
-- ============================================================

-- 1. AUTHORS
create table if not exists authors (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  bio text,
  avatar_url text,
  role text,
  social_links jsonb,
  created_at timestamptz default now()
);

-- 2. CATEGORIES
create table if not exists categories (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  slug text unique not null,
  description text,
  color text,
  icon text,
  created_at timestamptz default now()
);

-- 3. TAGS
create table if not exists tags (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  slug text unique not null,
  created_at timestamptz default now()
);

-- 4. ARTICLES
create table if not exists articles (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  slug text unique not null,
  excerpt text,
  content text,
  cover_image text,
  author_id uuid references authors(id) on delete set null,
  category_id uuid references categories(id) on delete set null,
  status text default 'draft' check (status in ('draft','published')),
  featured boolean default false,
  views_count integer default 0,
  likes_count integer default 0,
  claps_count integer default 0,
  reading_time integer default 5,
  tags text[] default '{}',
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

-- 5. SUBMISSIONS
create table if not exists submissions (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  content text not null,
  author_name text not null,
  author_email text not null,
  status text default 'pending' check (status in ('pending','approved','rejected')),
  tags text[] default '{}',
  created_at timestamptz default now()
);

-- 6. REACTIONS
create table if not exists reactions (
  id uuid primary key default gen_random_uuid(),
  article_id uuid references articles(id) on delete cascade,
  type text check (type in ('like','clap')),
  session_id text not null,
  created_at timestamptz default now(),
  unique(article_id, type, session_id)
);

-- 7. ACHIEVEMENTS
create table if not exists achievements (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text,
  icon text,
  color text,
  created_at timestamptz default now()
);

-- 8. ANNOUNCEMENTS
create table if not exists announcements (
  id uuid primary key default gen_random_uuid(),
  message text not null,
  active boolean default true,
  link text,
  link_text text,
  created_at timestamptz default now()
);

-- 9. SETTINGS
create table if not exists settings (
  id uuid primary key default gen_random_uuid(),
  key text unique not null,
  value text,
  updated_at timestamptz default now()
);

-- 10. ADMIN
create table if not exists admin (
  id uuid primary key default gen_random_uuid(),
  username text unique not null,
  password text not null,
  created_at timestamptz default now()
);

-- ── SEED DATA ──────────────────────────────────────────────

-- Admin user
insert into admin (username, password)
values ('Manmada', 'Abc123')
on conflict (username) do nothing;

-- Default settings
insert into settings (key, value) values
  ('terms', '<h2>Terms of Service</h2><p>Last updated: January 2025</p><h3>1. Acceptance of Terms</h3><p>By accessing or using Context Corner, you agree to be bound by these Terms of Service and all applicable laws and regulations.</p><h3>2. Content Submission</h3><p>When you submit content to Context Corner, you grant us a non-exclusive, worldwide, royalty-free license to publish, display, and distribute your content.</p><h3>3. Editorial Standards</h3><p>Context Corner maintains editorial standards for all published content. Submissions are reviewed by our editorial team and may be edited for clarity.</p><h3>4. Prohibited Content</h3><p>You may not submit content that infringes intellectual property rights, contains defamatory statements, promotes illegal activities, or violates any applicable laws.</p><h3>5. Intellectual Property</h3><p>The Context Corner name, logo, design, and original content are protected by applicable intellectual property laws.</p><h3>6. Contact</h3><p>For questions, please contact us through our platform.</p>'),
  ('help_email', 'help@contextcorner.com'),
  ('site_description', 'A premium editorial platform for thoughtful perspectives, deep-dives, and cultural commentary.')
on conflict (key) do nothing;

-- Sample categories
insert into categories (name, slug, description, icon, color) values
  ('Technology', 'technology', 'Exploring the frontiers of digital innovation', '💻', '#3b82f6'),
  ('Culture', 'culture', 'Art, society, and the human experience', '🎭', '#8b5cf6'),
  ('Science', 'science', 'Discoveries shaping our understanding of the world', '🔬', '#06b6d4'),
  ('Politics', 'politics', 'Analysis of power, policy, and governance', '⚖️', '#ef4444'),
  ('Environment', 'environment', 'Climate, nature, and sustainability', '🌍', '#22c55e'),
  ('Arts', 'arts', 'Creativity, literature, and visual expression', '🎨', '#f59e0b')
on conflict (slug) do nothing;

-- Sample author
insert into authors (name, bio, role) values
  ('Editorial Team', 'The Context Corner editorial team brings together writers, thinkers, and journalists committed to thoughtful, in-depth coverage.', 'Editor in Chief')
on conflict do nothing;

-- Sample achievement
insert into achievements (title, description, icon, color) values
  ('100 Articles Published', 'Celebrating a century of thoughtful stories', '🏆', '#c8973a'),
  ('10,000 Readers', 'Our community continues to grow', '🌟', '#3b82f6'),
  ('Featured in Press', 'Recognized by leading publications', '📰', '#22c55e')
on conflict do nothing;

-- Welcome announcement
insert into announcements (message, active, link, link_text) values
  ('Welcome to Context Corner — a premium editorial platform for thoughtful perspectives. Submit your story today!', true, '/write', 'Start Writing')
on conflict do nothing;

-- ── REALTIME ────────────────────────────────────────────────
-- Enable realtime for key tables
alter publication supabase_realtime add table articles;
alter publication supabase_realtime add table submissions;
alter publication supabase_realtime add table announcements;
alter publication supabase_realtime add table reactions;

-- ── ROW LEVEL SECURITY (RLS) ────────────────────────────────
-- Enable RLS on all tables
alter table articles enable row level security;
alter table authors enable row level security;
alter table categories enable row level security;
alter table tags enable row level security;
alter table submissions enable row level security;
alter table reactions enable row level security;
alter table achievements enable row level security;
alter table announcements enable row level security;
alter table settings enable row level security;
alter table admin enable row level security;

-- Public read policies
create policy "Public can read published articles" on articles for select using (status = 'published');
create policy "Public can read authors" on authors for select using (true);
create policy "Public can read categories" on categories for select using (true);
create policy "Public can read tags" on tags for select using (true);
create policy "Public can read reactions" on reactions for select using (true);
create policy "Public can read achievements" on achievements for select using (true);
create policy "Public can read active announcements" on announcements for select using (active = true);
create policy "Public can read settings" on settings for select using (true);

-- Public write policies
create policy "Public can insert submissions" on submissions for insert with check (true);
create policy "Public can insert reactions" on reactions for insert with check (true);
create policy "Public can update article views" on articles for update using (true) with check (true);
create policy "Public can delete own reactions" on reactions for delete using (true);

-- Admin full access (using anon key for this demo)
create policy "Anon can manage articles" on articles for all using (true) with check (true);
create policy "Anon can manage authors" on authors for all using (true) with check (true);
create policy "Anon can manage categories" on categories for all using (true) with check (true);
create policy "Anon can manage tags" on tags for all using (true) with check (true);
create policy "Anon can manage submissions" on submissions for all using (true) with check (true);
create policy "Anon can manage achievements" on achievements for all using (true) with check (true);
create policy "Anon can manage announcements" on announcements for all using (true) with check (true);
create policy "Anon can manage settings" on settings for all using (true) with check (true);
create policy "Anon can read admin" on admin for select using (true);
