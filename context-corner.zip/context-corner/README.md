# Context Corner — Premium Editorial Platform

A production-ready editorial platform built with Next.js 14, TypeScript, Tailwind CSS, Framer Motion, and Supabase.

---

## 🚀 Quick Start

### 1. Install dependencies
```bash
npm install
```

### 2. Set up Supabase database
1. Go to your Supabase project → **SQL Editor**
2. Paste the entire contents of `supabase-setup.sql`
3. Click **Run** — this creates all tables, seeds demo data, and configures RLS

### 3. Environment variables
The `.env.local` file is pre-configured with your Supabase credentials:
```
NEXT_PUBLIC_SUPABASE_URL=https://owbuptpswguimpyuwvyf.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=sb_publishable_vo5jIboXukZokhBhfUWWSw_SOJOFHqx
```

### 4. Run locally
```bash
npm run dev
```

Visit [http://localhost:3000](http://localhost:3000)

---

## 🔐 Admin Access

URL: `/admin`

| Field    | Value    |
|----------|----------|
| Username | Manmada  |
| Password | Abc123   |

---

## 📁 Project Structure

```
app/
  layout.tsx          # Root layout
  page.tsx            # Homepage
  admin/page.tsx      # Admin panel (login-protected)
  article/[slug]/     # Article detail page
  category/[slug]/    # Category listing
  tag/[slug]/         # Tag listing
  write/page.tsx      # Public submission form
  terms/page.tsx      # Terms of Service
  bookmarks/page.tsx  # Saved articles (localStorage)

components/
  Navbar.tsx          # Animated navigation bar
  ArticleCard.tsx     # Article card (3 variants)
  Editor.tsx          # TipTap rich text editor
  Search.tsx          # Live search overlay

lib/
  supabase.ts         # Supabase client + all types
```

---

## ✨ Features

### Public
- **Homepage** — Announcement banner, parallax hero, featured articles, trending, categories, achievements, latest articles, tag cloud
- **Article pages** — Full content, author bio, reactions (like/clap), share button, related articles, more from author
- **Search** — Live search from 1 character (title, excerpt)
- **Bookmarks** — localStorage-based, auto-cleans deleted articles
- **Write** — Public submission form with auto-save draft, TipTap editor
- **Category & Tag pages** — Paginated article listings
- **Terms** — Editable from admin settings

### Admin (`/admin`)
- **Dashboard** — Stats: articles, views, submissions, authors
- **Articles** — Full CRUD, rich editor, slug auto-gen, status toggle, featured flag
- **Authors** — CRUD with avatar, bio, role
- **Categories** — CRUD with emoji icon, color, slug
- **Tags** — Add/delete tags
- **Submissions** — Review, approve, reject, delete; realtime updates
- **Achievements** — CRUD with emoji + color
- **Announcements** — Live/off toggle, link support
- **Settings** — Edit terms content, help email, site description

### Technical
- **Realtime** — Supabase channels for articles, submissions, announcements, reactions
- **Skeleton loaders** — All data-loading states
- **Framer Motion** — Page transitions, hero parallax, card animations
- **Mobile-first** — Fully responsive at all breakpoints

---

## 🌐 Deploy to Vercel

```bash
npm install -g vercel
vercel --prod
```

Or connect your GitHub repo to Vercel and it will auto-deploy.

Make sure to add environment variables in Vercel dashboard.

---

## 🗄️ Database Tables

| Table | Purpose |
|-------|---------|
| `articles` | All articles with metadata |
| `authors` | Author profiles |
| `categories` | Article categories |
| `tags` | Article tags |
| `submissions` | Public write submissions |
| `reactions` | Like/clap per session |
| `achievements` | Platform milestones |
| `announcements` | Top banner messages |
| `settings` | Editable site settings |
| `admin` | Single admin user |
