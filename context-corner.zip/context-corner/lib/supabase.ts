import { createClient } from '@supabase/supabase-js'

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!

export const supabase = createClient(supabaseUrl, supabaseAnonKey)

export type Article = {
  id: string
  title: string
  slug: string
  excerpt: string
  content: string
  cover_image: string | null
  author_id: string | null
  category_id: string | null
  status: 'draft' | 'published'
  featured: boolean
  views_count: number
  likes_count: number
  claps_count: number
  reading_time: number
  tags: string[]
  created_at: string
  updated_at: string
  authors?: Author
  categories?: Category
}

export type Author = {
  id: string
  name: string
  bio: string | null
  avatar_url: string | null
  role: string | null
  social_links: Record<string, string> | null
  created_at: string
}

export type Category = {
  id: string
  name: string
  slug: string
  description: string | null
  color: string | null
  icon: string | null
  created_at: string
}

export type Tag = {
  id: string
  name: string
  slug: string
  created_at: string
}

export type Submission = {
  id: string
  title: string
  content: string
  author_name: string
  author_email: string
  status: 'pending' | 'approved' | 'rejected'
  tags: string[]
  created_at: string
}

export type Reaction = {
  id: string
  article_id: string
  type: 'like' | 'clap'
  session_id: string
  created_at: string
}

export type Achievement = {
  id: string
  title: string
  description: string
  icon: string | null
  color: string | null
  created_at: string
}

export type Announcement = {
  id: string
  message: string
  active: boolean
  link: string | null
  link_text: string | null
  created_at: string
}

export type Setting = {
  id: string
  key: string
  value: string
  updated_at: string
}

// SQL to create all tables (run in Supabase SQL editor)
export const DB_SETUP_SQL = `
-- Authors
create table if not exists authors (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  bio text,
  avatar_url text,
  role text,
  social_links jsonb,
  created_at timestamptz default now()
);

-- Categories
create table if not exists categories (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  slug text unique not null,
  description text,
  color text,
  icon text,
  created_at timestamptz default now()
);

-- Tags
create table if not exists tags (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  slug text unique not null,
  created_at timestamptz default now()
);

-- Articles
create table if not exists articles (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  slug text unique not null,
  excerpt text,
  content text,
  cover_image text,
  author_id uuid references authors(id) on delete set null,
  category_id uuid references categories(id) on delete set null,
  status text default 'draft' check (status in ('draft', 'published')),
  featured boolean default false,
  views_count integer default 0,
  likes_count integer default 0,
  claps_count integer default 0,
  reading_time integer default 5,
  tags text[] default '{}',
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

-- Submissions
create table if not exists submissions (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  content text not null,
  author_name text not null,
  author_email text not null,
  status text default 'pending' check (status in ('pending', 'approved', 'rejected')),
  tags text[] default '{}',
  created_at timestamptz default now()
);

-- Reactions
create table if not exists reactions (
  id uuid primary key default gen_random_uuid(),
  article_id uuid references articles(id) on delete cascade,
  type text check (type in ('like', 'clap')),
  session_id text not null,
  created_at timestamptz default now(),
  unique(article_id, type, session_id)
);

-- Achievements
create table if not exists achievements (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text,
  icon text,
  color text,
  created_at timestamptz default now()
);

-- Announcements
create table if not exists announcements (
  id uuid primary key default gen_random_uuid(),
  message text not null,
  active boolean default true,
  link text,
  link_text text,
  created_at timestamptz default now()
);

-- Settings
create table if not exists settings (
  id uuid primary key default gen_random_uuid(),
  key text unique not null,
  value text,
  updated_at timestamptz default now()
);

-- Admin
create table if not exists admin (
  id uuid primary key default gen_random_uuid(),
  username text unique not null,
  password text not null,
  created_at timestamptz default now()
);

-- Insert admin user
insert into admin (username, password) values ('Manmada', 'Abc123') on conflict do nothing;

-- Insert default settings
insert into settings (key, value) values
  ('terms', 'These are the Terms of Service for Context Corner...'),
  ('help_email', 'help@contextcorner.com'),
  ('site_description', 'A premium editorial platform for thoughtful perspectives.')
on conflict do nothing;

-- Enable realtime
alter publication supabase_realtime add table articles;
alter publication supabase_realtime add table submissions;
alter publication supabase_realtime add table announcements;
alter publication supabase_realtime add table reactions;
`
