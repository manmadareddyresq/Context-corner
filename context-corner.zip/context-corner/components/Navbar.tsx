'use client'

import { useState, useEffect, useRef } from 'react'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { motion, AnimatePresence } from 'framer-motion'
import { supabase } from '@/lib/supabase'
import type { Category } from '@/lib/supabase'
import Search from './Search'

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false)
  const [menuOpen, setMenuOpen] = useState(false)
  const [searchOpen, setSearchOpen] = useState(false)
  const [categories, setCategories] = useState<Category[]>([])
  const [bookmarkCount, setBookmarkCount] = useState(0)
  const pathname = usePathname()

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 40)
    window.addEventListener('scroll', handleScroll, { passive: true })
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  useEffect(() => {
    supabase.from('categories').select('*').limit(6).then(({ data }) => {
      if (data) setCategories(data)
    })
  }, [])

  useEffect(() => {
    const bookmarks = JSON.parse(localStorage.getItem('cc_bookmarks') || '[]')
    setBookmarkCount(bookmarks.length)
  }, [pathname])

  useEffect(() => { setMenuOpen(false) }, [pathname])

  return (
    <>
      <motion.nav
        initial={{ y: -80, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.6, ease: [0.25, 0.46, 0.45, 0.94] }}
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
          scrolled
            ? 'bg-cream/95 backdrop-blur-xl border-b border-ink-200/50 shadow-sm'
            : 'bg-transparent'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          {/* Top bar */}
          <div className="flex items-center justify-between h-16 md:h-18">
            {/* Logo */}
            <Link href="/" className="flex items-center gap-2 group">
              <div className="w-8 h-8 rounded-sm flex items-center justify-center"
                style={{ background: 'var(--amber)' }}>
                <span className="font-serif text-white font-bold text-sm">C</span>
              </div>
              <div>
                <span className="font-serif font-bold text-lg text-ink-950 tracking-tight leading-none block">
                  Context
                </span>
                <span className="font-mono text-xs text-amber tracking-widest uppercase leading-none">
                  Corner
                </span>
              </div>
            </Link>

            {/* Desktop nav */}
            <div className="hidden md:flex items-center gap-1">
              <Link href="/" className={`px-3 py-2 text-sm font-medium rounded-md transition-colors ${pathname === '/' ? 'text-amber' : 'text-ink-600 hover:text-ink-950'}`}>
                Home
              </Link>
              {categories.slice(0, 4).map(cat => (
                <Link key={cat.id} href={`/category/${cat.slug}`}
                  className={`px-3 py-2 text-sm font-medium rounded-md transition-colors ${pathname === `/category/${cat.slug}` ? 'text-amber' : 'text-ink-600 hover:text-ink-950'}`}>
                  {cat.name}
                </Link>
              ))}
              <Link href="/write" className="px-3 py-2 text-sm font-medium text-ink-600 hover:text-ink-950 rounded-md transition-colors">
                Write
              </Link>
            </div>

            {/* Right actions */}
            <div className="flex items-center gap-2">
              {/* Search */}
              <button onClick={() => setSearchOpen(true)}
                className="p-2 rounded-md text-ink-500 hover:text-ink-950 hover:bg-ink-100/50 transition-colors"
                aria-label="Search">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth={1.75} viewBox="0 0 24 24">
                  <circle cx="11" cy="11" r="8" /><path d="m21 21-4.35-4.35" strokeLinecap="round" />
                </svg>
              </button>

              {/* Bookmarks */}
              <Link href="/bookmarks" className="relative p-2 rounded-md text-ink-500 hover:text-ink-950 hover:bg-ink-100/50 transition-colors">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth={1.75} viewBox="0 0 24 24">
                  <path d="m19 21-7-4-7 4V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v16z" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
                {bookmarkCount > 0 && (
                  <span className="absolute top-1 right-1 w-3.5 h-3.5 rounded-full text-white flex items-center justify-center"
                    style={{ background: 'var(--amber)', fontSize: '9px', fontWeight: 700 }}>
                    {bookmarkCount > 9 ? '9+' : bookmarkCount}
                  </span>
                )}
              </Link>

              {/* Write CTA */}
              <Link href="/write"
                className="hidden md:flex items-center gap-1.5 px-4 py-2 rounded-full text-sm font-semibold text-white transition-all hover:scale-105 active:scale-95"
                style={{ background: 'linear-gradient(135deg, var(--amber), var(--amber-dark))' }}>
                <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" strokeWidth={2.5} viewBox="0 0 24 24">
                  <path d="M12 5v14M5 12h14" strokeLinecap="round" />
                </svg>
                Write
              </Link>

              {/* Mobile menu toggle */}
              <button onClick={() => setMenuOpen(!menuOpen)}
                className="md:hidden p-2 rounded-md text-ink-500 hover:text-ink-950 transition-colors"
                aria-label="Menu">
                <div className="w-5 h-4 flex flex-col justify-between">
                  <motion.span animate={menuOpen ? { rotate: 45, y: 6 } : { rotate: 0, y: 0 }}
                    className="block h-0.5 bg-current rounded-full transition-transform origin-center" />
                  <motion.span animate={menuOpen ? { opacity: 0 } : { opacity: 1 }}
                    className="block h-0.5 bg-current rounded-full" />
                  <motion.span animate={menuOpen ? { rotate: -45, y: -6 } : { rotate: 0, y: 0 }}
                    className="block h-0.5 bg-current rounded-full transition-transform origin-center" />
                </div>
              </button>
            </div>
          </div>
        </div>

        {/* Mobile menu */}
        <AnimatePresence>
          {menuOpen && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              transition={{ duration: 0.3, ease: 'easeInOut' }}
              className="md:hidden overflow-hidden bg-cream border-t border-ink-200/50"
            >
              <div className="px-4 py-4 space-y-1">
                <Link href="/" className="block px-3 py-2.5 text-sm font-medium text-ink-700 hover:text-amber rounded-md hover:bg-parchment transition-colors">Home</Link>
                {categories.map(cat => (
                  <Link key={cat.id} href={`/category/${cat.slug}`}
                    className="block px-3 py-2.5 text-sm font-medium text-ink-700 hover:text-amber rounded-md hover:bg-parchment transition-colors">
                    {cat.name}
                  </Link>
                ))}
                <Link href="/write" className="block px-3 py-2.5 text-sm font-medium text-ink-700 hover:text-amber rounded-md hover:bg-parchment transition-colors">Write for Us</Link>
                <Link href="/terms" className="block px-3 py-2.5 text-sm font-medium text-ink-700 hover:text-amber rounded-md hover:bg-parchment transition-colors">Terms</Link>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.nav>

      {/* Search overlay */}
      <AnimatePresence>
        {searchOpen && <Search onClose={() => setSearchOpen(false)} />}
      </AnimatePresence>
    </>
  )
}
