'use client'

import { useState, useEffect, useRef, useCallback } from 'react'
import { motion } from 'framer-motion'
import Link from 'next/link'
import Image from 'next/image'
import { supabase } from '@/lib/supabase'
import type { Article } from '@/lib/supabase'

interface SearchProps {
  onClose: () => void
}

export default function Search({ onClose }: SearchProps) {
  const [query, setQuery] = useState('')
  const [results, setResults] = useState<Article[]>([])
  const [loading, setLoading] = useState(false)
  const inputRef = useRef<HTMLInputElement>(null)
  const timeoutRef = useRef<ReturnType<typeof setTimeout>>()

  useEffect(() => {
    inputRef.current?.focus()
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose()
    }
    document.addEventListener('keydown', handleKey)
    document.body.style.overflow = 'hidden'
    return () => {
      document.removeEventListener('keydown', handleKey)
      document.body.style.overflow = ''
    }
  }, [onClose])

  const search = useCallback(async (q: string) => {
    if (!q.trim()) { setResults([]); return }
    setLoading(true)
    try {
      const { data } = await supabase
        .from('articles')
        .select('*, authors(name, avatar_url), categories(name, slug)')
        .eq('status', 'published')
        .or(`title.ilike.%${q}%,excerpt.ilike.%${q}%`)
        .limit(8)
      setResults(data || [])
    } catch {
      setResults([])
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    clearTimeout(timeoutRef.current)
    timeoutRef.current = setTimeout(() => search(query), 200)
    return () => clearTimeout(timeoutRef.current)
  }, [query, search])

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[100] flex items-start justify-center pt-20 px-4"
      style={{ background: 'rgba(15,14,13,0.85)', backdropFilter: 'blur(12px)' }}
      onClick={(e) => { if (e.target === e.currentTarget) onClose() }}
    >
      <motion.div
        initial={{ opacity: 0, y: -20, scale: 0.97 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, y: -20, scale: 0.97 }}
        transition={{ duration: 0.25, ease: [0.25, 0.46, 0.45, 0.94] }}
        className="w-full max-w-2xl rounded-2xl overflow-hidden shadow-2xl"
        style={{ background: 'var(--cream)' }}
      >
        {/* Search input */}
        <div className="flex items-center gap-3 px-5 py-4 border-b border-ink-200/40">
          <svg className="w-5 h-5 text-ink-400 flex-shrink-0" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
            <circle cx="11" cy="11" r="8" /><path d="m21 21-4.35-4.35" strokeLinecap="round" />
          </svg>
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={e => setQuery(e.target.value)}
            placeholder="Search articles, authors, topics…"
            className="flex-1 bg-transparent font-sans text-base text-ink-900 placeholder-ink-400 focus:outline-none"
          />
          {loading && (
            <div className="w-4 h-4 rounded-full border-2 border-amber border-t-transparent animate-spin" />
          )}
          <button onClick={onClose}
            className="text-xs font-mono text-ink-400 hover:text-ink-600 transition-colors px-2 py-1 rounded border border-ink-200 hover:border-ink-400">
            ESC
          </button>
        </div>

        {/* Results */}
        <div className="max-h-[60vh] overflow-y-auto">
          {query && results.length === 0 && !loading && (
            <div className="px-5 py-10 text-center">
              <p className="text-ink-400 font-sans text-sm">No articles found for <span className="font-medium text-ink-600">"{query}"</span></p>
            </div>
          )}

          {results.length > 0 && (
            <div className="py-2">
              <p className="px-5 py-2 text-xs font-mono text-ink-400 uppercase tracking-wider">
                {results.length} result{results.length !== 1 ? 's' : ''}
              </p>
              {results.map((article, i) => (
                <motion.div
                  key={article.id}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.04 }}
                >
                  <Link href={`/article/${article.slug}`} onClick={onClose}
                    className="flex items-center gap-4 px-5 py-3 hover:bg-parchment transition-colors group">
                    {article.cover_image ? (
                      <div className="w-14 h-10 rounded-md overflow-hidden flex-shrink-0 bg-ink-100">
                        <img src={article.cover_image} alt="" className="w-full h-full object-cover" />
                      </div>
                    ) : (
                      <div className="w-14 h-10 rounded-md flex-shrink-0 flex items-center justify-center text-xl bg-parchment">
                        📄
                      </div>
                    )}
                    <div className="flex-1 min-w-0">
                      <p className="font-serif font-semibold text-sm text-ink-900 group-hover:text-amber transition-colors truncate">
                        {article.title}
                      </p>
                      <p className="text-xs text-ink-400 mt-0.5">
                        {(article as any).authors?.name} · {article.reading_time} min read
                      </p>
                    </div>
                    <svg className="w-4 h-4 text-ink-300 group-hover:text-amber transition-colors flex-shrink-0" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
                      <path d="M9 18l6-6-6-6" strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                  </Link>
                </motion.div>
              ))}
            </div>
          )}

          {!query && (
            <div className="px-5 py-8 text-center">
              <p className="text-ink-300 font-mono text-xs uppercase tracking-wider mb-2">Start typing to search</p>
              <p className="text-ink-400 font-sans text-sm">Find articles, authors, and topics</p>
            </div>
          )}
        </div>
      </motion.div>
    </motion.div>
  )
}
