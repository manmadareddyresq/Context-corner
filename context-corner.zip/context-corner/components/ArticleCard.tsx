'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import { motion } from 'framer-motion'
import type { Article } from '@/lib/supabase'
import { formatDistanceToNow } from 'date-fns'

interface ArticleCardProps {
  article: Article & { authors?: any; categories?: any }
  variant?: 'default' | 'featured' | 'compact' | 'hero'
  index?: number
}

export default function ArticleCard({ article, variant = 'default', index = 0 }: ArticleCardProps) {
  const [bookmarked, setBookmarked] = useState(false)

  useEffect(() => {
    const bookmarks = JSON.parse(localStorage.getItem('cc_bookmarks') || '[]')
    setBookmarked(bookmarks.includes(article.id))
  }, [article.id])

  const toggleBookmark = (e: React.MouseEvent) => {
    e.preventDefault()
    e.stopPropagation()
    const bookmarks: string[] = JSON.parse(localStorage.getItem('cc_bookmarks') || '[]')
    const updated = bookmarked
      ? bookmarks.filter(id => id !== article.id)
      : [...bookmarks, article.id]
    localStorage.setItem('cc_bookmarks', JSON.stringify(updated))
    setBookmarked(!bookmarked)
    window.dispatchEvent(new Event('bookmarks-changed'))
  }

  const timeAgo = article.created_at
    ? formatDistanceToNow(new Date(article.created_at), { addSuffix: true })
    : ''

  if (variant === 'compact') {
    return (
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: index * 0.07, duration: 0.4 }}
      >
        <Link href={`/article/${article.slug}`}
          className="flex gap-4 group py-4 border-b border-ink-100 last:border-0">
          <div className="flex-1 min-w-0">
            {article.categories && (
              <span className="text-xs font-mono text-amber uppercase tracking-wider">
                {article.categories.name}
              </span>
            )}
            <h3 className="font-serif font-semibold text-base text-ink-900 group-hover:text-amber transition-colors leading-snug mt-0.5 line-clamp-2">
              {article.title}
            </h3>
            <div className="flex items-center gap-2 mt-1.5 text-xs text-ink-400 font-sans">
              {article.authors && <span>{article.authors.name}</span>}
              <span>·</span>
              <span>{article.reading_time} min</span>
            </div>
          </div>
          {article.cover_image && (
            <div className="w-20 h-16 rounded-lg overflow-hidden flex-shrink-0 bg-ink-100">
              <img src={article.cover_image} alt={article.title}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
            </div>
          )}
        </Link>
      </motion.div>
    )
  }

  if (variant === 'featured') {
    return (
      <motion.div
        initial={{ opacity: 0, y: 24 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: index * 0.1, duration: 0.5 }}
        className="article-card group"
      >
        <Link href={`/article/${article.slug}`} className="block">
          <div className="relative overflow-hidden rounded-xl bg-ink-100 aspect-[4/3]">
            {article.cover_image ? (
              <img src={article.cover_image} alt={article.title}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" />
            ) : (
              <div className="w-full h-full flex items-center justify-center text-5xl"
                style={{ background: 'linear-gradient(135deg, #f5ede0, #e8ddd0)' }}>
                ✍️
              </div>
            )}
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/10 to-transparent" />

            {/* Category badge */}
            {article.categories && (
              <div className="absolute top-3 left-3">
                <span className="px-2.5 py-1 rounded-full text-xs font-mono font-medium text-white uppercase tracking-wider"
                  style={{ background: 'rgba(200,151,58,0.9)', backdropFilter: 'blur(8px)' }}>
                  {article.categories.name}
                </span>
              </div>
            )}

            {/* Bookmark button */}
            <button onClick={toggleBookmark}
              className="absolute top-3 right-3 w-8 h-8 rounded-full flex items-center justify-center transition-all hover:scale-110"
              style={{ background: 'rgba(255,255,255,0.15)', backdropFilter: 'blur(8px)' }}>
              <svg className={`w-4 h-4 ${bookmarked ? 'text-amber fill-amber' : 'text-white'}`}
                fill={bookmarked ? 'currentColor' : 'none'} stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
                <path d="m19 21-7-4-7 4V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v16z" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            </button>
          </div>

          <div className="mt-3.5">
            <h3 className="font-serif font-bold text-lg text-ink-950 group-hover:text-amber transition-colors leading-tight line-clamp-2">
              {article.title}
            </h3>
            {article.excerpt && (
              <p className="font-sans text-sm text-ink-500 mt-1.5 line-clamp-2 leading-relaxed">
                {article.excerpt}
              </p>
            )}
            <div className="flex items-center gap-3 mt-3 text-xs text-ink-400 font-sans">
              {article.authors && (
                <div className="flex items-center gap-1.5">
                  <div className="w-5 h-5 rounded-full overflow-hidden bg-ink-200 flex-shrink-0">
                    {article.authors.avatar_url ? (
                      <img src={article.authors.avatar_url} alt={article.authors.name} className="w-full h-full object-cover" />
                    ) : (
                      <span className="w-full h-full flex items-center justify-center text-xs font-serif font-bold text-amber">
                        {article.authors.name?.[0]}
                      </span>
                    )}
                  </div>
                  <span className="font-medium text-ink-600">{article.authors.name}</span>
                </div>
              )}
              <span>·</span>
              <span>{article.reading_time} min read</span>
              <span>·</span>
              <span>{timeAgo}</span>
            </div>
          </div>
        </Link>
      </motion.div>
    )
  }

  // Default card
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.08, duration: 0.45 }}
      className="article-card group bg-white rounded-xl overflow-hidden border border-ink-100 shadow-sm"
    >
      <Link href={`/article/${article.slug}`} className="block">
        {article.cover_image ? (
          <div className="relative overflow-hidden aspect-[16/9] bg-ink-100">
            <img src={article.cover_image} alt={article.title}
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" />
            <button onClick={toggleBookmark}
              className="absolute top-2.5 right-2.5 w-7 h-7 rounded-full flex items-center justify-center transition-all hover:scale-110"
              style={{ background: 'rgba(255,255,255,0.9)', backdropFilter: 'blur(4px)' }}>
              <svg className={`w-3.5 h-3.5 ${bookmarked ? 'text-amber fill-amber' : 'text-ink-400'}`}
                fill={bookmarked ? 'currentColor' : 'none'} stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
                <path d="m19 21-7-4-7 4V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v16z" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            </button>
          </div>
        ) : null}

        <div className="p-4">
          {article.categories && (
            <span className="text-xs font-mono text-amber uppercase tracking-wider">
              {article.categories.name}
            </span>
          )}
          <h3 className="font-serif font-bold text-base text-ink-950 group-hover:text-amber transition-colors leading-snug mt-1 line-clamp-2">
            {article.title}
          </h3>
          {article.excerpt && (
            <p className="font-sans text-xs text-ink-500 mt-1.5 line-clamp-2 leading-relaxed">
              {article.excerpt}
            </p>
          )}
          <div className="flex items-center justify-between mt-3 pt-3 border-t border-ink-50">
            <div className="flex items-center gap-1.5 text-xs text-ink-400">
              {article.authors && <span className="font-medium text-ink-600">{article.authors.name}</span>}
              <span>·</span>
              <span>{article.reading_time}m</span>
            </div>
            <div className="flex items-center gap-2 text-xs text-ink-300">
              <span className="flex items-center gap-0.5">
                <svg className="w-3 h-3" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
                  <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" />
                  <circle cx="12" cy="12" r="3" />
                </svg>
                {article.views_count || 0}
              </span>
            </div>
          </div>
        </div>
      </Link>
    </motion.div>
  )
}
