'use client'

import { useState, useEffect } from 'react'
import { useParams } from 'next/navigation'
import Link from 'next/link'
import { motion } from 'framer-motion'
import Navbar from '@/components/Navbar'
import ArticleCard from '@/components/ArticleCard'
import { supabase } from '@/lib/supabase'
import type { Article, Category } from '@/lib/supabase'

export default function CategoryPage() {
  const { slug } = useParams<{ slug: string }>()
  const [category, setCategory] = useState<Category | null>(null)
  const [articles, setArticles] = useState<Article[]>([])
  const [loading, setLoading] = useState(true)
  const [page, setPage] = useState(0)
  const [hasMore, setHasMore] = useState(true)
  const PAGE_SIZE = 9

  useEffect(() => {
    const fetchCategory = async () => {
      const { data } = await supabase.from('categories').select('*').eq('slug', slug).single()
      setCategory(data)
      if (data) {
        const { data: arts } = await supabase
          .from('articles')
          .select('*, authors(*), categories(*)')
          .eq('status', 'published')
          .eq('category_id', data.id)
          .order('created_at', { ascending: false })
          .range(0, PAGE_SIZE - 1)
        setArticles(arts || [])
        setHasMore((arts?.length || 0) === PAGE_SIZE)
      }
      setLoading(false)
    }
    fetchCategory()
  }, [slug])

  const loadMore = async () => {
    if (!category || !hasMore) return
    const newPage = page + 1
    const { data } = await supabase
      .from('articles')
      .select('*, authors(*), categories(*)')
      .eq('status', 'published')
      .eq('category_id', category.id)
      .order('created_at', { ascending: false })
      .range(newPage * PAGE_SIZE, (newPage + 1) * PAGE_SIZE - 1)
    setArticles(prev => [...prev, ...(data || [])])
    setPage(newPage)
    setHasMore((data?.length || 0) === PAGE_SIZE)
  }

  const categoryEmojis: Record<string, string> = {
    Technology: '💻', Culture: '🎭', Politics: '⚖️', Science: '🔬',
    Arts: '🎨', Business: '📈', Health: '🌿', Environment: '🌍',
  }

  if (!loading && !category) {
    return (
      <div className="min-h-screen" style={{ background: 'var(--cream)' }}>
        <Navbar />
        <div className="pt-32 text-center px-4">
          <h1 className="font-serif text-4xl font-bold text-ink-950 mb-4">Category Not Found</h1>
          <Link href="/" className="text-amber hover:underline">← Back to Home</Link>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen" style={{ background: 'var(--cream)' }}>
      <Navbar />

      {/* Header */}
      <div className="pt-20 pb-12 border-b border-ink-100" style={{ background: 'var(--parchment)' }}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 pt-10">
          <div className="flex items-center gap-2 text-xs font-mono text-ink-400 mb-6">
            <Link href="/" className="hover:text-amber transition-colors">Home</Link>
            <span>/</span>
            <span className="text-ink-600">{category?.name || '...'}</span>
          </div>
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
            <div className="flex items-center gap-4">
              <span className="text-5xl">{category?.name ? (categoryEmojis[category.name] || category?.icon || '📂') : '📂'}</span>
              <div>
                <p className="text-xs font-mono text-amber uppercase tracking-widest mb-1">Category</p>
                <h1 className="font-serif font-bold text-4xl md:text-5xl text-ink-950">
                  {loading ? '...' : category?.name}
                </h1>
                {category?.description && (
                  <p className="font-sans text-ink-500 mt-2 max-w-xl">{category.description}</p>
                )}
              </div>
            </div>
          </motion.div>
        </div>
      </div>

      {/* Articles grid */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-12 md:py-16">
        {loading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {Array(6).fill(0).map((_, i) => (
              <div key={i} className="rounded-xl overflow-hidden bg-white border border-ink-100">
                <div className="skeleton aspect-video" style={{ background: 'linear-gradient(90deg,#e8e0d6 25%,#f0e8de 50%,#e8e0d6 75%)', backgroundSize: '200% 100%' }} />
                <div className="p-4 space-y-2">
                  <div className="skeleton h-4 w-full rounded" style={{ background: 'linear-gradient(90deg,#e8e0d6 25%,#f0e8de 50%,#e8e0d6 75%)', backgroundSize: '200% 100%' }} />
                  <div className="skeleton h-4 w-3/4 rounded" style={{ background: 'linear-gradient(90deg,#e8e0d6 25%,#f0e8de 50%,#e8e0d6 75%)', backgroundSize: '200% 100%' }} />
                </div>
              </div>
            ))}
          </div>
        ) : articles.length === 0 ? (
          <div className="text-center py-24">
            <p className="text-6xl mb-4">📭</p>
            <h2 className="font-serif text-2xl font-bold text-ink-800 mb-2">No articles yet</h2>
            <p className="font-sans text-ink-400">Check back soon for new content in this category.</p>
          </div>
        ) : (
          <>
            <p className="font-mono text-xs text-ink-400 uppercase tracking-wider mb-8">
              {articles.length} article{articles.length !== 1 ? 's' : ''}
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {articles.map((article, i) => (
                <ArticleCard key={article.id} article={article} variant="default" index={i} />
              ))}
            </div>
            {hasMore && (
              <div className="text-center mt-12">
                <button onClick={loadMore}
                  className="px-8 py-3 rounded-full border border-ink-300 font-sans font-medium text-ink-700 hover:border-amber hover:text-amber transition-all hover:scale-105">
                  Load more
                </button>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  )
}
