'use client'

import { useState, useEffect } from 'react'
import { useParams } from 'next/navigation'
import Link from 'next/link'
import { motion } from 'framer-motion'
import Navbar from '@/components/Navbar'
import ArticleCard from '@/components/ArticleCard'
import { supabase } from '@/lib/supabase'
import type { Article } from '@/lib/supabase'

export default function TagPage() {
  const { slug } = useParams<{ slug: string }>()
  const tagName = slug.replace(/-/g, ' ')
  const [articles, setArticles] = useState<Article[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchArticles = async () => {
      const { data } = await supabase
        .from('articles')
        .select('*, authors(*), categories(*)')
        .eq('status', 'published')
        .contains('tags', [tagName])
        .order('created_at', { ascending: false })
        .limit(20)
      setArticles(data || [])
      setLoading(false)
    }
    fetchArticles()
  }, [tagName])

  return (
    <div className="min-h-screen" style={{ background: 'var(--cream)' }}>
      <Navbar />

      <div className="pt-20 pb-12 border-b border-ink-100" style={{ background: 'var(--parchment)' }}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 pt-10">
          <div className="flex items-center gap-2 text-xs font-mono text-ink-400 mb-6">
            <Link href="/" className="hover:text-amber transition-colors">Home</Link>
            <span>/</span>
            <span className="text-ink-600">#{tagName}</span>
          </div>
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
            <p className="text-xs font-mono text-amber uppercase tracking-widest mb-2">Tag</p>
            <h1 className="font-serif font-bold text-4xl md:text-5xl text-ink-950">
              #{tagName}
            </h1>
            <p className="font-sans text-ink-400 mt-2">{articles.length} article{articles.length !== 1 ? 's' : ''} tagged</p>
          </motion.div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-12 md:py-16">
        {loading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {Array(6).fill(0).map((_, i) => (
              <div key={i} className="h-64 rounded-xl skeleton" style={{ background: 'linear-gradient(90deg,#e8e0d6 25%,#f0e8de 50%,#e8e0d6 75%)', backgroundSize: '200% 100%' }} />
            ))}
          </div>
        ) : articles.length === 0 ? (
          <div className="text-center py-24">
            <p className="text-6xl mb-4">🏷️</p>
            <h2 className="font-serif text-2xl font-bold text-ink-800 mb-2">No articles with this tag</h2>
            <p className="font-sans text-ink-400 mb-6">Try exploring other topics.</p>
            <Link href="/" className="text-amber hover:underline font-medium">← Back to Home</Link>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {articles.map((article, i) => (
              <ArticleCard key={article.id} article={article} variant="default" index={i} />
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
