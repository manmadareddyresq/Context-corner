'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import Navbar from '@/components/Navbar'
import { supabase } from '@/lib/supabase'

const DEFAULT_TERMS = `
<h2>Terms of Service</h2>
<p>Last updated: ${new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}</p>

<h3>1. Acceptance of Terms</h3>
<p>By accessing or using Context Corner, you agree to be bound by these Terms of Service and all applicable laws and regulations. If you do not agree with any of these terms, you are prohibited from using this platform.</p>

<h3>2. Content Submission</h3>
<p>When you submit content to Context Corner, you grant us a non-exclusive, worldwide, royalty-free license to publish, display, and distribute your content. You represent that you own or have the necessary rights to submit such content.</p>

<h3>3. Editorial Standards</h3>
<p>Context Corner maintains editorial standards for all published content. Submissions are reviewed by our editorial team and may be edited for clarity, grammar, or compliance with our guidelines. We reserve the right to reject any submission.</p>

<h3>4. Prohibited Content</h3>
<p>You may not submit content that: infringes intellectual property rights, contains defamatory statements, promotes illegal activities, includes harassment or hate speech, or violates any applicable laws.</p>

<h3>5. Intellectual Property</h3>
<p>The Context Corner name, logo, design, and original content are the property of Context Corner and are protected by applicable intellectual property laws. You may not reproduce, modify, or distribute our proprietary materials without prior written consent.</p>

<h3>6. Privacy</h3>
<p>Your use of Context Corner is also governed by our Privacy Policy. We collect minimal personal information and do not sell your data to third parties.</p>

<h3>7. Disclaimer of Warranties</h3>
<p>Context Corner is provided "as is" without warranties of any kind. We do not guarantee that the platform will be error-free, uninterrupted, or that any content is accurate or reliable.</p>

<h3>8. Limitation of Liability</h3>
<p>Context Corner shall not be liable for any indirect, incidental, special, or consequential damages arising from your use of the platform.</p>

<h3>9. Changes to Terms</h3>
<p>We reserve the right to modify these terms at any time. Continued use of Context Corner after changes constitutes acceptance of the updated terms.</p>

<h3>10. Contact</h3>
<p>For questions about these Terms, please contact us through our platform.</p>
`

export default function TermsPage() {
  const [terms, setTerms] = useState('')
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchTerms = async () => {
      const { data } = await supabase.from('settings').select('value').eq('key', 'terms').single()
      setTerms(data?.value || DEFAULT_TERMS)
      setLoading(false)
    }
    fetchTerms()
  }, [])

  return (
    <div className="min-h-screen" style={{ background: 'var(--cream)' }}>
      <Navbar />

      <div className="max-w-3xl mx-auto px-4 sm:px-6 pt-28 pb-20">
        <div className="flex items-center gap-2 text-xs font-mono text-ink-400 mb-8">
          <Link href="/" className="hover:text-amber transition-colors">Home</Link>
          <span>/</span>
          <span className="text-ink-600">Terms of Service</span>
        </div>

        <div className="bg-white rounded-2xl border border-ink-100 p-8 md:p-12">
          {loading ? (
            <div className="space-y-4">
              {Array(8).fill(0).map((_, i) => (
                <div key={i} className="skeleton h-4 rounded" style={{
                  width: `${[100, 80, 100, 90, 100, 85, 100, 70][i]}%`,
                  background: 'linear-gradient(90deg,#e8e0d6 25%,#f0e8de 50%,#e8e0d6 75%)',
                  backgroundSize: '200% 100%'
                }} />
              ))}
            </div>
          ) : (
            <div className="article-content" dangerouslySetInnerHTML={{ __html: terms }} />
          )}
        </div>
      </div>
    </div>
  )
}
