'use client'

import { useState, useEffect, useCallback } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import dynamic from 'next/dynamic'
import { supabase } from '@/lib/supabase'
import type { Article, Author, Category, Tag, Submission, Achievement, Announcement, Setting } from '@/lib/supabase'

const Editor = dynamic(() => import('@/components/Editor'), { ssr: false })

// ─── helpers ──────────────────────────────────────────────────────────────────
function slugify(str: string) {
  return str.toLowerCase().trim().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '')
}
function readingTime(html: string) {
  const words = html.replace(/<[^>]*>/g, ' ').split(/\s+/).filter(Boolean).length
  return Math.max(1, Math.ceil(words / 200))
}

// ─── Login ────────────────────────────────────────────────────────────────────
function LoginScreen({ onLogin }: { onLogin: () => void }) {
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)
  const [showPw, setShowPw] = useState(false)

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError('')
    const { data } = await supabase.from('admin').select('id').eq('username', username).eq('password', password).single()
    if (data) {
      sessionStorage.setItem('cc_admin', '1')
      onLogin()
    } else {
      setError('Invalid credentials.')
    }
    setLoading(false)
  }

  return (
    <div className="min-h-screen flex items-center justify-center px-4"
      style={{ background: 'linear-gradient(135deg,#0f0e0d 0%,#1a1714 50%,#2a2520 100%)' }}>
      <motion.div initial={{ opacity: 0, y: 32 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}
        className="w-full max-w-sm">
        <div className="text-center mb-10">
          <div className="w-14 h-14 rounded-xl flex items-center justify-center mx-auto mb-4"
            style={{ background: 'var(--amber)' }}>
            <span className="font-serif text-white font-bold text-2xl">C</span>
          </div>
          <h1 className="font-serif text-3xl font-bold text-white mb-1">Context Corner</h1>
          <p className="font-mono text-xs text-white/30 uppercase tracking-widest">Admin Access</p>
        </div>
        <form onSubmit={handleLogin} className="space-y-4">
          <div>
            <label className="block text-xs font-mono text-white/40 uppercase tracking-wider mb-1.5">Username</label>
            <input type="text" value={username} onChange={e => setUsername(e.target.value)} required
              className="w-full px-4 py-3 rounded-xl text-sm font-sans text-white placeholder-white/20 border border-white/10 focus:border-amber focus:outline-none transition-colors"
              style={{ background: 'rgba(255,255,255,0.05)' }}
              placeholder="Enter username" />
          </div>
          <div className="relative">
            <label className="block text-xs font-mono text-white/40 uppercase tracking-wider mb-1.5">Password</label>
            <input type={showPw ? 'text' : 'password'} value={password} onChange={e => setPassword(e.target.value)} required
              className="w-full px-4 py-3 rounded-xl text-sm font-sans text-white placeholder-white/20 border border-white/10 focus:border-amber focus:outline-none transition-colors"
              style={{ background: 'rgba(255,255,255,0.05)' }}
              placeholder="Enter password" />
            <button type="button" onClick={() => setShowPw(!showPw)}
              className="absolute right-3 top-9 text-white/30 hover:text-white/60 transition-colors">
              {showPw ? '🙈' : '👁️'}
            </button>
          </div>
          {error && <p className="text-red-400 text-sm font-sans">{error}</p>}
          <button type="submit" disabled={loading}
            className="w-full py-3 rounded-xl font-sans font-bold text-ink-950 transition-all hover:scale-[1.02] active:scale-[0.98] disabled:opacity-60"
            style={{ background: 'linear-gradient(135deg,var(--amber-light),var(--amber-dark))' }}>
            {loading ? 'Signing in…' : 'Sign In'}
          </button>
        </form>
      </motion.div>
    </div>
  )
}

// ─── Stat card ─────────────────────────────────────────────────────────────────
function StatCard({ label, value, icon, color }: { label: string; value: number | string; icon: string; color: string }) {
  return (
    <div className="bg-white rounded-xl p-5 border border-ink-100 flex items-center gap-4">
      <div className="w-11 h-11 rounded-lg flex items-center justify-center text-xl flex-shrink-0"
        style={{ background: `${color}18` }}>{icon}</div>
      <div>
        <p className="text-2xl font-serif font-bold text-ink-950">{value}</p>
        <p className="text-xs font-mono text-ink-400 uppercase tracking-wider">{label}</p>
      </div>
    </div>
  )
}

// ─── Modal ──────────────────────────────────────────────────────────────────
function Modal({ title, onClose, children }: { title: string; onClose: () => void; children: React.ReactNode }) {
  useEffect(() => {
    document.body.style.overflow = 'hidden'
    const esc = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose() }
    window.addEventListener('keydown', esc)
    return () => { document.body.style.overflow = ''; window.removeEventListener('keydown', esc) }
  }, [onClose])
  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
      className="fixed inset-0 z-[200] flex items-start justify-center pt-10 px-4 pb-10 overflow-y-auto"
      style={{ background: 'rgba(15,14,13,0.7)', backdropFilter: 'blur(8px)' }}
      onClick={e => { if (e.target === e.currentTarget) onClose() }}>
      <motion.div initial={{ opacity: 0, y: -24, scale: 0.97 }} animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, y: -24, scale: 0.97 }} transition={{ duration: 0.25 }}
        className="w-full max-w-3xl rounded-2xl shadow-2xl overflow-hidden my-auto"
        style={{ background: 'var(--cream)' }}>
        <div className="flex items-center justify-between px-6 py-4 border-b border-ink-100">
          <h2 className="font-serif font-bold text-xl text-ink-950">{title}</h2>
          <button onClick={onClose} className="w-8 h-8 rounded-full flex items-center justify-center text-ink-400 hover:text-ink-950 hover:bg-ink-100 transition-colors">
            <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
              <path d="M18 6L6 18M6 6l12 12" strokeLinecap="round" />
            </svg>
          </button>
        </div>
        <div className="px-6 py-6 max-h-[80vh] overflow-y-auto">{children}</div>
      </motion.div>
    </motion.div>
  )
}

// ─── Input helpers ──────────────────────────────────────────────────────────
const Field = ({ label, required, children }: { label: string; required?: boolean; children: React.ReactNode }) => (
  <div>
    <label className="block text-xs font-mono text-ink-400 uppercase tracking-wider mb-1.5">
      {label}{required && <span className="text-amber ml-1">*</span>}
    </label>
    {children}
  </div>
)
const Input = (props: React.InputHTMLAttributes<HTMLInputElement>) => (
  <input {...props} className={`w-full px-3 py-2.5 rounded-lg border border-ink-200 bg-white font-sans text-sm text-ink-900 placeholder-ink-300 focus:outline-none focus:border-amber transition-colors ${props.className || ''}`} />
)
const Textarea = (props: React.TextareaHTMLAttributes<HTMLTextAreaElement>) => (
  <textarea {...props} className={`w-full px-3 py-2.5 rounded-lg border border-ink-200 bg-white font-sans text-sm text-ink-900 placeholder-ink-300 focus:outline-none focus:border-amber transition-colors resize-none ${props.className || ''}`} />
)
const Select = (props: React.SelectHTMLAttributes<HTMLSelectElement> & { children: React.ReactNode }) => (
  <select {...props} className={`w-full px-3 py-2.5 rounded-lg border border-ink-200 bg-white font-sans text-sm text-ink-900 focus:outline-none focus:border-amber transition-colors ${props.className || ''}`} />
)

// ─── ARTICLES SECTION ──────────────────────────────────────────────────────
function ArticlesSection() {
  const [articles, setArticles] = useState<Article[]>([])
  const [authors, setAuthors] = useState<Author[]>([])
  const [categories, setCategories] = useState<Category[]>([])
  const [loading, setLoading] = useState(true)
  const [modal, setModal] = useState<'new' | 'edit' | null>(null)
  const [editing, setEditing] = useState<Partial<Article> | null>(null)
  const [saving, setSaving] = useState(false)
  const [search, setSearch] = useState('')

  const fetch = useCallback(async () => {
    const [aRes, auRes, cRes] = await Promise.all([
      supabase.from('articles').select('*, authors(name), categories(name)').order('created_at', { ascending: false }),
      supabase.from('authors').select('*').order('name'),
      supabase.from('categories').select('*').order('name'),
    ])
    setArticles(aRes.data || [])
    setAuthors(auRes.data || [])
    setCategories(cRes.data || [])
    setLoading(false)
  }, [])

  useEffect(() => { fetch() }, [fetch])

  const openNew = () => {
    setEditing({ title: '', slug: '', excerpt: '', content: '', status: 'draft', featured: false, reading_time: 5, tags: [], views_count: 0, likes_count: 0, claps_count: 0 })
    setModal('new')
  }
  const openEdit = (a: Article) => { setEditing({ ...a }); setModal('edit') }

  const handleTitleChange = (title: string) => {
    setEditing(prev => ({ ...prev, title, slug: prev?.slug || slugify(title) }))
  }

  const save = async () => {
    if (!editing?.title || !editing?.slug) return
    setSaving(true)
    const payload = {
      title: editing.title,
      slug: editing.slug,
      excerpt: editing.excerpt || '',
      content: editing.content || '',
      cover_image: editing.cover_image || null,
      author_id: (editing as any).author_id || null,
      category_id: (editing as any).category_id || null,
      status: editing.status || 'draft',
      featured: editing.featured || false,
      reading_time: editing.content ? readingTime(editing.content) : (editing.reading_time || 5),
      tags: Array.isArray(editing.tags) ? editing.tags : (typeof editing.tags === 'string' ? (editing.tags as string).split(',').map(t => t.trim()).filter(Boolean) : []),
    }
    if (modal === 'new') {
      await supabase.from('articles').insert({ ...payload, views_count: 0, likes_count: 0, claps_count: 0 })
    } else {
      await supabase.from('articles').update({ ...payload, updated_at: new Date().toISOString() }).eq('id', editing.id!)
    }
    setModal(null)
    setSaving(false)
    fetch()
  }

  const del = async (id: string) => {
    if (!confirm('Delete this article? This cannot be undone.')) return
    await supabase.from('articles').delete().eq('id', id)
    fetch()
  }

  const toggle = async (a: Article) => {
    await supabase.from('articles').update({ status: a.status === 'published' ? 'draft' : 'published' }).eq('id', a.id)
    fetch()
  }

  const filtered = articles.filter(a =>
    a.title.toLowerCase().includes(search.toLowerCase())
  )

  return (
    <div>
      <div className="flex flex-wrap items-center justify-between gap-4 mb-6">
        <h2 className="font-serif text-2xl font-bold text-ink-950">Articles <span className="text-ink-300 text-lg font-sans font-normal">({articles.length})</span></h2>
        <div className="flex items-center gap-3">
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search articles…"
            className="px-3 py-2 rounded-lg border border-ink-200 text-sm focus:outline-none focus:border-amber transition-colors w-48" />
          <button onClick={openNew}
            className="flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold text-white transition-all hover:scale-105"
            style={{ background: 'var(--amber)' }}>
            <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth={2.5} viewBox="0 0 24 24"><path d="M12 5v14M5 12h14" strokeLinecap="round" /></svg>
            New Article
          </button>
        </div>
      </div>

      <div className="bg-white rounded-xl border border-ink-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-ink-100" style={{ background: 'var(--parchment)' }}>
                {['Title', 'Author', 'Category', 'Status', 'Views', 'Featured', 'Actions'].map(h => (
                  <th key={h} className="text-left px-4 py-3 text-xs font-mono text-ink-400 uppercase tracking-wider whitespace-nowrap">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {loading ? (
                Array(5).fill(0).map((_, i) => (
                  <tr key={i} className="border-b border-ink-50">
                    {Array(7).fill(0).map((__, j) => (
                      <td key={j} className="px-4 py-3">
                        <div className="skeleton h-4 rounded" style={{ width: j === 0 ? '180px' : '60px', background: 'linear-gradient(90deg,#e8e0d6 25%,#f0e8de 50%,#e8e0d6 75%)', backgroundSize: '200% 100%' }} />
                      </td>
                    ))}
                  </tr>
                ))
              ) : filtered.length === 0 ? (
                <tr><td colSpan={7} className="text-center py-12 text-ink-400 font-sans">No articles found</td></tr>
              ) : filtered.map(a => (
                <tr key={a.id} className="border-b border-ink-50 hover:bg-parchment/30 transition-colors">
                  <td className="px-4 py-3">
                    <div>
                      <p className="font-medium text-ink-900 line-clamp-1 max-w-[220px]">{a.title}</p>
                      <p className="text-xs text-ink-400 font-mono">{a.slug}</p>
                    </div>
                  </td>
                  <td className="px-4 py-3 text-ink-600 whitespace-nowrap">{(a as any).authors?.name || '—'}</td>
                  <td className="px-4 py-3 text-ink-600 whitespace-nowrap">{(a as any).categories?.name || '—'}</td>
                  <td className="px-4 py-3">
                    <button onClick={() => toggle(a)}
                      className={`px-2.5 py-1 rounded-full text-xs font-mono font-bold uppercase tracking-wider transition-all ${a.status === 'published' ? 'bg-green-100 text-green-700' : 'bg-ink-100 text-ink-500'}`}>
                      {a.status}
                    </button>
                  </td>
                  <td className="px-4 py-3 font-mono text-ink-500 text-xs">{(a.views_count || 0).toLocaleString()}</td>
                  <td className="px-4 py-3 text-center">{a.featured ? '⭐' : '—'}</td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-1">
                      <a href={`/article/${a.slug}`} target="_blank" rel="noopener noreferrer"
                        className="p-1.5 rounded-md text-ink-400 hover:text-amber hover:bg-amber/10 transition-colors" title="View">
                        <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
                          <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6" /><polyline points="15 3 21 3 21 9" /><line x1="10" y1="14" x2="21" y2="3" />
                        </svg>
                      </a>
                      <button onClick={() => openEdit(a)}
                        className="p-1.5 rounded-md text-ink-400 hover:text-amber hover:bg-amber/10 transition-colors" title="Edit">
                        <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
                          <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" /><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" />
                        </svg>
                      </button>
                      <button onClick={() => del(a.id)}
                        className="p-1.5 rounded-md text-ink-400 hover:text-red-500 hover:bg-red-50 transition-colors" title="Delete">
                        <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
                          <polyline points="3 6 5 6 21 6" /><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2" />
                        </svg>
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Article modal */}
      <AnimatePresence>
        {modal && editing && (
          <Modal title={modal === 'new' ? 'New Article' : 'Edit Article'} onClose={() => setModal(null)}>
            <div className="space-y-5">
              <Field label="Title" required>
                <Input value={editing.title || ''} onChange={e => handleTitleChange(e.target.value)} placeholder="Article title" />
              </Field>
              <Field label="Slug" required>
                <Input value={editing.slug || ''} onChange={e => setEditing(p => ({ ...p, slug: e.target.value }))} placeholder="url-slug" />
              </Field>
              <div className="grid grid-cols-2 gap-4">
                <Field label="Author">
                  <Select value={(editing as any).author_id || ''} onChange={e => setEditing(p => ({ ...p, author_id: e.target.value || null }))}>
                    <option value="">No author</option>
                    {authors.map(a => <option key={a.id} value={a.id}>{a.name}</option>)}
                  </Select>
                </Field>
                <Field label="Category">
                  <Select value={(editing as any).category_id || ''} onChange={e => setEditing(p => ({ ...p, category_id: e.target.value || null }))}>
                    <option value="">No category</option>
                    {categories.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                  </Select>
                </Field>
              </div>
              <Field label="Cover Image URL">
                <Input value={editing.cover_image || ''} onChange={e => setEditing(p => ({ ...p, cover_image: e.target.value }))} placeholder="https://..." />
              </Field>
              <Field label="Excerpt">
                <Textarea value={editing.excerpt || ''} onChange={e => setEditing(p => ({ ...p, excerpt: e.target.value }))} rows={2} placeholder="Short description" />
              </Field>
              <Field label="Content" required>
                <Editor content={editing.content || ''} onChange={c => setEditing(p => ({ ...p, content: c }))} placeholder="Write your article…" minHeight="300px" />
              </Field>
              <Field label="Tags (comma separated)">
                <Input
                  value={Array.isArray(editing.tags) ? editing.tags.join(', ') : (editing.tags as any || '')}
                  onChange={e => setEditing(p => ({ ...p, tags: e.target.value.split(',').map(t => t.trim()).filter(Boolean) }))}
                  placeholder="tag1, tag2, tag3"
                />
              </Field>
              <div className="grid grid-cols-2 gap-4">
                <Field label="Status">
                  <Select value={editing.status || 'draft'} onChange={e => setEditing(p => ({ ...p, status: e.target.value as any }))}>
                    <option value="draft">Draft</option>
                    <option value="published">Published</option>
                  </Select>
                </Field>
                <Field label="Featured">
                  <div className="flex items-center h-10">
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input type="checkbox" checked={editing.featured || false} onChange={e => setEditing(p => ({ ...p, featured: e.target.checked }))}
                        className="w-4 h-4 rounded accent-amber" />
                      <span className="text-sm font-sans text-ink-700">Mark as featured</span>
                    </label>
                  </div>
                </Field>
              </div>
              <div className="flex justify-end gap-3 pt-2">
                <button onClick={() => setModal(null)} className="px-5 py-2.5 rounded-lg border border-ink-200 text-sm font-sans text-ink-600 hover:border-ink-400 transition-colors">Cancel</button>
                <button onClick={save} disabled={saving || !editing.title || !editing.slug}
                  className="flex items-center gap-2 px-6 py-2.5 rounded-lg text-sm font-bold text-white disabled:opacity-60 transition-all hover:scale-105"
                  style={{ background: 'var(--amber)' }}>
                  {saving ? <><div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />Saving…</> : 'Save Article'}
                </button>
              </div>
            </div>
          </Modal>
        )}
      </AnimatePresence>
    </div>
  )
}

// ─── AUTHORS SECTION ────────────────────────────────────────────────────────
function AuthorsSection() {
  const [authors, setAuthors] = useState<Author[]>([])
  const [loading, setLoading] = useState(true)
  const [modal, setModal] = useState(false)
  const [editing, setEditing] = useState<Partial<Author> | null>(null)
  const [saving, setSaving] = useState(false)

  const fetch = useCallback(async () => {
    const { data } = await supabase.from('authors').select('*').order('name')
    setAuthors(data || [])
    setLoading(false)
  }, [])

  useEffect(() => { fetch() }, [fetch])

  const openNew = () => { setEditing({ name: '', bio: '', avatar_url: '', role: '' }); setModal(true) }
  const openEdit = (a: Author) => { setEditing({ ...a }); setModal(true) }

  const save = async () => {
    if (!editing?.name) return
    setSaving(true)
    const payload = { name: editing.name, bio: editing.bio || null, avatar_url: editing.avatar_url || null, role: editing.role || null }
    if (editing.id) {
      await supabase.from('authors').update(payload).eq('id', editing.id)
    } else {
      await supabase.from('authors').insert(payload)
    }
    setSaving(false)
    setModal(false)
    fetch()
  }

  const del = async (id: string) => {
    if (!confirm('Delete this author?')) return
    await supabase.from('authors').delete().eq('id', id)
    fetch()
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h2 className="font-serif text-2xl font-bold text-ink-950">Authors <span className="text-ink-300 text-lg font-sans font-normal">({authors.length})</span></h2>
        <button onClick={openNew} className="flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold text-white" style={{ background: 'var(--amber)' }}>
          <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth={2.5} viewBox="0 0 24 24"><path d="M12 5v14M5 12h14" strokeLinecap="round" /></svg>
          New Author
        </button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {loading ? Array(3).fill(0).map((_, i) => (
          <div key={i} className="skeleton h-28 rounded-xl" style={{ background: 'linear-gradient(90deg,#e8e0d6 25%,#f0e8de 50%,#e8e0d6 75%)', backgroundSize: '200% 100%' }} />
        )) : authors.map(a => (
          <div key={a.id} className="bg-white rounded-xl p-4 border border-ink-100 flex items-start gap-3">
            <div className="w-12 h-12 rounded-full bg-parchment flex items-center justify-center flex-shrink-0 overflow-hidden">
              {a.avatar_url ? <img src={a.avatar_url} alt={a.name} className="w-full h-full object-cover" /> :
                <span className="font-serif font-bold text-amber text-lg">{a.name?.[0]}</span>}
            </div>
            <div className="flex-1 min-w-0">
              <p className="font-sans font-semibold text-sm text-ink-900">{a.name}</p>
              {a.role && <p className="text-xs font-mono text-amber">{a.role}</p>}
              {a.bio && <p className="text-xs text-ink-400 mt-1 line-clamp-2">{a.bio}</p>}
            </div>
            <div className="flex gap-1">
              <button onClick={() => openEdit(a)} className="p-1.5 rounded text-ink-400 hover:text-amber hover:bg-amber/10 transition-colors">
                <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" /><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" /></svg>
              </button>
              <button onClick={() => del(a.id)} className="p-1.5 rounded text-ink-400 hover:text-red-500 hover:bg-red-50 transition-colors">
                <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24"><polyline points="3 6 5 6 21 6" /><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2" /></svg>
              </button>
            </div>
          </div>
        ))}
      </div>

      <AnimatePresence>
        {modal && editing && (
          <Modal title={editing.id ? 'Edit Author' : 'New Author'} onClose={() => setModal(false)}>
            <div className="space-y-4">
              <Field label="Name" required><Input value={editing.name || ''} onChange={e => setEditing(p => ({ ...p, name: e.target.value }))} placeholder="Full name" /></Field>
              <Field label="Role / Title"><Input value={editing.role || ''} onChange={e => setEditing(p => ({ ...p, role: e.target.value }))} placeholder="e.g. Senior Editor" /></Field>
              <Field label="Avatar URL"><Input value={editing.avatar_url || ''} onChange={e => setEditing(p => ({ ...p, avatar_url: e.target.value }))} placeholder="https://..." /></Field>
              <Field label="Bio"><Textarea value={editing.bio || ''} onChange={e => setEditing(p => ({ ...p, bio: e.target.value }))} rows={3} placeholder="Short biography" /></Field>
              <div className="flex justify-end gap-3 pt-2">
                <button onClick={() => setModal(false)} className="px-5 py-2.5 rounded-lg border border-ink-200 text-sm font-sans text-ink-600">Cancel</button>
                <button onClick={save} disabled={saving || !editing.name} className="px-6 py-2.5 rounded-lg text-sm font-bold text-white disabled:opacity-60" style={{ background: 'var(--amber)' }}>
                  {saving ? 'Saving…' : 'Save Author'}
                </button>
              </div>
            </div>
          </Modal>
        )}
      </AnimatePresence>
    </div>
  )
}

// ─── CATEGORIES SECTION ─────────────────────────────────────────────────────
function CategoriesSection() {
  const [categories, setCategories] = useState<Category[]>([])
  const [modal, setModal] = useState(false)
  const [editing, setEditing] = useState<Partial<Category> | null>(null)
  const [saving, setSaving] = useState(false)

  const fetch = useCallback(async () => {
    const { data } = await supabase.from('categories').select('*').order('name')
    setCategories(data || [])
  }, [])
  useEffect(() => { fetch() }, [fetch])

  const save = async () => {
    if (!editing?.name || !editing?.slug) return
    setSaving(true)
    const payload = { name: editing.name, slug: editing.slug, description: editing.description || null, color: editing.color || null, icon: editing.icon || null }
    if (editing.id) await supabase.from('categories').update(payload).eq('id', editing.id)
    else await supabase.from('categories').insert(payload)
    setSaving(false); setModal(false); fetch()
  }

  const del = async (id: string) => {
    if (!confirm('Delete this category?')) return
    await supabase.from('categories').delete().eq('id', id)
    fetch()
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h2 className="font-serif text-2xl font-bold text-ink-950">Categories</h2>
        <button onClick={() => { setEditing({ name: '', slug: '', description: '', color: '#c8973a', icon: '' }); setModal(true) }}
          className="flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold text-white" style={{ background: 'var(--amber)' }}>
          <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth={2.5} viewBox="0 0 24 24"><path d="M12 5v14M5 12h14" strokeLinecap="round" /></svg>
          New Category
        </button>
      </div>

      <div className="bg-white rounded-xl border border-ink-100 overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-ink-100" style={{ background: 'var(--parchment)' }}>
              {['Icon', 'Name', 'Slug', 'Description', 'Actions'].map(h => (
                <th key={h} className="text-left px-4 py-3 text-xs font-mono text-ink-400 uppercase tracking-wider">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {categories.map(c => (
              <tr key={c.id} className="border-b border-ink-50 hover:bg-parchment/30 transition-colors">
                <td className="px-4 py-3 text-xl">{c.icon || '📂'}</td>
                <td className="px-4 py-3 font-semibold text-ink-900">{c.name}</td>
                <td className="px-4 py-3 font-mono text-xs text-ink-400">{c.slug}</td>
                <td className="px-4 py-3 text-ink-500 max-w-xs truncate">{c.description || '—'}</td>
                <td className="px-4 py-3">
                  <div className="flex gap-1">
                    <button onClick={() => { setEditing({ ...c }); setModal(true) }} className="p-1.5 rounded text-ink-400 hover:text-amber hover:bg-amber/10 transition-colors">
                      <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" /><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" /></svg>
                    </button>
                    <button onClick={() => del(c.id)} className="p-1.5 rounded text-ink-400 hover:text-red-500 hover:bg-red-50 transition-colors">
                      <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24"><polyline points="3 6 5 6 21 6" /><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2" /></svg>
                    </button>
                  </div>
                </td>
              </tr>
            ))}
            {categories.length === 0 && (
              <tr><td colSpan={5} className="text-center py-10 text-ink-400">No categories yet</td></tr>
            )}
          </tbody>
        </table>
      </div>

      <AnimatePresence>
        {modal && editing && (
          <Modal title={editing.id ? 'Edit Category' : 'New Category'} onClose={() => setModal(false)}>
            <div className="space-y-4">
              <Field label="Name" required><Input value={editing.name || ''} onChange={e => setEditing(p => ({ ...p, name: e.target.value, slug: p?.slug || slugify(e.target.value) }))} placeholder="Category name" /></Field>
              <Field label="Slug" required><Input value={editing.slug || ''} onChange={e => setEditing(p => ({ ...p, slug: e.target.value }))} placeholder="category-slug" /></Field>
              <div className="grid grid-cols-2 gap-4">
                <Field label="Icon (emoji)"><Input value={editing.icon || ''} onChange={e => setEditing(p => ({ ...p, icon: e.target.value }))} placeholder="📂" /></Field>
                <Field label="Color"><Input type="color" value={editing.color || '#c8973a'} onChange={e => setEditing(p => ({ ...p, color: e.target.value }))} /></Field>
              </div>
              <Field label="Description"><Textarea value={editing.description || ''} onChange={e => setEditing(p => ({ ...p, description: e.target.value }))} rows={2} /></Field>
              <div className="flex justify-end gap-3 pt-2">
                <button onClick={() => setModal(false)} className="px-5 py-2.5 rounded-lg border border-ink-200 text-sm font-sans text-ink-600">Cancel</button>
                <button onClick={save} disabled={saving || !editing.name || !editing.slug} className="px-6 py-2.5 rounded-lg text-sm font-bold text-white disabled:opacity-60" style={{ background: 'var(--amber)' }}>
                  {saving ? 'Saving…' : 'Save Category'}
                </button>
              </div>
            </div>
          </Modal>
        )}
      </AnimatePresence>
    </div>
  )
}

// ─── TAGS SECTION ───────────────────────────────────────────────────────────
function TagsSection() {
  const [tags, setTags] = useState<Tag[]>([])
  const [newTag, setNewTag] = useState('')
  const [saving, setSaving] = useState(false)

  const fetch = useCallback(async () => {
    const { data } = await supabase.from('tags').select('*').order('name')
    setTags(data || [])
  }, [])
  useEffect(() => { fetch() }, [fetch])

  const add = async () => {
    if (!newTag.trim()) return
    setSaving(true)
    await supabase.from('tags').insert({ name: newTag.trim(), slug: slugify(newTag.trim()) })
    setNewTag(''); setSaving(false); fetch()
  }

  const del = async (id: string) => {
    await supabase.from('tags').delete().eq('id', id)
    fetch()
  }

  return (
    <div>
      <h2 className="font-serif text-2xl font-bold text-ink-950 mb-6">Tags</h2>
      <div className="flex gap-3 mb-6">
        <Input value={newTag} onChange={e => setNewTag(e.target.value)}
          onKeyDown={e => { if (e.key === 'Enter') add() }}
          placeholder="Add a new tag…" className="max-w-xs" />
        <button onClick={add} disabled={saving || !newTag.trim()}
          className="px-5 py-2.5 rounded-lg text-sm font-bold text-white disabled:opacity-60" style={{ background: 'var(--amber)' }}>
          Add
        </button>
      </div>
      <div className="flex flex-wrap gap-2">
        {tags.map(t => (
          <div key={t.id} className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-white border border-ink-200">
            <span className="font-mono text-sm text-ink-700">#{t.name}</span>
            <button onClick={() => del(t.id)} className="text-ink-300 hover:text-red-400 transition-colors">
              <svg className="w-3 h-3" fill="none" stroke="currentColor" strokeWidth={2.5} viewBox="0 0 24 24"><path d="M18 6L6 18M6 6l12 12" strokeLinecap="round" /></svg>
            </button>
          </div>
        ))}
        {tags.length === 0 && <p className="text-ink-400 text-sm font-sans">No tags yet. Add some above.</p>}
      </div>
    </div>
  )
}

// ─── SUBMISSIONS SECTION ─────────────────────────────────────────────────────
function SubmissionsSection() {
  const [submissions, setSubmissions] = useState<Submission[]>([])
  const [loading, setLoading] = useState(true)
  const [selected, setSelected] = useState<Submission | null>(null)
  const [filter, setFilter] = useState<'all' | 'pending' | 'approved' | 'rejected'>('pending')

  const fetch = useCallback(async () => {
    const query = supabase.from('submissions').select('*').order('created_at', { ascending: false })
    const { data } = filter === 'all' ? await query : await query.eq('status', filter)
    setSubmissions(data || [])
    setLoading(false)
  }, [filter])

  useEffect(() => { fetch() }, [fetch])

  useEffect(() => {
    const channel = supabase.channel('submissions-realtime')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'submissions' }, fetch)
      .subscribe()
    return () => { supabase.removeChannel(channel) }
  }, [fetch])

  const updateStatus = async (id: string, status: 'approved' | 'rejected') => {
    await supabase.from('submissions').update({ status }).eq('id', id)
    setSelected(null)
    fetch()
  }

  const del = async (id: string) => {
    if (!confirm('Delete this submission?')) return
    await supabase.from('submissions').delete().eq('id', id)
    setSelected(null)
    fetch()
  }

  const statusColor: Record<string, string> = {
    pending: 'bg-yellow-100 text-yellow-700',
    approved: 'bg-green-100 text-green-700',
    rejected: 'bg-red-100 text-red-700',
  }

  return (
    <div>
      <div className="flex flex-wrap items-center justify-between gap-4 mb-6">
        <h2 className="font-serif text-2xl font-bold text-ink-950">Submissions</h2>
        <div className="flex gap-2">
          {(['all', 'pending', 'approved', 'rejected'] as const).map(f => (
            <button key={f} onClick={() => setFilter(f)}
              className={`px-3 py-1.5 rounded-lg text-xs font-mono uppercase tracking-wider transition-colors ${filter === f ? 'text-white' : 'border border-ink-200 text-ink-500 hover:border-amber hover:text-amber'}`}
              style={filter === f ? { background: 'var(--amber)' } : {}}>
              {f}
            </button>
          ))}
        </div>
      </div>

      <div className="bg-white rounded-xl border border-ink-100 overflow-hidden">
        {loading ? (
          <div className="p-8 text-center text-ink-400">Loading…</div>
        ) : submissions.length === 0 ? (
          <div className="p-12 text-center">
            <p className="text-3xl mb-3">📭</p>
            <p className="font-sans text-ink-400">No {filter === 'all' ? '' : filter} submissions</p>
          </div>
        ) : (
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-ink-100" style={{ background: 'var(--parchment)' }}>
                {['Title', 'Author', 'Status', 'Submitted', 'Actions'].map(h => (
                  <th key={h} className="text-left px-4 py-3 text-xs font-mono text-ink-400 uppercase tracking-wider">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {submissions.map(s => (
                <tr key={s.id} className="border-b border-ink-50 hover:bg-parchment/30 transition-colors">
                  <td className="px-4 py-3">
                    <button onClick={() => setSelected(s)} className="font-medium text-ink-900 hover:text-amber transition-colors text-left line-clamp-1 max-w-[200px]">
                      {s.title}
                    </button>
                  </td>
                  <td className="px-4 py-3">
                    <div>
                      <p className="text-ink-700 font-medium">{s.author_name}</p>
                      <p className="text-xs text-ink-400">{s.author_email}</p>
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <span className={`px-2.5 py-1 rounded-full text-xs font-mono font-bold uppercase tracking-wider ${statusColor[s.status]}`}>{s.status}</span>
                  </td>
                  <td className="px-4 py-3 text-xs text-ink-400 whitespace-nowrap">
                    {new Date(s.created_at).toLocaleDateString()}
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex gap-1">
                      <button onClick={() => setSelected(s)} className="p-1.5 rounded text-ink-400 hover:text-amber hover:bg-amber/10 transition-colors" title="View">
                        <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" /><circle cx="12" cy="12" r="3" /></svg>
                      </button>
                      {s.status === 'pending' && (
                        <>
                          <button onClick={() => updateStatus(s.id, 'approved')} className="p-1.5 rounded text-ink-400 hover:text-green-600 hover:bg-green-50 transition-colors" title="Approve">
                            <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12" /></svg>
                          </button>
                          <button onClick={() => updateStatus(s.id, 'rejected')} className="p-1.5 rounded text-ink-400 hover:text-red-500 hover:bg-red-50 transition-colors" title="Reject">
                            <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24"><path d="M18 6L6 18M6 6l12 12" strokeLinecap="round" /></svg>
                          </button>
                        </>
                      )}
                      <button onClick={() => del(s.id)} className="p-1.5 rounded text-ink-400 hover:text-red-500 hover:bg-red-50 transition-colors" title="Delete">
                        <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24"><polyline points="3 6 5 6 21 6" /><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2" /></svg>
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {/* Submission detail modal */}
      <AnimatePresence>
        {selected && (
          <Modal title="Submission Review" onClose={() => setSelected(null)}>
            <div className="space-y-4">
              <div className="flex items-start justify-between gap-4">
                <div>
                  <h3 className="font-serif text-xl font-bold text-ink-950">{selected.title}</h3>
                  <div className="flex items-center gap-2 mt-1 text-sm text-ink-400">
                    <span>By {selected.author_name}</span>
                    <span>·</span>
                    <span>{selected.author_email}</span>
                    <span>·</span>
                    <span className={`px-2 py-0.5 rounded-full text-xs font-mono font-bold uppercase ${statusColor[selected.status]}`}>{selected.status}</span>
                  </div>
                </div>
              </div>
              {selected.tags?.length > 0 && (
                <div className="flex flex-wrap gap-2">
                  {selected.tags.map(t => (
                    <span key={t} className="px-2.5 py-1 rounded-full text-xs font-mono bg-parchment text-ink-600">#{t}</span>
                  ))}
                </div>
              )}
              <div className="bg-parchment rounded-xl p-4 max-h-[400px] overflow-y-auto">
                <div className="article-content text-sm" dangerouslySetInnerHTML={{ __html: selected.content }} />
              </div>
              <div className="flex items-center gap-3 pt-2">
                {selected.status === 'pending' && (
                  <>
                    <button onClick={() => updateStatus(selected.id, 'approved')}
                      className="flex items-center gap-2 px-5 py-2.5 rounded-lg text-sm font-bold text-white bg-green-600 hover:bg-green-700 transition-colors">
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth={2.5} viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12" /></svg>
                      Approve
                    </button>
                    <button onClick={() => updateStatus(selected.id, 'rejected')}
                      className="flex items-center gap-2 px-5 py-2.5 rounded-lg text-sm font-bold text-white bg-red-500 hover:bg-red-600 transition-colors">
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24"><path d="M18 6L6 18M6 6l12 12" strokeLinecap="round" /></svg>
                      Reject
                    </button>
                  </>
                )}
                <button onClick={() => del(selected.id)}
                  className="flex items-center gap-2 px-5 py-2.5 rounded-lg text-sm font-bold text-red-500 border border-red-200 hover:bg-red-50 transition-colors ml-auto">
                  Delete
                </button>
              </div>
            </div>
          </Modal>
        )}
      </AnimatePresence>
    </div>
  )
}

// ─── ACHIEVEMENTS SECTION ───────────────────────────────────────────────────
function AchievementsSection() {
  const [items, setItems] = useState<Achievement[]>([])
  const [modal, setModal] = useState(false)
  const [editing, setEditing] = useState<Partial<Achievement> | null>(null)
  const [saving, setSaving] = useState(false)

  const fetch = useCallback(async () => {
    const { data } = await supabase.from('achievements').select('*').order('created_at', { ascending: false })
    setItems(data || [])
  }, [])
  useEffect(() => { fetch() }, [fetch])

  const save = async () => {
    if (!editing?.title) return
    setSaving(true)
    const payload = { title: editing.title, description: editing.description || null, icon: editing.icon || null, color: editing.color || null }
    if (editing.id) await supabase.from('achievements').update(payload).eq('id', editing.id)
    else await supabase.from('achievements').insert(payload)
    setSaving(false); setModal(false); fetch()
  }

  const del = async (id: string) => {
    if (!confirm('Delete?')) return
    await supabase.from('achievements').delete().eq('id', id)
    fetch()
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h2 className="font-serif text-2xl font-bold text-ink-950">Achievements</h2>
        <button onClick={() => { setEditing({ title: '', description: '', icon: '🏆', color: '#c8973a' }); setModal(true) }}
          className="flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold text-white" style={{ background: 'var(--amber)' }}>
          <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth={2.5} viewBox="0 0 24 24"><path d="M12 5v14M5 12h14" strokeLinecap="round" /></svg>
          New Achievement
        </button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {items.map(item => (
          <div key={item.id} className="bg-white rounded-xl p-4 border border-ink-100 flex items-start gap-3">
            <div className="w-11 h-11 rounded-xl flex items-center justify-center text-2xl flex-shrink-0"
              style={{ background: item.color ? `${item.color}20` : 'var(--parchment)' }}>
              {item.icon || '🏆'}
            </div>
            <div className="flex-1">
              <p className="font-semibold text-sm text-ink-900">{item.title}</p>
              {item.description && <p className="text-xs text-ink-400 mt-0.5 line-clamp-2">{item.description}</p>}
            </div>
            <div className="flex gap-1">
              <button onClick={() => { setEditing({ ...item }); setModal(true) }} className="p-1.5 rounded text-ink-400 hover:text-amber hover:bg-amber/10">
                <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" /><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" /></svg>
              </button>
              <button onClick={() => del(item.id)} className="p-1.5 rounded text-ink-400 hover:text-red-500 hover:bg-red-50">
                <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24"><polyline points="3 6 5 6 21 6" /><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2" /></svg>
              </button>
            </div>
          </div>
        ))}
        {items.length === 0 && <p className="col-span-3 text-ink-400 text-sm font-sans py-8">No achievements yet.</p>}
      </div>

      <AnimatePresence>
        {modal && editing && (
          <Modal title={editing.id ? 'Edit Achievement' : 'New Achievement'} onClose={() => setModal(false)}>
            <div className="space-y-4">
              <Field label="Title" required><Input value={editing.title || ''} onChange={e => setEditing(p => ({ ...p, title: e.target.value }))} /></Field>
              <div className="grid grid-cols-2 gap-4">
                <Field label="Icon (emoji)"><Input value={editing.icon || ''} onChange={e => setEditing(p => ({ ...p, icon: e.target.value }))} placeholder="🏆" /></Field>
                <Field label="Color"><Input type="color" value={editing.color || '#c8973a'} onChange={e => setEditing(p => ({ ...p, color: e.target.value }))} /></Field>
              </div>
              <Field label="Description"><Textarea value={editing.description || ''} onChange={e => setEditing(p => ({ ...p, description: e.target.value }))} rows={2} /></Field>
              <div className="flex justify-end gap-3 pt-2">
                <button onClick={() => setModal(false)} className="px-5 py-2.5 rounded-lg border border-ink-200 text-sm font-sans text-ink-600">Cancel</button>
                <button onClick={save} disabled={saving || !editing.title} className="px-6 py-2.5 rounded-lg text-sm font-bold text-white disabled:opacity-60" style={{ background: 'var(--amber)' }}>
                  {saving ? 'Saving…' : 'Save'}
                </button>
              </div>
            </div>
          </Modal>
        )}
      </AnimatePresence>
    </div>
  )
}

// ─── ANNOUNCEMENTS SECTION ──────────────────────────────────────────────────
function AnnouncementsSection() {
  const [items, setItems] = useState<Announcement[]>([])
  const [modal, setModal] = useState(false)
  const [editing, setEditing] = useState<Partial<Announcement> | null>(null)
  const [saving, setSaving] = useState(false)

  const fetch = useCallback(async () => {
    const { data } = await supabase.from('announcements').select('*').order('created_at', { ascending: false })
    setItems(data || [])
  }, [])
  useEffect(() => { fetch() }, [fetch])

  const save = async () => {
    if (!editing?.message) return
    setSaving(true)
    const payload = { message: editing.message, active: editing.active ?? true, link: editing.link || null, link_text: editing.link_text || null }
    if (editing.id) await supabase.from('announcements').update(payload).eq('id', editing.id)
    else await supabase.from('announcements').insert(payload)
    setSaving(false); setModal(false); fetch()
  }

  const toggle = async (id: string, active: boolean) => {
    await supabase.from('announcements').update({ active: !active }).eq('id', id)
    fetch()
  }

  const del = async (id: string) => {
    if (!confirm('Delete?')) return
    await supabase.from('announcements').delete().eq('id', id)
    fetch()
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h2 className="font-serif text-2xl font-bold text-ink-950">Announcements</h2>
        <button onClick={() => { setEditing({ message: '', active: true, link: '', link_text: '' }); setModal(true) }}
          className="flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold text-white" style={{ background: 'var(--amber)' }}>
          <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth={2.5} viewBox="0 0 24 24"><path d="M12 5v14M5 12h14" strokeLinecap="round" /></svg>
          New Banner
        </button>
      </div>

      <div className="space-y-3">
        {items.map(item => (
          <div key={item.id} className={`bg-white rounded-xl p-4 border flex items-start gap-4 ${item.active ? 'border-amber/40' : 'border-ink-100'}`}>
            <span className="text-xl mt-0.5">📣</span>
            <div className="flex-1">
              <p className="font-sans text-sm text-ink-800">{item.message}</p>
              {item.link && <a href={item.link} className="text-xs text-amber mt-1 block hover:underline">{item.link_text || item.link}</a>}
            </div>
            <div className="flex items-center gap-2">
              <button onClick={() => toggle(item.id, item.active)}
                className={`px-2.5 py-1 rounded-full text-xs font-mono font-bold uppercase tracking-wider ${item.active ? 'bg-green-100 text-green-700' : 'bg-ink-100 text-ink-500'}`}>
                {item.active ? 'Live' : 'Off'}
              </button>
              <button onClick={() => { setEditing({ ...item }); setModal(true) }} className="p-1.5 rounded text-ink-400 hover:text-amber hover:bg-amber/10">
                <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" /><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" /></svg>
              </button>
              <button onClick={() => del(item.id)} className="p-1.5 rounded text-ink-400 hover:text-red-500 hover:bg-red-50">
                <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24"><polyline points="3 6 5 6 21 6" /><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2" /></svg>
              </button>
            </div>
          </div>
        ))}
        {items.length === 0 && <p className="text-ink-400 text-sm font-sans py-8 text-center">No announcements yet.</p>}
      </div>

      <AnimatePresence>
        {modal && editing && (
          <Modal title={editing.id ? 'Edit Announcement' : 'New Announcement'} onClose={() => setModal(false)}>
            <div className="space-y-4">
              <Field label="Message" required>
                <Textarea value={editing.message || ''} onChange={e => setEditing(p => ({ ...p, message: e.target.value }))} rows={3} placeholder="Announcement text…" />
              </Field>
              <div className="grid grid-cols-2 gap-4">
                <Field label="Link URL"><Input value={editing.link || ''} onChange={e => setEditing(p => ({ ...p, link: e.target.value }))} placeholder="https://..." /></Field>
                <Field label="Link Text"><Input value={editing.link_text || ''} onChange={e => setEditing(p => ({ ...p, link_text: e.target.value }))} placeholder="Learn more" /></Field>
              </div>
              <Field label="Status">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input type="checkbox" checked={editing.active ?? true} onChange={e => setEditing(p => ({ ...p, active: e.target.checked }))} className="w-4 h-4 accent-amber" />
                  <span className="text-sm font-sans text-ink-700">Active (show on site)</span>
                </label>
              </Field>
              <div className="flex justify-end gap-3 pt-2">
                <button onClick={() => setModal(false)} className="px-5 py-2.5 rounded-lg border border-ink-200 text-sm font-sans text-ink-600">Cancel</button>
                <button onClick={save} disabled={saving || !editing.message} className="px-6 py-2.5 rounded-lg text-sm font-bold text-white disabled:opacity-60" style={{ background: 'var(--amber)' }}>
                  {saving ? 'Saving…' : 'Save'}
                </button>
              </div>
            </div>
          </Modal>
        )}
      </AnimatePresence>
    </div>
  )
}

// ─── SETTINGS SECTION ───────────────────────────────────────────────────────
function SettingsSection() {
  const [settings, setSettings] = useState<Record<string, string>>({})
  const [saving, setSaving] = useState<string | null>(null)
  const [saved, setSaved] = useState<string | null>(null)

  const fetch = useCallback(async () => {
    const { data } = await supabase.from('settings').select('*')
    if (data) {
      const map: Record<string, string> = {}
      data.forEach((s: Setting) => { map[s.key] = s.value || '' })
      setSettings(map)
    }
  }, [])
  useEffect(() => { fetch() }, [fetch])

  const saveSetting = async (key: string, value: string) => {
    setSaving(key)
    const { data } = await supabase.from('settings').select('id').eq('key', key).single()
    if (data) {
      await supabase.from('settings').update({ value, updated_at: new Date().toISOString() }).eq('key', key)
    } else {
      await supabase.from('settings').insert({ key, value })
    }
    setSaving(null)
    setSaved(key)
    setTimeout(() => setSaved(null), 2000)
  }

  const settingFields = [
    { key: 'site_description', label: 'Site Description', type: 'textarea', placeholder: 'Describe your platform…' },
    { key: 'help_email', label: 'Help / Contact Email', type: 'input', placeholder: 'help@yoursite.com' },
    { key: 'terms', label: 'Terms of Service Content (HTML)', type: 'textarea-lg', placeholder: '<h2>Terms of Service</h2><p>…</p>' },
  ]

  return (
    <div>
      <h2 className="font-serif text-2xl font-bold text-ink-950 mb-6">Settings</h2>
      <div className="space-y-6">
        {settingFields.map(field => (
          <div key={field.key} className="bg-white rounded-xl border border-ink-100 p-5">
            <label className="block text-xs font-mono text-ink-400 uppercase tracking-wider mb-3">{field.label}</label>
            {field.type === 'input' ? (
              <Input value={settings[field.key] || ''} onChange={e => setSettings(p => ({ ...p, [field.key]: e.target.value }))} placeholder={field.placeholder} />
            ) : field.type === 'textarea-lg' ? (
              <Textarea value={settings[field.key] || ''} onChange={e => setSettings(p => ({ ...p, [field.key]: e.target.value }))} rows={12} placeholder={field.placeholder} className="font-mono text-xs" />
            ) : (
              <Textarea value={settings[field.key] || ''} onChange={e => setSettings(p => ({ ...p, [field.key]: e.target.value }))} rows={3} placeholder={field.placeholder} />
            )}
            <div className="flex items-center justify-end mt-3 gap-3">
              {saved === field.key && <span className="text-green-600 text-xs font-mono">✓ Saved</span>}
              <button onClick={() => saveSetting(field.key, settings[field.key] || '')}
                disabled={saving === field.key}
                className="px-4 py-2 rounded-lg text-xs font-bold text-white disabled:opacity-60 transition-all hover:scale-105"
                style={{ background: 'var(--amber)' }}>
                {saving === field.key ? 'Saving…' : 'Save'}
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

// ─── DASHBOARD ──────────────────────────────────────────────────────────────
function Dashboard() {
  const [stats, setStats] = useState({ articles: 0, published: 0, views: 0, submissions: 0, pending: 0, authors: 0 })
  const [recentArticles, setRecentArticles] = useState<Article[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetch = async () => {
      const [artRes, subRes, auRes] = await Promise.all([
        supabase.from('articles').select('id, status, views_count'),
        supabase.from('submissions').select('id, status'),
        supabase.from('authors').select('id'),
      ])
      const articles = artRes.data || []
      const submissions = subRes.data || []
      setStats({
        articles: articles.length,
        published: articles.filter(a => a.status === 'published').length,
        views: articles.reduce((sum, a) => sum + (a.views_count || 0), 0),
        submissions: submissions.length,
        pending: submissions.filter(s => s.status === 'pending').length,
        authors: (auRes.data || []).length,
      })
      const { data: recent } = await supabase.from('articles').select('*, authors(name)').order('created_at', { ascending: false }).limit(5)
      setRecentArticles(recent || [])
      setLoading(false)
    }
    fetch()
  }, [])

  return (
    <div>
      <div className="mb-8">
        <h2 className="font-serif text-2xl font-bold text-ink-950">Dashboard</h2>
        <p className="font-sans text-sm text-ink-400 mt-1">Welcome back, Manmada</p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-10">
        {loading ? Array(6).fill(0).map((_, i) => (
          <div key={i} className="skeleton h-24 rounded-xl" style={{ background: 'linear-gradient(90deg,#e8e0d6 25%,#f0e8de 50%,#e8e0d6 75%)', backgroundSize: '200% 100%' }} />
        )) : (
          <>
            <StatCard label="Total Articles" value={stats.articles} icon="📝" color="#c8973a" />
            <StatCard label="Published" value={stats.published} icon="✅" color="#22c55e" />
            <StatCard label="Total Views" value={stats.views.toLocaleString()} icon="👁️" color="#3b82f6" />
            <StatCard label="Submissions" value={stats.submissions} icon="📬" color="#8b5cf6" />
            <StatCard label="Pending" value={stats.pending} icon="⏳" color="#f59e0b" />
            <StatCard label="Authors" value={stats.authors} icon="✍️" color="#ec4899" />
          </>
        )}
      </div>

      <div className="bg-white rounded-xl border border-ink-100 overflow-hidden">
        <div className="px-5 py-4 border-b border-ink-100">
          <h3 className="font-serif font-bold text-lg text-ink-950">Recent Articles</h3>
        </div>
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-ink-100" style={{ background: 'var(--parchment)' }}>
              {['Title', 'Author', 'Status', 'Views', 'Date'].map(h => (
                <th key={h} className="text-left px-4 py-3 text-xs font-mono text-ink-400 uppercase tracking-wider">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {loading ? (
              Array(5).fill(0).map((_, i) => (
                <tr key={i} className="border-b border-ink-50">
                  {Array(5).fill(0).map((__, j) => (
                    <td key={j} className="px-4 py-3">
                      <div className="skeleton h-4 rounded" style={{ width: j === 0 ? '180px' : '80px', background: 'linear-gradient(90deg,#e8e0d6 25%,#f0e8de 50%,#e8e0d6 75%)', backgroundSize: '200% 100%' }} />
                    </td>
                  ))}
                </tr>
              ))
            ) : recentArticles.map(a => (
              <tr key={a.id} className="border-b border-ink-50 hover:bg-parchment/20">
                <td className="px-4 py-3">
                  <a href={`/article/${a.slug}`} target="_blank" className="font-medium text-ink-900 hover:text-amber transition-colors line-clamp-1 max-w-[200px] block">{a.title}</a>
                </td>
                <td className="px-4 py-3 text-ink-600">{(a as any).authors?.name || '—'}</td>
                <td className="px-4 py-3">
                  <span className={`px-2 py-0.5 rounded-full text-xs font-mono font-bold uppercase ${a.status === 'published' ? 'bg-green-100 text-green-700' : 'bg-ink-100 text-ink-500'}`}>{a.status}</span>
                </td>
                <td className="px-4 py-3 font-mono text-xs text-ink-400">{(a.views_count || 0).toLocaleString()}</td>
                <td className="px-4 py-3 text-xs text-ink-400 whitespace-nowrap">{new Date(a.created_at).toLocaleDateString()}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}

// ─── MAIN ADMIN PAGE ─────────────────────────────────────────────────────────
type Section = 'dashboard' | 'articles' | 'authors' | 'categories' | 'tags' | 'submissions' | 'achievements' | 'announcements' | 'settings'

const navItems: { key: Section; label: string; icon: string }[] = [
  { key: 'dashboard', label: 'Dashboard', icon: '📊' },
  { key: 'articles', label: 'Articles', icon: '📝' },
  { key: 'authors', label: 'Authors', icon: '✍️' },
  { key: 'categories', label: 'Categories', icon: '📂' },
  { key: 'tags', label: 'Tags', icon: '🏷️' },
  { key: 'submissions', label: 'Submissions', icon: '📬' },
  { key: 'achievements', label: 'Achievements', icon: '🏆' },
  { key: 'announcements', label: 'Announcements', icon: '📣' },
  { key: 'settings', label: 'Settings', icon: '⚙️' },
]

export default function AdminPage() {
  const [authed, setAuthed] = useState(false)
  const [checking, setChecking] = useState(true)
  const [section, setSection] = useState<Section>('dashboard')
  const [sidebarOpen, setSidebarOpen] = useState(false)

  useEffect(() => {
    if (sessionStorage.getItem('cc_admin') === '1') setAuthed(true)
    setChecking(false)
  }, [])

  const logout = () => {
    sessionStorage.removeItem('cc_admin')
    setAuthed(false)
  }

  if (checking) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ background: 'var(--cream)' }}>
        <div className="w-8 h-8 rounded-full border-2 border-amber border-t-transparent animate-spin" />
      </div>
    )
  }

  if (!authed) return <LoginScreen onLogin={() => setAuthed(true)} />

  const sectionComponents: Record<Section, React.ReactNode> = {
    dashboard: <Dashboard />,
    articles: <ArticlesSection />,
    authors: <AuthorsSection />,
    categories: <CategoriesSection />,
    tags: <TagsSection />,
    submissions: <SubmissionsSection />,
    achievements: <AchievementsSection />,
    announcements: <AnnouncementsSection />,
    settings: <SettingsSection />,
  }

  return (
    <div className="min-h-screen flex" style={{ background: 'var(--parchment)' }}>
      {/* Sidebar */}
      <>
        {/* Mobile overlay */}
        <AnimatePresence>
          {sidebarOpen && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              className="fixed inset-0 z-40 bg-black/40 md:hidden"
              onClick={() => setSidebarOpen(false)} />
          )}
        </AnimatePresence>

        <motion.aside
          initial={false}
          animate={{ x: sidebarOpen ? 0 : '-100%' }}
          className="fixed inset-y-0 left-0 z-50 w-56 flex flex-col border-r border-ink-100 md:static md:translate-x-0 md:flex"
          style={{ background: 'white' }}
        >
          {/* Logo */}
          <div className="px-4 py-5 border-b border-ink-100">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-md flex items-center justify-center" style={{ background: 'var(--amber)' }}>
                <span className="font-serif text-white font-bold text-sm">C</span>
              </div>
              <div>
                <span className="font-serif text-sm font-bold text-ink-950 block leading-none">Context Corner</span>
                <span className="font-mono text-xs text-amber">Admin</span>
              </div>
            </div>
          </div>

          {/* Nav */}
          <nav className="flex-1 px-3 py-4 overflow-y-auto space-y-0.5">
            {navItems.map(item => (
              <button key={item.key} onClick={() => { setSection(item.key); setSidebarOpen(false) }}
                className={`admin-nav-link w-full ${section === item.key ? 'active' : ''}`}>
                <span className="text-base">{item.icon}</span>
                <span>{item.label}</span>
              </button>
            ))}
          </nav>

          {/* Footer */}
          <div className="px-4 py-4 border-t border-ink-100 space-y-2">
            <a href="/" target="_blank" rel="noopener noreferrer"
              className="flex items-center gap-2 px-3 py-2 rounded-lg text-xs font-sans text-ink-400 hover:text-amber hover:bg-amber/10 transition-colors">
              <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
                <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6" /><polyline points="15 3 21 3 21 9" /><line x1="10" y1="14" x2="21" y2="3" />
              </svg>
              View Site
            </a>
            <button onClick={logout}
              className="flex items-center gap-2 px-3 py-2 rounded-lg text-xs font-sans text-ink-400 hover:text-red-500 hover:bg-red-50 transition-colors w-full">
              <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
                <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" /><polyline points="16 17 21 12 16 7" /><line x1="21" y1="12" x2="9" y2="12" />
              </svg>
              Sign Out
            </button>
          </div>
        </motion.aside>
      </>

      {/* Main */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Top bar */}
        <header className="bg-white border-b border-ink-100 px-4 md:px-6 py-4 flex items-center gap-4">
          <button onClick={() => setSidebarOpen(true)} className="md:hidden p-2 rounded-lg text-ink-400 hover:text-ink-950 hover:bg-ink-100 transition-colors">
            <svg className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
              <line x1="3" y1="12" x2="21" y2="12" /><line x1="3" y1="6" x2="21" y2="6" /><line x1="3" y1="18" x2="21" y2="18" />
            </svg>
          </button>
          <div>
            <h1 className="font-serif font-bold text-lg text-ink-950">
              {navItems.find(n => n.key === section)?.label}
            </h1>
          </div>
        </header>

        {/* Content */}
        <main className="flex-1 p-4 md:p-8 overflow-y-auto">
          <AnimatePresence mode="wait">
            <motion.div key={section}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.2 }}>
              {sectionComponents[section]}
            </motion.div>
          </AnimatePresence>
        </main>
      </div>
    </div>
  )
}
