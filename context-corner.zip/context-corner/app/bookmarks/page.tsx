'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import Navbar from '@/components/Navbar'
import ArticleCard from '@/components/ArticleCard'
import { supabase } from '@/lib/supabase'
import type { Article } from '@/lib/supabase'

export default function BookmarksPage() {
  const [articles, setArticles] = useState<Article[]>([])
  const [loading, setLoading] = useState(true)

  const fetchBookmarks = async () => {
    const ids: string[] = JSON.parse(localStorage.getItem('cc_bookmarks') || '[]')
    if (ids.length === 0) { setLoading(false); return }

    const { data } = await supabase
      .from('articles')
      .select('*, authors(*), categories(*)')
      .in('id', ids)
      .eq('status', 'published')

    // Remove bookmarks for deleted articles
    if (data) {
      const existingIds = data.map(a => a.id)
      const validIds = ids.filter(id => existingIds.includes(id))
      localStorage.setItem('cc_bookmarks', JSON.stringify(validIds))
      setArticles(data)
    } else {
      localStorage.removeItem('cc_bookmarks')
    }
    setLoading(false)
  }

  useEffect(() => {
    fetchBookmarks()
    window.addEventListener('bookmarks-changed', fetchBookmarks)
    return () => window.removeEventListener('bookmarks-changed', fetchBookmarks)
  }, [])

  return (
    <div className="min-h-screen" style={{ background: 'var(--cream)' }}>
      <Navbar />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 pt-28 pb-20">
        <div className="flex items-center gap-2 text-xs font-mono text-ink-400 mb-8">
          <Link href="/" className="hover:text-amber transition-colors">Home</Link>
          <span>/</span>
          <span className="text-ink-600">Bookmarks</span>
        </div>

        <div className="flex items-center justify-between mb-10">
          <div>
            <p className="text-xs font-mono text-amber uppercase tracking-widest mb-2">Saved</p>
            <h1 className="font-serif font-bold text-4xl text-ink-950">Your Bookmarks</h1>
          </div>
          {articles.length > 0 && (
            <button onClick={() => {
              localStorage.removeItem('cc_bookmarks')
              setArticles([])
            }}
              className="text-sm font-sans text-ink-400 hover:text-red-400 transition-colors">
              Clear all
            </button>
          )}
        </div>

        {loading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {Array(3).fill(0).map((_, i) => (
              <div key={i} className="h-64 rounded-xl skeleton" style={{ background: 'linear-gradient(90deg,#e8e0d6 25%,#f0e8de 50%,#e8e0d6 75%)', backgroundSize: '200% 100%' }} />
            ))}
          </div>
        ) : articles.length === 0 ? (
          <div className="text-center py-24">
            <p className="text-6xl mb-4">🔖</p>
            <h2 className="font-serif text-2xl font-bold text-ink-800 mb-3">No bookmarks yet</h2>
            <p className="font-sans text-ink-400 mb-6 max-w-sm mx-auto">
              Save articles you want to read later by clicking the bookmark icon.
            </p>
            <Link href="/" className="inline-flex items-center gap-2 px-6 py-2.5 rounded-full text-sm font-medium text-white transition-all hover:scale-105"
              style={{ background: 'var(--amber)' }}>
              Explore articles
            </Link>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {articles.map((article, i) => (
              <ArticleCard key={article.id} article={article} variant="default" index={i} />
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
