import type { Metadata } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: 'Context Corner — Premium Editorial Platform',
  description: 'A premium editorial platform for thoughtful perspectives, deep-dives, and cultural commentary.',
  openGraph: {
    title: 'Context Corner',
    description: 'Premium editorial platform',
    type: 'website',
  },
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
      </head>
      <body className="grain">
        {children}
      </body>
    </html>
  )
}
