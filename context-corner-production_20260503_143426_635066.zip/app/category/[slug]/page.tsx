import Navbar from '@/components/Navbar'
import ArticleCard from '@/components/ArticleCard'
import { supabase } from '@/lib/supabase'

export default async function CategoryPage({ params }: { params: { slug: string } }) {
  const { data: category } = await supabase.from('categories').select('*').eq('slug', params.slug).single()
  const { data: articles } = await supabase.from('articles').select('*, categories!inner(*)').eq('categories.slug', params.slug)

  return (
    <main>
      <Navbar />
      <header className="py-16 text-center border-b border-cream-border">
        <span className="font-mono text-xs uppercase tracking-widest text-ink-muted">Archive</span>
        <h1 className="mt-2 text-5xl font-serif font-bold">{category?.name}</h1>
      </header>
      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
        <div className="grid gap-12 md:grid-cols-2 lg:grid-cols-3">
          {articles?.map((art: any) => (
            <ArticleCard key={art.id} article={art} />
          ))}
        </div>
      </section>
    </main>
  )
}