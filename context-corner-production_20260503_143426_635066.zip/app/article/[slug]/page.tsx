import Navbar from '@/components/Navbar'
import { supabase } from '@/lib/supabase'
import Image from 'next/image'
import Link from 'next/link'

export default async function ArticlePage({ params }: { params: { slug: string } }) {
  const { data: article } = await supabase.from('articles').select('*, authors(*), categories(*)').eq('slug', params.slug).single()
  const { data: moreFromAuthor } = await supabase.from('articles').select('*').eq('author_id', article?.author_id).neq('id', article?.id).limit(3)

  if (!article) return <div className="p-12 text-center">Article not found. <Link href="/" className="underline">Go back</Link></div>

  return (
    <main>
      <Navbar />
      <article className="mx-auto max-w-3xl px-4 py-12 md:py-24">
        <div className="text-center mb-12">
          <span className="font-mono text-xs uppercase tracking-widest text-accent">{article.categories?.name}</span>
          <h1 className="mt-4 text-4xl md:text-6xl font-serif font-bold leading-tight">{article.title}</h1>
          <div className="mt-8 flex items-center justify-center space-x-4">
            <div className="text-left">
              <p className="font-bold text-sm uppercase tracking-wider">{article.authors?.name}</p>
              <p className="text-xs text-ink-muted">Published on {new Date(article.created_at).toLocaleDateString()}</p>
            </div>
          </div>
        </div>

        <div className="relative aspect-[16/9] mb-12 bg-cream-dark">
          <Image src={article.image_url} alt={article.title} fill className="object-cover" priority />
        </div>

        <div className="rich-text font-serif text-xl leading-relaxed text-ink/90" dangerouslySetInnerHTML={{ __html: article.content }} />
        
        <hr className="my-16 border-cream-border" />

        <div className="bg-cream-dark p-8 md:p-12">
          <h3 className="font-mono text-xs uppercase tracking-widest mb-6">More from this author</h3>
          <div className="grid gap-8 md:grid-cols-2">
            {moreFromAuthor?.map(art => (
              <Link key={art.id} href={`/article/${art.slug}`} className="group block">
                <h4 className="font-serif text-lg group-hover:text-accent transition-colors">{art.title}</h4>
              </Link>
            ))}
          </div>
        </div>
      </article>
    </main>
  )
}