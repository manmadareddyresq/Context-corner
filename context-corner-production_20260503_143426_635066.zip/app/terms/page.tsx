import Navbar from '@/components/Navbar'

export default function TermsPage() {
  return (
    <main>
      <Navbar />
      <section className="mx-auto max-w-2xl px-4 py-24">
        <h1 className="font-serif text-4xl mb-8">Terms & Conditions</h1>
        <div className="space-y-6 text-ink-muted leading-relaxed">
          <p>By accessing Context Corner, you agree to these basic terms. This platform is an editorial showcase...</p>
          <p>All content is protected by copyright laws. Unauthorized reproduction is prohibited.</p>
        </div>
      </section>
    </main>
  )
}