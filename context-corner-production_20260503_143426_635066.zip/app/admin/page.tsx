'use client'
import { useState, useEffect } from 'react'
import { supabase } from '@/lib/supabase'
import Editor from '@/components/Editor'

export default function AdminPage() {
  const [isLoggedIn, setIsLoggedIn] = useState(false)
  const [user, setUser] = useState({ username: '', password: '' })
  const [view, setView] = useState('dashboard') // dashboard, articles, submissions
  const [stats, setStats] = useState({ total: 0, pending: 0 })

  const handleLogin = async (e: any) => {
    e.preventDefault()
    const { data } = await supabase.from('admin').select('*').eq('username', user.username).eq('password', user.password).single()
    if (data) setIsLoggedIn(true)
    else alert('Invalid credentials')
  }

  if (!isLoggedIn) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-cream px-4">
        <form onSubmit={handleLogin} className="w-full max-w-sm space-y-6 bg-white p-8 border border-cream-border shadow-sm">
          <h1 className="font-serif text-2xl text-center">Admin Access</h1>
          <input 
            type="text" placeholder="Username" 
            className="w-full p-3 border border-cream-border focus:ring-1 focus:ring-accent outline-none"
            onChange={(e) => setUser({...user, username: e.target.value})}
          />
          <input 
            type="password" placeholder="Password" 
            className="w-full p-3 border border-cream-border focus:ring-1 focus:ring-accent outline-none"
            onChange={(e) => setUser({...user, password: e.target.value})}
          />
          <button className="w-full bg-ink text-cream py-3 font-bold uppercase tracking-widest hover:bg-accent transition-colors">Enter</button>
        </form>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-cream flex flex-col md:flex-row">
      <aside className="w-full md:w-64 bg-ink text-cream p-6 space-y-8">
        <div className="font-serif text-xl font-bold">Admin Console</div>
        <nav className="flex flex-col space-y-4 font-mono text-xs uppercase tracking-widest">
          <button onClick={() => setView('dashboard')} className={view === 'dashboard' ? 'text-accent' : ''}>Dashboard</button>
          <button onClick={() => setView('articles')} className={view === 'articles' ? 'text-accent' : ''}>Articles</button>
          <button onClick={() => setView('submissions')} className={view === 'submissions' ? 'text-accent' : ''}>Submissions</button>
        </nav>
      </aside>
      <main className="flex-1 p-6 md:p-12 overflow-y-auto">
        <h2 className="font-serif text-4xl mb-8 capitalize">{view}</h2>
        {/* Simplified placeholders for the requested components */}
        <div className="bg-white p-8 border border-cream-border min-h-[60vh]">
          {view === 'dashboard' && <p>Stats and overview...</p>}
          {view === 'articles' && <p>Article Management Table (Add/Edit/Delete)...</p>}
          {view === 'submissions' && <p>Submission Moderation Queue...</p>}
        </div>
      </main>
    </div>
  )
}