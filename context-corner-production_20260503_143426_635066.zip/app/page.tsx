import Navbar from '@/components/Navbar'
import ArticleCard from '@/components/ArticleCard'
import { supabase } from '@/lib/supabase'

export default async function Home() {
  const { data: announcement } = await supabase.from('announcements').select('*').eq('active', true).single()
  const { data: articles } = await supabase.from('articles').select('*, categories(name)').order('created_at', { ascending: false })
  const { data: categories } = await supabase.from('categories').select('*')
  
  const featured = articles?.find(a => a.is_featured) || articles?.[0]
  const latest = articles?.filter(a => a.id !== featured?.id).slice(0, 6)

  return (
    <main>
      {announcement && (
        <div className="bg-accent py-2 text-center text-[10px] font-bold uppercase tracking-[0.2em] text-cream">
          {announcement.text}
        </div>
      )}
      <Navbar />
      
      <section className="mx-auto max-w-7xl px-4 py-8 md:py-16 sm:px-6 lg:px-8">
        {featured && <ArticleCard article={featured} variant="featured" />}
        
        <div className="mt-16 grid gap-12 md:grid-cols-2 lg:grid-cols-3">
          {latest?.map((art: any) => (
            <ArticleCard key={art.id} article={art} />
          ))}
        </div>
      </section>

      <section className="bg-cream-dark py-12 px-4">
        <div className="mx-auto max-w-7xl">
          <h3 className="font-mono text-xs uppercase tracking-widest text-ink-muted mb-6">Categories</h3>
          <div className="flex flex-wrap gap-4">
            {categories?.map(cat => (
              <a key={cat.slug} href={`/category/${cat.slug}`} className="px-6 py-3 border border-cream-border hover:border-accent hover:text-accent transition-colors bg-cream">
                {cat.name}
              </a>
            ))}
          </div>
        </div>
      </section>

      <footer className="py-12 border-t border-cream-border text-center">
        <p className="text-[10px] font-mono uppercase text-ink-muted">© 2024 Context Corner • <a href="/terms">Terms</a></p>
      </footer>
    </main>
  )
}