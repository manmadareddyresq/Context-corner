'use client'
import Link from 'next/link'
import { useState } from 'react'
import { Menu, X, Search as SearchIcon } from 'lucide-react'
import Search from './Search'

export default function Navbar() {
  const [isSearchOpen, setIsSearchOpen] = useState(false)
  
  return (
    <nav className="sticky top-0 z-50 border-b border-cream-border bg-cream/90 backdrop-blur-md">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex h-16 items-center justify-between">
          <Link href="/" className="font-serif text-xl font-black uppercase tracking-tighter">
            Context <span className="text-accent">Corner</span>
          </Link>
          
          <div className="flex items-center space-x-4">
            <button onClick={() => setIsSearchOpen(!isSearchOpen)} className="p-2 text-ink-muted hover:text-ink">
              <SearchIcon size={20} />
            </button>
            <Link href="/admin" className="hidden sm:block rounded-full bg-ink px-4 py-1.5 text-xs font-bold uppercase tracking-widest text-cream transition-colors hover:bg-accent">
              Admin
            </Link>
          </div>
        </div>
      </div>
      {isSearchOpen && <div className="absolute top-16 w-full border-b border-cream-border bg-cream p-4 shadow-xl"><Search /></div>}
    </nav>
  )
}