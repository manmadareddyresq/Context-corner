'use client'
import Image from 'next/image'
import Link from 'next/link'
import { motion } from 'framer-motion'

export default function ArticleCard({ article, variant = 'standard' }: any) {
  const isFeatured = variant === 'featured'
  
  return (
    <motion.article 
      initial={{ opacity: 0, y: 10 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
      className={`group cursor-pointer ${isFeatured ? 'space-y-4 md:grid md:grid-cols-2 md:gap-8 md:space-y-0' : 'space-y-3'}`}
    >
      <Link href={`/article/${article.slug}`} className="block">
        <div className={`relative overflow-hidden bg-cream-dark ${isFeatured ? 'aspect-[16/9]' : 'aspect-[3/2]'}`}>
          <Image 
            src={article.image_url || 'https://picsum.photos/seed/editorial/800/500'} 
            alt={article.title} 
            fill 
            className="object-cover transition-transform duration-700 group-hover:scale-105"
            loading="lazy"
          />
        </div>
        <div className="mt-4">
          <span className="font-mono text-[10px] uppercase tracking-widest text-accent">{article.categories?.name || 'Article'}</span>
          <h2 className={`mt-2 font-serif font-bold group-hover:text-accent transition-colors ${isFeatured ? 'text-3xl md:text-5xl' : 'text-xl'}`}>
            {article.title}
          </h2>
          <p className="mt-2 line-clamp-2 text-sm text-ink-muted leading-relaxed">
            {article.excerpt}
          </p>
        </div>
      </Link>
    </motion.article>
  )
}