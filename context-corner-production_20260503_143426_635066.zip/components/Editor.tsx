'use client'
import { useState } from 'react'

export default function Editor({ value, onChange }: { value: string, onChange: (v: string) => void }) {
  return (
    <div className="space-y-2">
      <label className="text-xs font-bold uppercase tracking-widest text-ink-muted">Content (HTML Support)</label>
      <textarea 
        className="w-full h-96 p-4 border border-cream-border bg-white font-mono text-sm focus:ring-1 focus:ring-accent outline-none"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder="Write your article in HTML or plain text..."
      />
    </div>
  )
}