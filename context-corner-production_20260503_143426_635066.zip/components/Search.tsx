'use client'
import { useState, useEffect } from 'react'
import { supabase } from '@/lib/supabase'
import Link from 'next/link'

export default function Search() {
  const [query, setQuery] = useState('')
  const [results, setResults] = useState<any[]>([])

  useEffect(() => {
    if (query.length < 2) { setResults([]); return; }
    const search = async () => {
      const { data } = await supabase.from('articles').select('title, slug').ilike('title', `%${query}%`).limit(5)
      setResults(data || [])
    }
    const timer = setTimeout(search, 300)
    return () => clearTimeout(timer)
  }, [query])

  return (
    <div className="w-full max-w-xl mx-auto">
      <input 
        type="text" 
        placeholder="Search by title..." 
        className="w-full border-none bg-transparent text-xl focus:outline-none placeholder:text-cream-border"
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        autoFocus
      />
      {results.length > 0 && (
        <div className="mt-4 space-y-2">
          {results.map(r => (
            <Link key={r.slug} href={`/article/${r.slug}`} className="block p-2 hover:bg-cream-dark rounded">
              {r.title}
            </Link>
          ))}
        </div>
      )}
    </div>
  )
}