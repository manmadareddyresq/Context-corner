import { createClient } from '@supabase/supabase-js'

const supabaseUrl = 'https://owbuptpswguimpyuwvyf.supabase.co'
const supabaseAnonKey = 'sb_publishable_vo5jIboXukZokhBhfUWWSw_SOJOFHqx'

export const supabase = createClient(supabaseUrl, supabaseAnonKey)