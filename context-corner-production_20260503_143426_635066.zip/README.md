# Context Corner

Premium editorial platform built with Next.js, Tailwind, and Supabase.

## Setup
1. `npm install`
2. Configure `.env.local` with your Supabase credentials.
3. Run migrations in `supabase/schema.sql`.
4. `npm run dev`

## Admin
- **User**: Manmada
- **Pass**: Abc123
