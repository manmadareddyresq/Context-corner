import type { Config } from 'tailwindcss'

const config: Config = {
  content: ['./app/**/*.{js,ts,jsx,tsx}', './components/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      fontFamily: {
        serif: ['var(--font-playfair)', 'serif'],
        sans: ['var(--font-outfit)', 'sans-serif'],
        mono: ['var(--font-dm-mono)', 'monospace'],
      },
      colors: {
        ink: { DEFAULT: '#0F0E0C', light: '#2A2825', muted: '#6B6860' },
        cream: { DEFAULT: '#FAF8F4', dark: '#F0EDE6', border: '#E5E1D8' },
        accent: { DEFAULT: '#C2402A', light: '#E8533A' },
      },
    },
  },
  plugins: [],
}
export default config