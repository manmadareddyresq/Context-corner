import { createClient } from '@supabase/supabase-js'

export const SUPABASE_URL = 'https://owbuptpswguimpyuwvyf.supabase.co'
export const SUPABASE_ANON_KEY = 'sb_publishable_vo5jIboXukZokhBhfUWWSw_SOJOFHqx'

export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
  realtime: { params: { eventsPerSecond: 10 } },
})

export type Article = {
  id: string
  title: string
  slug: string
  excerpt: string
  content: string
  cover_image: string | null
  author_id: string | null
  category_id: string | null
  status: 'draft' | 'published'
  featured: boolean
  views_count: number
  likes_count: number
  claps_count: number
  reading_time: number
  tags: string[]
  created_at: string
  updated_at: string
  authors?: Author
  categories?: Category
}

export type Author = {
  id: string
  name: string
  bio: string | null
  avatar_url: string | null
  role: string | null
  social_links: Record<string, string> | null
  created_at: string
}

export type Category = {
  id: string
  name: string
  slug: string
  description: string | null
  color: string | null
  icon: string | null
  created_at: string
}

export type Tag = {
  id: string
  name: string
  slug: string
  created_at: string
}

export type Submission = {
  id: string
  title: string
  content: string
  author_name: string
  author_email: string
  status: 'pending' | 'approved' | 'rejected'
  tags: string[]
  created_at: string
}

export type Achievement = {
  id: string
  title: string
  description: string
  icon: string | null
  color: string | null
  created_at: string
}

export type Announcement = {
  id: string
  message: string
  active: boolean
  link: string | null
  link_text: string | null
  created_at: string
}

export type Setting = {
  id: string
  key: string
  value: string
  updated_at: string
}
