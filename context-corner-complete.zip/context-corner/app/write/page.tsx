'use client'

import { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import dynamic from 'next/dynamic'
import Link from 'next/link'
import Navbar from '@/components/Navbar'
import { supabase } from '@/lib/supabase'

const Editor = dynamic(() => import('@/components/Editor'), { ssr: false })

const DRAFT_KEY = 'cc_write_draft'

export default function WritePage() {
  const [title, setTitle] = useState('')
  const [content, setContent] = useState('')
  const [authorName, setAuthorName] = useState('')
  const [authorEmail, setAuthorEmail] = useState('')
  const [tags, setTags] = useState('')
  const [submitting, setSubmitting] = useState(false)
  const [submitted, setSubmitted] = useState(false)
  const [error, setError] = useState('')
  const [lastSaved, setLastSaved] = useState<Date | null>(null)
  const [wordCount, setWordCount] = useState(0)

  useEffect(() => {
    try {
      const draft = localStorage.getItem(DRAFT_KEY)
      if (draft) {
        const p = JSON.parse(draft)
        setTitle(p.title || ''); setContent(p.content || '')
        setAuthorName(p.authorName || ''); setAuthorEmail(p.authorEmail || ''); setTags(p.tags || '')
      }
    } catch {}
  }, [])

  useEffect(() => {
    if (!title && !content) return
    const t = setTimeout(() => {
      try {
        localStorage.setItem(DRAFT_KEY, JSON.stringify({ title, content, authorName, authorEmail, tags }))
        setLastSaved(new Date())
      } catch {}
    }, 1500)
    return () => clearTimeout(t)
  }, [title, content, authorName, authorEmail, tags])

  useEffect(() => {
    const text = content.replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim()
    setWordCount(text ? text.split(' ').filter(Boolean).length : 0)
  }, [content])

  const readTime = Math.max(1, Math.ceil(wordCount / 200))

  const handleSubmit = async () => {
    if (!title.trim()) { setError('Please add a title for your article.'); return }
    if (!content.trim() || content === '<p></p>') { setError('Please write some content.'); return }
    if (!authorName.trim()) { setError('Please enter your name.'); return }
    if (!authorEmail.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(authorEmail)) { setError('Please enter a valid email address.'); return }

    setSubmitting(true); setError('')
    try {
      const tagsArr = tags.split(',').map(t => t.trim()).filter(Boolean)
      const { error: err } = await supabase.from('submissions').insert({
        title: title.trim(), content, author_name: authorName.trim(),
        author_email: authorEmail.trim(), tags: tagsArr, status: 'pending',
      })
      if (err) throw err
      setSubmitted(true)
      try { localStorage.removeItem(DRAFT_KEY) } catch {}
    } catch (e: any) {
      setError(e?.message || 'Submission failed. Please try again.')
    } finally { setSubmitting(false) }
  }

  const clearDraft = () => {
    if (!confirm('Clear your draft? This cannot be undone.')) return
    try { localStorage.removeItem(DRAFT_KEY) } catch {}
    setTitle(''); setContent(''); setAuthorName(''); setAuthorEmail(''); setTags(''); setLastSaved(null)
  }

  if (submitted) return (
    <div className="min-h-screen" style={{ background: 'var(--cream)' }}>
      <Navbar />
      <div className="pt-36 flex flex-col items-center justify-center px-4 text-center">
        <motion.div initial={{ opacity: 0, scale: 0.8 }} animate={{ opacity: 1, scale: 1 }} transition={{ type: 'spring', bounce: 0.4 }} className="max-w-md">
          <motion.div animate={{ rotate: [0, -10, 10, -5, 0] }} transition={{ delay: 0.3, duration: 0.5 }}
            className="w-20 h-20 rounded-full flex items-center justify-center text-4xl mx-auto mb-6 shadow-lg"
            style={{ background: 'linear-gradient(135deg, var(--amber-light), var(--amber))' }}>
            ✍️
          </motion.div>
          <h1 className="font-serif text-4xl font-bold text-ink-950 mb-3">Submission Received!</h1>
          <p className="font-sans text-ink-500 leading-relaxed mb-2">
            Thank you for your contribution. Our editorial team will review your piece and reach out at
          </p>
          <p className="font-mono text-amber font-medium mb-8">{authorEmail}</p>
          <div className="flex gap-3 justify-center">
            <button onClick={() => { setSubmitted(false); setTitle(''); setContent(''); setAuthorName(''); setAuthorEmail(''); setTags('') }}
              className="px-6 py-2.5 rounded-full font-semibold text-white text-sm transition-all hover:scale-105"
              style={{ background: 'var(--amber)' }}>
              Write another
            </button>
            <Link href="/" className="px-6 py-2.5 rounded-full font-semibold text-ink-600 text-sm border border-ink-200 hover:border-amber hover:text-amber transition-all">
              Back home
            </Link>
          </div>
        </motion.div>
      </div>
    </div>
  )

  return (
    <div className="min-h-screen" style={{ background: 'var(--cream)' }}>
      <Navbar />
      <div className="max-w-3xl mx-auto px-4 sm:px-6 pt-28 pb-20">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
          <div className="text-center mb-10">
            <p className="text-xs font-mono uppercase tracking-widest mb-3" style={{ color: 'var(--amber)' }}>Share your story</p>
            <h1 className="font-serif font-bold text-4xl md:text-5xl text-ink-950 mb-3">Write for Context Corner</h1>
            <p className="font-sans text-ink-400 max-w-lg mx-auto">No account needed. Submit your piece and our editors will be in touch.</p>
          </div>

          {/* Draft status bar */}
          <div className="flex items-center justify-between text-xs font-mono text-ink-400 mb-5 px-1">
            <div className="flex items-center gap-2">
              <div className={`w-1.5 h-1.5 rounded-full ${lastSaved ? 'bg-green-400' : 'bg-ink-300'} animate-pulse`} />
              {lastSaved ? `Auto-saved at ${lastSaved.toLocaleTimeString()}` : 'Auto-save enabled'}
            </div>
            <div className="flex items-center gap-4">
              <span>{wordCount} words · ~{readTime} min read</span>
              {(title || content) && (
                <button onClick={clearDraft} className="text-ink-300 hover:text-red-400 transition-colors">Clear draft</button>
              )}
            </div>
          </div>

          {/* Title input */}
          <div className="mb-5">
            <input type="text" value={title} onChange={e => setTitle(e.target.value)} placeholder="Your article title…"
              className="w-full font-serif text-2xl md:text-3xl font-bold text-ink-950 bg-transparent placeholder-ink-200 border-none focus:outline-none leading-snug" />
          </div>

          {/* Editor */}
          <div className="mb-7">
            <Editor content={content} onChange={setContent} placeholder="Tell your story… Start writing here." minHeight="480px" />
          </div>

          {/* Author info */}
          <div className="bg-white rounded-xl border border-ink-100 p-6 mb-6">
            <h3 className="font-serif font-bold text-lg text-ink-950 mb-4">About You</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-mono text-ink-400 uppercase tracking-wider mb-1.5">Your Name *</label>
                <input type="text" value={authorName} onChange={e => setAuthorName(e.target.value)} placeholder="Full name"
                  className="w-full px-3 py-2.5 rounded-lg border border-ink-200 bg-cream font-sans text-sm text-ink-900 placeholder-ink-300 focus:outline-none focus:border-amber transition-colors" />
              </div>
              <div>
                <label className="block text-xs font-mono text-ink-400 uppercase tracking-wider mb-1.5">Email Address *</label>
                <input type="email" value={authorEmail} onChange={e => setAuthorEmail(e.target.value)} placeholder="your@email.com"
                  className="w-full px-3 py-2.5 rounded-lg border border-ink-200 bg-cream font-sans text-sm text-ink-900 placeholder-ink-300 focus:outline-none focus:border-amber transition-colors" />
              </div>
            </div>
            <div className="mt-4">
              <label className="block text-xs font-mono text-ink-400 uppercase tracking-wider mb-1.5">Tags (comma separated)</label>
              <input type="text" value={tags} onChange={e => setTags(e.target.value)} placeholder="e.g. technology, opinion, culture, climate"
                className="w-full px-3 py-2.5 rounded-lg border border-ink-200 bg-cream font-sans text-sm text-ink-900 placeholder-ink-300 focus:outline-none focus:border-amber transition-colors" />
            </div>
          </div>

          <AnimatePresence>
            {error && (
              <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} exit={{ opacity: 0, height: 0 }}
                className="mb-5 px-4 py-3 rounded-xl bg-red-50 border border-red-200 text-red-700 text-sm font-sans">
                ⚠️ {error}
              </motion.div>
            )}
          </AnimatePresence>

          <div className="flex items-center gap-4">
            <button onClick={handleSubmit} disabled={submitting}
              className="flex items-center gap-2 px-8 py-3.5 rounded-full font-bold text-white text-sm transition-all hover:scale-105 active:scale-95 disabled:opacity-60 disabled:cursor-not-allowed shadow-md"
              style={{ background: 'linear-gradient(135deg, var(--amber-light), var(--amber-dark))' }}>
              {submitting ? (
                <><span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />Submitting…</>
              ) : (
                <><svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth={2.5} viewBox="0 0 24 24">
                  <path d="M22 2L11 13M22 2l-7 20-4-9-9-4 20-7z" strokeLinecap="round" strokeLinejoin="round" />
                </svg>Submit for Review</>
              )}
            </button>
            <p className="text-xs font-sans text-ink-400">Reviewed before publishing · No login needed</p>
          </div>
        </motion.div>
      </div>
    </div>
  )
}
