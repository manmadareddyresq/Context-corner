'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import Navbar from '@/components/Navbar'
import { supabase } from '@/lib/supabase'

const DEFAULT_TERMS = `<h2>Terms of Service</h2>
<p><em>Last updated: January 2025</em></p>
<h3>1. Acceptance of Terms</h3>
<p>By accessing or using Context Corner, you agree to be bound by these Terms of Service and all applicable laws and regulations. If you do not agree with any of these terms, please do not use this platform.</p>
<h3>2. Content Submission</h3>
<p>When you submit content to Context Corner, you grant us a non-exclusive, worldwide, royalty-free licence to publish, display, and distribute your content. You retain full ownership of your work.</p>
<h3>3. Editorial Standards</h3>
<p>All submissions are reviewed by our editorial team. We may edit for clarity, grammar, or compliance with our guidelines. We reserve the right to decline any submission without providing a reason.</p>
<h3>4. Prohibited Content</h3>
<p>You may not submit content that infringes intellectual property rights, contains defamatory statements, promotes illegal activities, constitutes harassment or hate speech, or violates any applicable laws.</p>
<h3>5. Intellectual Property</h3>
<p>The Context Corner name, logo, design, and original platform content are protected by applicable intellectual property laws. You may not reproduce or distribute our proprietary materials without prior written consent.</p>
<h3>6. Privacy</h3>
<p>We collect minimal personal information. Submitted email addresses are used only for editorial correspondence and are never sold or shared with third parties.</p>
<h3>7. Limitation of Liability</h3>
<p>Context Corner is provided in good faith but without warranties of any kind. We are not liable for any indirect or consequential damages arising from use of the platform.</p>
<h3>8. Changes to Terms</h3>
<p>We reserve the right to modify these terms at any time. Continued use of the platform after changes constitutes acceptance of the updated terms.</p>
<h3>9. Contact</h3>
<p>For questions about these Terms, please contact us at hello@contextcorner.in</p>`

export default function TermsPage() {
  const [terms, setTerms] = useState('')
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    supabase.from('settings').select('value').eq('key', 'terms').maybeSingle().then(({ data }) => {
      setTerms(data?.value || DEFAULT_TERMS)
      setLoading(false)
    })
  }, [])

  return (
    <div className="min-h-screen" style={{ background: 'var(--cream)' }}>
      <Navbar />
      <div className="max-w-3xl mx-auto px-4 sm:px-6 pt-28 pb-20">
        <div className="flex items-center gap-2 text-xs font-mono text-ink-400 mb-8">
          <Link href="/" className="hover:text-amber transition-colors">Home</Link>
          <span>/</span>
          <span className="text-ink-600">Terms of Service</span>
        </div>
        <div className="bg-white rounded-2xl border border-ink-100 p-8 md:p-12 shadow-sm">
          {loading ? (
            <div className="space-y-3 animate-pulse">
              {[80, 100, 60, 100, 90, 100, 70, 100, 85, 100].map((w, i) => (
                <div key={i} className="h-4 rounded" style={{ width: `${w}%`, background: 'var(--parchment)' }} />
              ))}
            </div>
          ) : (
            <div className="article-content" dangerouslySetInnerHTML={{ __html: terms }} />
          )}
        </div>
      </div>
    </div>
  )
}
