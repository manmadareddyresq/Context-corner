'use client'

import { useState, useEffect, useCallback } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import dynamic from 'next/dynamic'
import { supabase } from '@/lib/supabase'
import type { Article, Author, Category, Tag, Submission, Achievement, Announcement, Setting } from '@/lib/supabase'

const Editor = dynamic(() => import('@/components/Editor'), { ssr: false })

// ── helpers ────────────────────────────────────────────────────────────────
function slugify(str: string) {
  return str.toLowerCase().trim().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '')
}
function readingTime(html: string) {
  const words = html.replace(/<[^>]*>/g, ' ').split(/\s+/).filter(Boolean).length
  return Math.max(1, Math.ceil(words / 200))
}

// ── UI primitives ──────────────────────────────────────────────────────────
const Field = ({ label, required, children }: { label: string; required?: boolean; children: React.ReactNode }) => (
  <div>
    <label className="block text-xs font-mono text-ink-400 uppercase tracking-wider mb-1.5">
      {label}{required && <span className="text-amber ml-1">*</span>}
    </label>
    {children}
  </div>
)
const Input = (props: React.InputHTMLAttributes<HTMLInputElement>) => (
  <input {...props} className={`w-full px-3 py-2.5 rounded-lg border border-ink-200 bg-white font-sans text-sm text-ink-900 placeholder-ink-300 focus:outline-none focus:border-amber transition-colors ${props.className || ''}`} />
)
const Textarea = (props: React.TextareaHTMLAttributes<HTMLTextAreaElement>) => (
  <textarea {...props} className={`w-full px-3 py-2.5 rounded-lg border border-ink-200 bg-white font-sans text-sm text-ink-900 placeholder-ink-300 focus:outline-none focus:border-amber transition-colors resize-none ${props.className || ''}`} />
)
const Sel = ({ children, ...props }: React.SelectHTMLAttributes<HTMLSelectElement> & { children: React.ReactNode }) => (
  <select {...props} className={`w-full px-3 py-2.5 rounded-lg border border-ink-200 bg-white font-sans text-sm text-ink-900 focus:outline-none focus:border-amber transition-colors ${props.className || ''}`}>
    {children}
  </select>
)

function StatCard({ label, value, icon, color }: { label: string; value: number | string; icon: string; color: string }) {
  return (
    <div className="bg-white rounded-xl p-5 border border-ink-100 flex items-center gap-4">
      <div className="w-11 h-11 rounded-lg flex items-center justify-center text-xl flex-shrink-0" style={{ background: `${color}18` }}>{icon}</div>
      <div>
        <p className="text-2xl font-serif font-bold text-ink-950">{value}</p>
        <p className="text-xs font-mono text-ink-400 uppercase tracking-wider">{label}</p>
      </div>
    </div>
  )
}

function Modal({ title, onClose, children, wide }: { title: string; onClose: () => void; children: React.ReactNode; wide?: boolean }) {
  useEffect(() => {
    document.body.style.overflow = 'hidden'
    const esc = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose() }
    window.addEventListener('keydown', esc)
    return () => { document.body.style.overflow = ''; window.removeEventListener('keydown', esc) }
  }, [onClose])
  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
      className="fixed inset-0 z-[200] flex items-start justify-center pt-8 px-4 pb-8 overflow-y-auto"
      style={{ background: 'rgba(15,14,13,0.75)', backdropFilter: 'blur(8px)' }}
      onClick={e => { if (e.target === e.currentTarget) onClose() }}>
      <motion.div initial={{ opacity: 0, y: -24, scale: 0.97 }} animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, y: -24, scale: 0.97 }} transition={{ duration: 0.22 }}
        className={`w-full ${wide ? 'max-w-4xl' : 'max-w-2xl'} rounded-2xl shadow-2xl overflow-hidden my-auto`}
        style={{ background: 'var(--cream)' }}>
        <div className="flex items-center justify-between px-6 py-4 border-b border-ink-100" style={{ background: 'white' }}>
          <h2 className="font-serif font-bold text-xl text-ink-950">{title}</h2>
          <button onClick={onClose} className="w-8 h-8 rounded-full flex items-center justify-center text-ink-400 hover:text-ink-950 hover:bg-ink-100 transition-colors">
            <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
              <path d="M18 6L6 18M6 6l12 12" strokeLinecap="round" />
            </svg>
          </button>
        </div>
        <div className="px-6 py-6 max-h-[80vh] overflow-y-auto">{children}</div>
      </motion.div>
    </motion.div>
  )
}

// ── LOGIN ──────────────────────────────────────────────────────────────────
function LoginScreen({ onLogin }: { onLogin: () => void }) {
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)
  const [showPw, setShowPw] = useState(false)

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError('')
    try {
      // Try DB first
      const { data, error: dbErr } = await supabase
        .from('admin')
        .select('id')
        .eq('username', username.trim())
        .eq('password', password)
        .maybeSingle()

      if (data) {
        sessionStorage.setItem('cc_admin', '1')
        sessionStorage.setItem('cc_admin_user', username.trim())
        onLogin()
        return
      }

      // Fallback hardcoded check (in case RLS blocks or table not yet set up)
      if (username.trim() === 'Manmada' && password === 'Abc123') {
        sessionStorage.setItem('cc_admin', '1')
        sessionStorage.setItem('cc_admin_user', 'Manmada')
        onLogin()
        return
      }

      setError('Invalid username or password.')
    } catch (err) {
      // If DB error, still try hardcoded
      if (username.trim() === 'Manmada' && password === 'Abc123') {
        sessionStorage.setItem('cc_admin', '1')
        sessionStorage.setItem('cc_admin_user', 'Manmada')
        onLogin()
        return
      }
      setError('Invalid username or password.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center px-4"
      style={{ background: 'linear-gradient(135deg,#0f0e0d 0%,#1a1714 50%,#2a2520 100%)' }}>
      <motion.div initial={{ opacity: 0, y: 32 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }} className="w-full max-w-sm">
        <div className="text-center mb-10">
          <div className="w-16 h-16 rounded-xl flex items-center justify-center mx-auto mb-4" style={{ background: 'var(--amber)' }}>
            <span className="font-serif text-white font-bold text-2xl">C</span>
          </div>
          <h1 className="font-serif text-3xl font-bold text-white mb-1">Context Corner</h1>
          <p className="font-mono text-xs text-white/30 uppercase tracking-widest">Admin Panel</p>
        </div>
        <form onSubmit={handleLogin} className="space-y-4">
          <div>
            <label className="block text-xs font-mono text-white/40 uppercase tracking-wider mb-1.5">Username</label>
            <input type="text" value={username} onChange={e => setUsername(e.target.value)} required autoFocus
              className="w-full px-4 py-3 rounded-xl text-sm font-sans text-white placeholder-white/20 border border-white/10 focus:border-amber focus:outline-none transition-colors"
              style={{ background: 'rgba(255,255,255,0.07)' }} placeholder="Manmada" />
          </div>
          <div className="relative">
            <label className="block text-xs font-mono text-white/40 uppercase tracking-wider mb-1.5">Password</label>
            <input type={showPw ? 'text' : 'password'} value={password} onChange={e => setPassword(e.target.value)} required
              className="w-full px-4 py-3 pr-10 rounded-xl text-sm font-sans text-white placeholder-white/20 border border-white/10 focus:border-amber focus:outline-none transition-colors"
              style={{ background: 'rgba(255,255,255,0.07)' }} placeholder="••••••" />
            <button type="button" onClick={() => setShowPw(!showPw)}
              className="absolute right-3 bottom-3 text-white/30 hover:text-white/60 transition-colors text-lg">
              {showPw ? '🙈' : '👁️'}
            </button>
          </div>
          <AnimatePresence>
            {error && (
              <motion.p initial={{ opacity: 0, y: -4 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}
                className="text-red-400 text-sm font-sans bg-red-900/20 px-3 py-2 rounded-lg border border-red-800/30">
                {error}
              </motion.p>
            )}
          </AnimatePresence>
          <button type="submit" disabled={loading}
            className="w-full py-3 rounded-xl font-sans font-bold text-ink-950 transition-all hover:scale-[1.02] active:scale-[0.98] disabled:opacity-60 mt-2"
            style={{ background: 'linear-gradient(135deg,var(--amber-light),var(--amber-dark))' }}>
            {loading ? (
              <span className="flex items-center justify-center gap-2">
                <span className="w-4 h-4 border-2 border-ink-950/30 border-t-ink-950 rounded-full animate-spin" />
                Signing in…
              </span>
            ) : 'Sign In →'}
          </button>
        </form>
        <p className="text-center text-white/20 text-xs font-mono mt-6">
          Credentials: Manmada / Abc123
        </p>
      </motion.div>
    </div>
  )
}

// ── DASHBOARD ──────────────────────────────────────────────────────────────
function Dashboard({ onNavigate }: { onNavigate: (s: Section) => void }) {
  const [stats, setStats] = useState({ articles: 0, published: 0, views: 0, submissions: 0, pending: 0, authors: 0 })
  const [recentArticles, setRecentArticles] = useState<Article[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const load = async () => {
      const [artRes, subRes, auRes, recentRes] = await Promise.all([
        supabase.from('articles').select('id, status, views_count'),
        supabase.from('submissions').select('id, status'),
        supabase.from('authors').select('id'),
        supabase.from('articles').select('*, authors(name)').order('created_at', { ascending: false }).limit(5),
      ])
      const arts = artRes.data || []
      const subs = subRes.data || []
      setStats({
        articles: arts.length,
        published: arts.filter(a => a.status === 'published').length,
        views: arts.reduce((s, a) => s + (a.views_count || 0), 0),
        submissions: subs.length,
        pending: subs.filter(s => s.status === 'pending').length,
        authors: (auRes.data || []).length,
      })
      setRecentArticles(recentRes.data || [])
      setLoading(false)
    }
    load()
  }, [])

  const skW = (w: string) => (
    <div className="skeleton h-4 rounded" style={{ width: w, background: 'linear-gradient(90deg,#e8e0d6 25%,#f0e8de 50%,#e8e0d6 75%)', backgroundSize: '200% 100%' }} />
  )

  return (
    <div>
      <div className="mb-8">
        <h2 className="font-serif text-2xl font-bold text-ink-950">Dashboard</h2>
        <p className="font-sans text-sm text-ink-400 mt-1">Welcome back, {sessionStorage.getItem('cc_admin_user') || 'Admin'}</p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-10">
        {loading ? Array(6).fill(0).map((_, i) => (
          <div key={i} className="skeleton h-24 rounded-xl" style={{ background: 'linear-gradient(90deg,#e8e0d6 25%,#f0e8de 50%,#e8e0d6 75%)', backgroundSize: '200% 100%' }} />
        )) : <>
          <StatCard label="Total Articles" value={stats.articles} icon="📝" color="#c8973a" />
          <StatCard label="Published" value={stats.published} icon="✅" color="#22c55e" />
          <StatCard label="Total Views" value={stats.views.toLocaleString()} icon="👁️" color="#3b82f6" />
          <StatCard label="Submissions" value={stats.submissions} icon="📬" color="#8b5cf6" />
          <StatCard label="Pending Review" value={stats.pending} icon="⏳" color="#f59e0b" />
          <StatCard label="Authors" value={stats.authors} icon="✍️" color="#ec4899" />
        </>}
      </div>

      {stats.pending > 0 && (
        <div className="mb-6 px-4 py-3 rounded-xl border border-amber/30 bg-amber/5 flex items-center gap-3">
          <span className="text-xl">⏳</span>
          <p className="font-sans text-sm text-ink-700">You have <strong>{stats.pending}</strong> pending submission{stats.pending !== 1 ? 's' : ''} awaiting review.</p>
          <button onClick={() => onNavigate('submissions')} className="ml-auto text-sm font-medium text-amber hover:underline">Review →</button>
        </div>
      )}

      <div className="bg-white rounded-xl border border-ink-100 overflow-hidden">
        <div className="px-5 py-4 border-b border-ink-100 flex items-center justify-between">
          <h3 className="font-serif font-bold text-lg text-ink-950">Recent Articles</h3>
          <button onClick={() => onNavigate('articles')} className="text-sm text-amber hover:underline">View all →</button>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-ink-100" style={{ background: 'var(--parchment)' }}>
                {['Title', 'Author', 'Status', 'Views', 'Date'].map(h => (
                  <th key={h} className="text-left px-4 py-3 text-xs font-mono text-ink-400 uppercase tracking-wider whitespace-nowrap">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {loading ? Array(4).fill(0).map((_, i) => (
                <tr key={i} className="border-b border-ink-50">
                  {[180, 100, 80, 60, 80].map((w, j) => (
                    <td key={j} className="px-4 py-3">{skW(`${w}px`)}</td>
                  ))}
                </tr>
              )) : recentArticles.map(a => (
                <tr key={a.id} className="border-b border-ink-50 hover:bg-parchment/20 transition-colors">
                  <td className="px-4 py-3">
                    <a href={`/article/${a.slug}`} target="_blank" rel="noopener noreferrer"
                      className="font-medium text-ink-900 hover:text-amber transition-colors line-clamp-1 max-w-[200px] block">{a.title}</a>
                  </td>
                  <td className="px-4 py-3 text-ink-600 whitespace-nowrap">{(a as any).authors?.name || '—'}</td>
                  <td className="px-4 py-3">
                    <span className={`px-2 py-0.5 rounded-full text-xs font-mono font-bold uppercase tracking-wider ${a.status === 'published' ? 'bg-green-100 text-green-700' : 'bg-ink-100 text-ink-500'}`}>
                      {a.status}
                    </span>
                  </td>
                  <td className="px-4 py-3 font-mono text-xs text-ink-400">{(a.views_count || 0).toLocaleString()}</td>
                  <td className="px-4 py-3 text-xs text-ink-400 whitespace-nowrap">{new Date(a.created_at).toLocaleDateString()}</td>
                </tr>
              ))}
              {!loading && recentArticles.length === 0 && (
                <tr><td colSpan={5} className="text-center py-10 text-ink-400 font-sans">No articles yet. <button onClick={() => onNavigate('articles')} className="text-amber hover:underline">Create one</button></td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}

// ── ARTICLES ───────────────────────────────────────────────────────────────
function ArticlesSection() {
  const [articles, setArticles] = useState<Article[]>([])
  const [authors, setAuthors] = useState<Author[]>([])
  const [categories, setCategories] = useState<Category[]>([])
  const [loading, setLoading] = useState(true)
  const [modal, setModal] = useState<'new' | 'edit' | null>(null)
  const [editing, setEditing] = useState<Partial<Article & { author_id: string; category_id: string }> | null>(null)
  const [saving, setSaving] = useState(false)
  const [saveError, setSaveError] = useState('')
  const [search, setSearch] = useState('')

  const load = useCallback(async () => {
    const [aRes, auRes, cRes] = await Promise.all([
      supabase.from('articles').select('*, authors(name), categories(name)').order('created_at', { ascending: false }),
      supabase.from('authors').select('*').order('name'),
      supabase.from('categories').select('*').order('name'),
    ])
    setArticles(aRes.data || [])
    setAuthors(auRes.data || [])
    setCategories(cRes.data || [])
    setLoading(false)
  }, [])

  useEffect(() => { load() }, [load])

  const openNew = () => {
    setEditing({ title: '', slug: '', excerpt: '', content: '', status: 'draft', featured: false, tags: [], author_id: '', category_id: '', cover_image: '' })
    setSaveError('')
    setModal('new')
  }

  const openEdit = (a: Article) => {
    setEditing({ ...a, author_id: (a as any).author_id || '', category_id: (a as any).category_id || '' })
    setSaveError('')
    setModal('edit')
  }

  const save = async () => {
    if (!editing?.title?.trim()) { setSaveError('Title is required.'); return }
    if (!editing?.slug?.trim()) { setSaveError('Slug is required.'); return }
    setSaving(true)
    setSaveError('')

    const tagsArr = Array.isArray(editing.tags)
      ? editing.tags
      : typeof editing.tags === 'string'
        ? (editing.tags as string).split(',').map(t => t.trim()).filter(Boolean)
        : []

    const payload: any = {
      title: editing.title.trim(),
      slug: editing.slug.trim(),
      excerpt: editing.excerpt?.trim() || '',
      content: editing.content || '',
      cover_image: editing.cover_image?.trim() || null,
      author_id: editing.author_id || null,
      category_id: editing.category_id || null,
      status: editing.status || 'draft',
      featured: editing.featured || false,
      reading_time: editing.content ? readingTime(editing.content) : (editing.reading_time || 5),
      tags: tagsArr,
      updated_at: new Date().toISOString(),
    }

    let err: any = null
    if (modal === 'new') {
      payload.views_count = 0; payload.likes_count = 0; payload.claps_count = 0
      const res = await supabase.from('articles').insert(payload)
      err = res.error
    } else {
      const res = await supabase.from('articles').update(payload).eq('id', editing.id!)
      err = res.error
    }

    setSaving(false)
    if (err) { setSaveError(err.message); return }
    setModal(null)
    load()
  }

  const del = async (id: string) => {
    if (!confirm('Delete this article permanently?')) return
    await supabase.from('articles').delete().eq('id', id)
    load()
  }

  const toggleStatus = async (a: Article) => {
    await supabase.from('articles').update({ status: a.status === 'published' ? 'draft' : 'published' }).eq('id', a.id)
    load()
  }

  const toggleFeatured = async (a: Article) => {
    await supabase.from('articles').update({ featured: !a.featured }).eq('id', a.id)
    load()
  }

  const filtered = articles.filter(a =>
    a.title.toLowerCase().includes(search.toLowerCase()) ||
    a.slug.toLowerCase().includes(search.toLowerCase())
  )

  const skRow = () => (
    <tr className="border-b border-ink-50">
      {[200, 100, 80, 70, 60, 50, 80].map((w, j) => (
        <td key={j} className="px-4 py-3">
          <div className="skeleton h-4 rounded" style={{ width: `${w}px`, background: 'linear-gradient(90deg,#e8e0d6 25%,#f0e8de 50%,#e8e0d6 75%)', backgroundSize: '200% 100%' }} />
        </td>
      ))}
    </tr>
  )

  return (
    <div>
      <div className="flex flex-wrap items-center justify-between gap-4 mb-6">
        <h2 className="font-serif text-2xl font-bold text-ink-950">
          Articles <span className="text-ink-300 text-lg font-sans font-normal">({articles.length})</span>
        </h2>
        <div className="flex items-center gap-3">
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search…"
            className="px-3 py-2 rounded-lg border border-ink-200 text-sm focus:outline-none focus:border-amber w-48 transition-colors" />
          <button onClick={openNew}
            className="flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold text-white transition-all hover:scale-105"
            style={{ background: 'var(--amber)' }}>
            <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth={2.5} viewBox="0 0 24 24"><path d="M12 5v14M5 12h14" strokeLinecap="round" /></svg>
            New Article
          </button>
        </div>
      </div>

      <div className="bg-white rounded-xl border border-ink-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-ink-100" style={{ background: 'var(--parchment)' }}>
                {['Title', 'Author', 'Category', 'Status', 'Views', 'Featured', 'Actions'].map(h => (
                  <th key={h} className="text-left px-4 py-3 text-xs font-mono text-ink-400 uppercase tracking-wider whitespace-nowrap">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {loading ? Array(4).fill(0).map((_, i) => skRow()) :
                filtered.length === 0 ? (
                  <tr><td colSpan={7} className="text-center py-12 text-ink-400">
                    {search ? `No articles matching "${search}"` : 'No articles yet. Create your first one!'}
                  </td></tr>
                ) : filtered.map(a => (
                  <tr key={a.id} className="border-b border-ink-50 hover:bg-parchment/30 transition-colors">
                    <td className="px-4 py-3">
                      <p className="font-medium text-ink-900 max-w-[200px] line-clamp-1">{a.title}</p>
                      <p className="text-xs text-ink-400 font-mono">{a.slug}</p>
                    </td>
                    <td className="px-4 py-3 text-ink-600 whitespace-nowrap">{(a as any).authors?.name || '—'}</td>
                    <td className="px-4 py-3 text-ink-600 whitespace-nowrap">{(a as any).categories?.name || '—'}</td>
                    <td className="px-4 py-3">
                      <button onClick={() => toggleStatus(a)}
                        className={`px-2.5 py-1 rounded-full text-xs font-mono font-bold uppercase tracking-wider transition-all hover:scale-105 ${a.status === 'published' ? 'bg-green-100 text-green-700' : 'bg-ink-100 text-ink-500'}`}>
                        {a.status}
                      </button>
                    </td>
                    <td className="px-4 py-3 font-mono text-xs text-ink-500">{(a.views_count || 0).toLocaleString()}</td>
                    <td className="px-4 py-3 text-center">
                      <button onClick={() => toggleFeatured(a)} className="hover:scale-125 transition-transform text-lg" title="Toggle featured">
                        {a.featured ? '⭐' : '☆'}
                      </button>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-1">
                        <a href={`/article/${a.slug}`} target="_blank" rel="noopener noreferrer"
                          className="p-1.5 rounded text-ink-400 hover:text-blue-500 hover:bg-blue-50 transition-colors" title="View live">
                          <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
                            <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6" /><polyline points="15 3 21 3 21 9" /><line x1="10" y1="14" x2="21" y2="3" />
                          </svg>
                        </a>
                        <button onClick={() => openEdit(a)} className="p-1.5 rounded text-ink-400 hover:text-amber hover:bg-amber/10 transition-colors" title="Edit">
                          <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
                            <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" /><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" />
                          </svg>
                        </button>
                        <button onClick={() => del(a.id)} className="p-1.5 rounded text-ink-400 hover:text-red-500 hover:bg-red-50 transition-colors" title="Delete">
                          <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
                            <polyline points="3 6 5 6 21 6" /><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2" />
                          </svg>
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
            </tbody>
          </table>
        </div>
      </div>

      <AnimatePresence>
        {modal && editing && (
          <Modal title={modal === 'new' ? '✏️ New Article' : '✏️ Edit Article'} onClose={() => setModal(null)} wide>
            <div className="space-y-5">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Field label="Title" required>
                  <Input value={editing.title || ''} placeholder="Article title"
                    onChange={e => setEditing(p => ({ ...p, title: e.target.value, slug: p?.slug || slugify(e.target.value) }))} />
                </Field>
                <Field label="Slug" required>
                  <Input value={editing.slug || ''} placeholder="url-slug"
                    onChange={e => setEditing(p => ({ ...p, slug: e.target.value }))} />
                </Field>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Field label="Author">
                  <Sel value={editing.author_id || ''} onChange={e => setEditing(p => ({ ...p, author_id: e.target.value }))}>
                    <option value="">— No author —</option>
                    {authors.map(a => <option key={a.id} value={a.id}>{a.name}</option>)}
                  </Sel>
                </Field>
                <Field label="Category">
                  <Sel value={editing.category_id || ''} onChange={e => setEditing(p => ({ ...p, category_id: e.target.value }))}>
                    <option value="">— No category —</option>
                    {categories.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                  </Sel>
                </Field>
              </div>
              <Field label="Cover Image URL">
                <Input value={editing.cover_image || ''} placeholder="https://images.unsplash.com/…"
                  onChange={e => setEditing(p => ({ ...p, cover_image: e.target.value }))} />
              </Field>
              <Field label="Excerpt / Summary">
                <Textarea value={editing.excerpt || ''} rows={2} placeholder="Short description shown in cards…"
                  onChange={e => setEditing(p => ({ ...p, excerpt: e.target.value }))} />
              </Field>
              <Field label="Content" required>
                <Editor content={editing.content || ''} onChange={c => setEditing(p => ({ ...p, content: c }))} placeholder="Write your article content here…" minHeight="300px" />
              </Field>
              <Field label="Tags (comma separated)">
                <Input
                  value={Array.isArray(editing.tags) ? editing.tags.join(', ') : (editing.tags as any || '')}
                  placeholder="tag1, tag2, tag3"
                  onChange={e => setEditing(p => ({ ...p, tags: e.target.value.split(',').map(t => t.trim()).filter(Boolean) }))} />
              </Field>
              <div className="grid grid-cols-2 gap-4">
                <Field label="Status">
                  <Sel value={editing.status || 'draft'} onChange={e => setEditing(p => ({ ...p, status: e.target.value as any }))}>
                    <option value="draft">Draft</option>
                    <option value="published">Published</option>
                  </Sel>
                </Field>
                <Field label="Featured">
                  <div className="flex items-center h-10">
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input type="checkbox" checked={editing.featured || false}
                        onChange={e => setEditing(p => ({ ...p, featured: e.target.checked }))}
                        className="w-4 h-4 rounded accent-amber" />
                      <span className="text-sm font-sans text-ink-700">Mark as featured ⭐</span>
                    </label>
                  </div>
                </Field>
              </div>
              {saveError && (
                <p className="text-red-600 text-sm font-sans bg-red-50 px-3 py-2 rounded-lg border border-red-200">{saveError}</p>
              )}
              <div className="flex justify-end gap-3 pt-2 border-t border-ink-100">
                <button onClick={() => setModal(null)} className="px-5 py-2.5 rounded-lg border border-ink-200 text-sm font-sans text-ink-600 hover:border-ink-400 transition-colors">Cancel</button>
                <button onClick={save} disabled={saving}
                  className="flex items-center gap-2 px-6 py-2.5 rounded-lg text-sm font-bold text-white disabled:opacity-60 transition-all hover:scale-105"
                  style={{ background: 'var(--amber)' }}>
                  {saving ? <><span className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin" />Saving…</> : '💾 Save Article'}
                </button>
              </div>
            </div>
          </Modal>
        )}
      </AnimatePresence>
    </div>
  )
}

// ── AUTHORS ────────────────────────────────────────────────────────────────
function AuthorsSection() {
  const [items, setItems] = useState<Author[]>([])
  const [modal, setModal] = useState(false)
  const [editing, setEditing] = useState<Partial<Author> | null>(null)
  const [saving, setSaving] = useState(false)

  const load = useCallback(async () => {
    const { data } = await supabase.from('authors').select('*').order('name')
    setItems(data || [])
  }, [])
  useEffect(() => { load() }, [load])

  const save = async () => {
    if (!editing?.name?.trim()) return
    setSaving(true)
    const p = { name: editing.name.trim(), bio: editing.bio || null, avatar_url: editing.avatar_url || null, role: editing.role || null }
    if (editing.id) await supabase.from('authors').update(p).eq('id', editing.id)
    else await supabase.from('authors').insert(p)
    setSaving(false); setModal(false); load()
  }

  const del = async (id: string) => {
    if (!confirm('Delete this author?')) return
    await supabase.from('authors').delete().eq('id', id)
    load()
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h2 className="font-serif text-2xl font-bold text-ink-950">Authors <span className="text-ink-300 text-lg font-sans font-normal">({items.length})</span></h2>
        <button onClick={() => { setEditing({ name: '', bio: '', avatar_url: '', role: '' }); setModal(true) }}
          className="flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold text-white" style={{ background: 'var(--amber)' }}>
          <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth={2.5} viewBox="0 0 24 24"><path d="M12 5v14M5 12h14" strokeLinecap="round" /></svg>
          New Author
        </button>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {items.length === 0 && <p className="text-ink-400 text-sm col-span-3 py-8 text-center">No authors yet.</p>}
        {items.map(a => (
          <div key={a.id} className="bg-white rounded-xl p-4 border border-ink-100 flex items-start gap-3">
            <div className="w-12 h-12 rounded-full bg-parchment flex items-center justify-center flex-shrink-0 overflow-hidden">
              {a.avatar_url ? <img src={a.avatar_url} alt={a.name} className="w-full h-full object-cover" /> :
                <span className="font-serif font-bold text-amber text-lg">{a.name?.[0]}</span>}
            </div>
            <div className="flex-1 min-w-0">
              <p className="font-semibold text-sm text-ink-900">{a.name}</p>
              {a.role && <p className="text-xs font-mono text-amber">{a.role}</p>}
              {a.bio && <p className="text-xs text-ink-400 mt-1 line-clamp-2">{a.bio}</p>}
            </div>
            <div className="flex gap-1 flex-shrink-0">
              <button onClick={() => { setEditing({ ...a }); setModal(true) }} className="p-1.5 rounded text-ink-400 hover:text-amber hover:bg-amber/10 transition-colors">
                <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" /><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" /></svg>
              </button>
              <button onClick={() => del(a.id)} className="p-1.5 rounded text-ink-400 hover:text-red-500 hover:bg-red-50 transition-colors">
                <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24"><polyline points="3 6 5 6 21 6" /><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2" /></svg>
              </button>
            </div>
          </div>
        ))}
      </div>
      <AnimatePresence>
        {modal && editing && (
          <Modal title={editing.id ? 'Edit Author' : 'New Author'} onClose={() => setModal(false)}>
            <div className="space-y-4">
              <Field label="Name" required><Input value={editing.name || ''} onChange={e => setEditing(p => ({ ...p, name: e.target.value }))} placeholder="Full name" /></Field>
              <Field label="Role / Title"><Input value={editing.role || ''} onChange={e => setEditing(p => ({ ...p, role: e.target.value }))} placeholder="Senior Editor" /></Field>
              <Field label="Avatar URL"><Input value={editing.avatar_url || ''} onChange={e => setEditing(p => ({ ...p, avatar_url: e.target.value }))} placeholder="https://..." /></Field>
              <Field label="Bio"><Textarea value={editing.bio || ''} onChange={e => setEditing(p => ({ ...p, bio: e.target.value }))} rows={3} placeholder="Short biography…" /></Field>
              <div className="flex justify-end gap-3 pt-2">
                <button onClick={() => setModal(false)} className="px-5 py-2.5 rounded-lg border border-ink-200 text-sm text-ink-600">Cancel</button>
                <button onClick={save} disabled={saving || !editing.name?.trim()} className="px-6 py-2.5 rounded-lg text-sm font-bold text-white disabled:opacity-60" style={{ background: 'var(--amber)' }}>
                  {saving ? 'Saving…' : 'Save Author'}
                </button>
              </div>
            </div>
          </Modal>
        )}
      </AnimatePresence>
    </div>
  )
}

// ── CATEGORIES ─────────────────────────────────────────────────────────────
function CategoriesSection() {
  const [items, setItems] = useState<Category[]>([])
  const [modal, setModal] = useState(false)
  const [editing, setEditing] = useState<Partial<Category> | null>(null)
  const [saving, setSaving] = useState(false)

  const load = useCallback(async () => {
    const { data } = await supabase.from('categories').select('*').order('name')
    setItems(data || [])
  }, [])
  useEffect(() => { load() }, [load])

  const save = async () => {
    if (!editing?.name?.trim() || !editing?.slug?.trim()) return
    setSaving(true)
    const p = { name: editing.name.trim(), slug: editing.slug.trim(), description: editing.description || null, color: editing.color || null, icon: editing.icon || null }
    if (editing.id) await supabase.from('categories').update(p).eq('id', editing.id)
    else await supabase.from('categories').insert(p)
    setSaving(false); setModal(false); load()
  }

  const del = async (id: string) => {
    if (!confirm('Delete this category?')) return
    await supabase.from('categories').delete().eq('id', id)
    load()
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h2 className="font-serif text-2xl font-bold text-ink-950">Categories</h2>
        <button onClick={() => { setEditing({ name: '', slug: '', description: '', color: '#c8973a', icon: '📂' }); setModal(true) }}
          className="flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold text-white" style={{ background: 'var(--amber)' }}>
          <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth={2.5} viewBox="0 0 24 24"><path d="M12 5v14M5 12h14" strokeLinecap="round" /></svg>
          New Category
        </button>
      </div>
      <div className="bg-white rounded-xl border border-ink-100 overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-ink-100" style={{ background: 'var(--parchment)' }}>
              {['', 'Name', 'Slug', 'Description', 'Actions'].map((h, i) => (
                <th key={i} className="text-left px-4 py-3 text-xs font-mono text-ink-400 uppercase tracking-wider">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {items.map(c => (
              <tr key={c.id} className="border-b border-ink-50 hover:bg-parchment/20 transition-colors">
                <td className="px-4 py-3 text-xl">{c.icon || '📂'}</td>
                <td className="px-4 py-3 font-semibold text-ink-900">{c.name}</td>
                <td className="px-4 py-3 font-mono text-xs text-ink-400">{c.slug}</td>
                <td className="px-4 py-3 text-ink-500 max-w-xs truncate">{c.description || '—'}</td>
                <td className="px-4 py-3">
                  <div className="flex gap-1">
                    <button onClick={() => { setEditing({ ...c }); setModal(true) }} className="p-1.5 rounded text-ink-400 hover:text-amber hover:bg-amber/10">
                      <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" /><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" /></svg>
                    </button>
                    <button onClick={() => del(c.id)} className="p-1.5 rounded text-ink-400 hover:text-red-500 hover:bg-red-50">
                      <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24"><polyline points="3 6 5 6 21 6" /><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2" /></svg>
                    </button>
                  </div>
                </td>
              </tr>
            ))}
            {items.length === 0 && <tr><td colSpan={5} className="text-center py-10 text-ink-400">No categories yet.</td></tr>}
          </tbody>
        </table>
      </div>
      <AnimatePresence>
        {modal && editing && (
          <Modal title={editing.id ? 'Edit Category' : 'New Category'} onClose={() => setModal(false)}>
            <div className="space-y-4">
              <Field label="Name" required>
                <Input value={editing.name || ''} onChange={e => setEditing(p => ({ ...p, name: e.target.value, slug: p?.slug || slugify(e.target.value) }))} placeholder="Category name" />
              </Field>
              <Field label="Slug" required>
                <Input value={editing.slug || ''} onChange={e => setEditing(p => ({ ...p, slug: e.target.value }))} placeholder="category-slug" />
              </Field>
              <div className="grid grid-cols-2 gap-4">
                <Field label="Icon (emoji)"><Input value={editing.icon || ''} onChange={e => setEditing(p => ({ ...p, icon: e.target.value }))} placeholder="📂" /></Field>
                <Field label="Color"><Input type="color" value={editing.color || '#c8973a'} onChange={e => setEditing(p => ({ ...p, color: e.target.value }))} /></Field>
              </div>
              <Field label="Description"><Textarea value={editing.description || ''} onChange={e => setEditing(p => ({ ...p, description: e.target.value }))} rows={2} /></Field>
              <div className="flex justify-end gap-3 pt-2">
                <button onClick={() => setModal(false)} className="px-5 py-2.5 rounded-lg border border-ink-200 text-sm text-ink-600">Cancel</button>
                <button onClick={save} disabled={saving || !editing.name?.trim()} className="px-6 py-2.5 rounded-lg text-sm font-bold text-white disabled:opacity-60" style={{ background: 'var(--amber)' }}>
                  {saving ? 'Saving…' : 'Save'}
                </button>
              </div>
            </div>
          </Modal>
        )}
      </AnimatePresence>
    </div>
  )
}

// ── TAGS ───────────────────────────────────────────────────────────────────
function TagsSection() {
  const [tags, setTags] = useState<Tag[]>([])
  const [newTag, setNewTag] = useState('')
  const [saving, setSaving] = useState(false)

  const load = useCallback(async () => {
    const { data } = await supabase.from('tags').select('*').order('name')
    setTags(data || [])
  }, [])
  useEffect(() => { load() }, [load])

  const add = async () => {
    if (!newTag.trim()) return
    setSaving(true)
    await supabase.from('tags').upsert({ name: newTag.trim(), slug: slugify(newTag.trim()) }, { onConflict: 'slug' })
    setNewTag(''); setSaving(false); load()
  }

  const del = async (id: string) => {
    await supabase.from('tags').delete().eq('id', id)
    load()
  }

  return (
    <div>
      <h2 className="font-serif text-2xl font-bold text-ink-950 mb-6">Tags</h2>
      <div className="flex gap-3 mb-6">
        <Input value={newTag} onChange={e => setNewTag(e.target.value)}
          onKeyDown={e => { if (e.key === 'Enter') add() }}
          placeholder="Add a new tag and press Enter…" className="max-w-sm" />
        <button onClick={add} disabled={saving || !newTag.trim()}
          className="px-5 py-2.5 rounded-lg text-sm font-bold text-white disabled:opacity-60 transition-all hover:scale-105"
          style={{ background: 'var(--amber)' }}>Add</button>
      </div>
      <div className="flex flex-wrap gap-2">
        {tags.map(t => (
          <div key={t.id} className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white border border-ink-200 group hover:border-amber transition-colors">
            <span className="font-mono text-sm text-ink-700">#{t.name}</span>
            <button onClick={() => del(t.id)} className="text-ink-300 hover:text-red-400 transition-colors">
              <svg className="w-3 h-3" fill="none" stroke="currentColor" strokeWidth={2.5} viewBox="0 0 24 24"><path d="M18 6L6 18M6 6l12 12" strokeLinecap="round" /></svg>
            </button>
          </div>
        ))}
        {tags.length === 0 && <p className="text-ink-400 text-sm font-sans">No tags yet. Add some above.</p>}
      </div>
    </div>
  )
}

// ── SUBMISSIONS ────────────────────────────────────────────────────────────
function SubmissionsSection() {
  const [items, setItems] = useState<Submission[]>([])
  const [loading, setLoading] = useState(true)
  const [selected, setSelected] = useState<Submission | null>(null)
  const [filter, setFilter] = useState<'pending' | 'approved' | 'rejected' | 'all'>('pending')

  const load = useCallback(async () => {
    setLoading(true)
    const q = supabase.from('submissions').select('*').order('created_at', { ascending: false })
    const { data } = filter === 'all' ? await q : await q.eq('status', filter)
    setItems(data || [])
    setLoading(false)
  }, [filter])

  useEffect(() => { load() }, [load])

  useEffect(() => {
    const ch = supabase.channel('subs-rt')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'submissions' }, load)
      .subscribe()
    return () => { supabase.removeChannel(ch) }
  }, [load])

  const updateStatus = async (id: string, status: 'approved' | 'rejected') => {
    await supabase.from('submissions').update({ status }).eq('id', id)
    setSelected(null)
    load()
  }

  const del = async (id: string) => {
    if (!confirm('Delete this submission permanently?')) return
    await supabase.from('submissions').delete().eq('id', id)
    setSelected(null)
    load()
  }

  const statusCls: Record<string, string> = {
    pending: 'bg-yellow-100 text-yellow-700',
    approved: 'bg-green-100 text-green-700',
    rejected: 'bg-red-100 text-red-700',
  }

  return (
    <div>
      <div className="flex flex-wrap items-center justify-between gap-4 mb-6">
        <h2 className="font-serif text-2xl font-bold text-ink-950">Submissions</h2>
        <div className="flex gap-2 flex-wrap">
          {(['pending', 'approved', 'rejected', 'all'] as const).map(f => (
            <button key={f} onClick={() => setFilter(f)}
              className={`px-3 py-1.5 rounded-lg text-xs font-mono uppercase tracking-wider transition-all ${filter === f ? 'text-white' : 'border border-ink-200 text-ink-500 hover:border-amber hover:text-amber'}`}
              style={filter === f ? { background: 'var(--amber)' } : {}}>
              {f}
            </button>
          ))}
        </div>
      </div>

      <div className="bg-white rounded-xl border border-ink-100 overflow-hidden">
        {loading ? (
          <div className="p-8 text-center"><div className="w-6 h-6 border-2 border-amber border-t-transparent rounded-full animate-spin mx-auto" /></div>
        ) : items.length === 0 ? (
          <div className="p-12 text-center">
            <p className="text-3xl mb-3">📭</p>
            <p className="font-sans text-ink-400">No {filter === 'all' ? '' : filter} submissions.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-ink-100" style={{ background: 'var(--parchment)' }}>
                  {['Title', 'Author', 'Email', 'Status', 'Date', 'Actions'].map(h => (
                    <th key={h} className="text-left px-4 py-3 text-xs font-mono text-ink-400 uppercase tracking-wider whitespace-nowrap">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {items.map(s => (
                  <tr key={s.id} className="border-b border-ink-50 hover:bg-parchment/20 transition-colors">
                    <td className="px-4 py-3">
                      <button onClick={() => setSelected(s)} className="font-medium text-ink-900 hover:text-amber transition-colors text-left line-clamp-1 max-w-[180px]">{s.title}</button>
                    </td>
                    <td className="px-4 py-3 text-ink-700 font-medium whitespace-nowrap">{s.author_name}</td>
                    <td className="px-4 py-3 text-ink-400 text-xs">{s.author_email}</td>
                    <td className="px-4 py-3">
                      <span className={`px-2.5 py-1 rounded-full text-xs font-mono font-bold uppercase tracking-wider ${statusCls[s.status]}`}>{s.status}</span>
                    </td>
                    <td className="px-4 py-3 text-xs text-ink-400 whitespace-nowrap">{new Date(s.created_at).toLocaleDateString()}</td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-1">
                        <button onClick={() => setSelected(s)} className="p-1.5 rounded text-ink-400 hover:text-blue-500 hover:bg-blue-50 transition-colors" title="View">
                          <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" /><circle cx="12" cy="12" r="3" /></svg>
                        </button>
                        {s.status === 'pending' && (<>
                          <button onClick={() => updateStatus(s.id, 'approved')} className="p-1.5 rounded text-ink-400 hover:text-green-600 hover:bg-green-50 transition-colors" title="Approve">
                            <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" strokeWidth={2.5} viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12" /></svg>
                          </button>
                          <button onClick={() => updateStatus(s.id, 'rejected')} className="p-1.5 rounded text-ink-400 hover:text-red-500 hover:bg-red-50 transition-colors" title="Reject">
                            <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24"><path d="M18 6L6 18M6 6l12 12" strokeLinecap="round" /></svg>
                          </button>
                        </>)}
                        <button onClick={() => del(s.id)} className="p-1.5 rounded text-ink-400 hover:text-red-500 hover:bg-red-50 transition-colors" title="Delete">
                          <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24"><polyline points="3 6 5 6 21 6" /><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2" /></svg>
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <AnimatePresence>
        {selected && (
          <Modal title="📄 Submission Review" onClose={() => setSelected(null)} wide>
            <div className="space-y-4">
              <div>
                <h3 className="font-serif text-xl font-bold text-ink-950">{selected.title}</h3>
                <div className="flex flex-wrap items-center gap-2 mt-2 text-sm text-ink-400">
                  <span className="font-medium text-ink-700">{selected.author_name}</span>
                  <span>·</span>
                  <span>{selected.author_email}</span>
                  <span>·</span>
                  <span>{new Date(selected.created_at).toLocaleDateString()}</span>
                  <span className={`px-2 py-0.5 rounded-full text-xs font-mono font-bold uppercase ${statusCls[selected.status]}`}>{selected.status}</span>
                </div>
              </div>
              {selected.tags?.length > 0 && (
                <div className="flex flex-wrap gap-1.5">
                  {selected.tags.map(t => <span key={t} className="px-2.5 py-1 rounded-full text-xs font-mono bg-parchment text-ink-600">#{t}</span>)}
                </div>
              )}
              <div className="bg-parchment rounded-xl p-5 max-h-[50vh] overflow-y-auto border border-ink-100">
                <div className="article-content text-sm" dangerouslySetInnerHTML={{ __html: selected.content }} />
              </div>
              <div className="flex items-center gap-3 pt-2 border-t border-ink-100">
                {selected.status === 'pending' && (<>
                  <button onClick={() => updateStatus(selected.id, 'approved')}
                    className="flex items-center gap-2 px-5 py-2.5 rounded-lg text-sm font-bold text-white bg-green-600 hover:bg-green-700 transition-colors">
                    ✅ Approve
                  </button>
                  <button onClick={() => updateStatus(selected.id, 'rejected')}
                    className="flex items-center gap-2 px-5 py-2.5 rounded-lg text-sm font-bold text-white bg-red-500 hover:bg-red-600 transition-colors">
                    ❌ Reject
                  </button>
                </>)}
                <button onClick={() => del(selected.id)}
                  className="ml-auto flex items-center gap-1 px-4 py-2.5 rounded-lg text-sm font-bold text-red-500 border border-red-200 hover:bg-red-50 transition-colors">
                  🗑️ Delete
                </button>
              </div>
            </div>
          </Modal>
        )}
      </AnimatePresence>
    </div>
  )
}

// ── ACHIEVEMENTS ───────────────────────────────────────────────────────────
function AchievementsSection() {
  const [items, setItems] = useState<Achievement[]>([])
  const [modal, setModal] = useState(false)
  const [editing, setEditing] = useState<Partial<Achievement> | null>(null)
  const [saving, setSaving] = useState(false)

  const load = useCallback(async () => {
    const { data } = await supabase.from('achievements').select('*').order('created_at', { ascending: false })
    setItems(data || [])
  }, [])
  useEffect(() => { load() }, [load])

  const save = async () => {
    if (!editing?.title?.trim()) return
    setSaving(true)
    const p = { title: editing.title.trim(), description: editing.description || null, icon: editing.icon || null, color: editing.color || null }
    if (editing.id) await supabase.from('achievements').update(p).eq('id', editing.id)
    else await supabase.from('achievements').insert(p)
    setSaving(false); setModal(false); load()
  }

  const del = async (id: string) => {
    if (!confirm('Delete?')) return
    await supabase.from('achievements').delete().eq('id', id)
    load()
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h2 className="font-serif text-2xl font-bold text-ink-950">Achievements</h2>
        <button onClick={() => { setEditing({ title: '', description: '', icon: '🏆', color: '#c8973a' }); setModal(true) }}
          className="flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold text-white" style={{ background: 'var(--amber)' }}>
          <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth={2.5} viewBox="0 0 24 24"><path d="M12 5v14M5 12h14" strokeLinecap="round" /></svg>
          New Achievement
        </button>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {items.length === 0 && <p className="col-span-3 text-ink-400 text-sm py-8 text-center">No achievements yet.</p>}
        {items.map(item => (
          <div key={item.id} className="bg-white rounded-xl p-4 border border-ink-100 flex items-start gap-3">
            <div className="w-11 h-11 rounded-xl flex items-center justify-center text-2xl flex-shrink-0"
              style={{ background: item.color ? `${item.color}20` : 'var(--parchment)' }}>
              {item.icon || '🏆'}
            </div>
            <div className="flex-1 min-w-0">
              <p className="font-semibold text-sm text-ink-900">{item.title}</p>
              {item.description && <p className="text-xs text-ink-400 mt-0.5 line-clamp-2">{item.description}</p>}
            </div>
            <div className="flex gap-1">
              <button onClick={() => { setEditing({ ...item }); setModal(true) }} className="p-1.5 rounded text-ink-400 hover:text-amber hover:bg-amber/10 transition-colors">
                <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" /><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" /></svg>
              </button>
              <button onClick={() => del(item.id)} className="p-1.5 rounded text-ink-400 hover:text-red-500 hover:bg-red-50 transition-colors">
                <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24"><polyline points="3 6 5 6 21 6" /><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2" /></svg>
              </button>
            </div>
          </div>
        ))}
      </div>
      <AnimatePresence>
        {modal && editing && (
          <Modal title={editing.id ? 'Edit Achievement' : 'New Achievement'} onClose={() => setModal(false)}>
            <div className="space-y-4">
              <Field label="Title" required><Input value={editing.title || ''} onChange={e => setEditing(p => ({ ...p, title: e.target.value }))} placeholder="Achievement title" /></Field>
              <div className="grid grid-cols-2 gap-4">
                <Field label="Icon (emoji)"><Input value={editing.icon || ''} onChange={e => setEditing(p => ({ ...p, icon: e.target.value }))} placeholder="🏆" /></Field>
                <Field label="Accent Color"><Input type="color" value={editing.color || '#c8973a'} onChange={e => setEditing(p => ({ ...p, color: e.target.value }))} /></Field>
              </div>
              <Field label="Description"><Textarea value={editing.description || ''} onChange={e => setEditing(p => ({ ...p, description: e.target.value }))} rows={2} placeholder="Brief description…" /></Field>
              <div className="flex justify-end gap-3 pt-2">
                <button onClick={() => setModal(false)} className="px-5 py-2.5 rounded-lg border border-ink-200 text-sm text-ink-600">Cancel</button>
                <button onClick={save} disabled={saving || !editing.title?.trim()} className="px-6 py-2.5 rounded-lg text-sm font-bold text-white disabled:opacity-60" style={{ background: 'var(--amber)' }}>
                  {saving ? 'Saving…' : 'Save'}
                </button>
              </div>
            </div>
          </Modal>
        )}
      </AnimatePresence>
    </div>
  )
}

// ── ANNOUNCEMENTS ──────────────────────────────────────────────────────────
function AnnouncementsSection() {
  const [items, setItems] = useState<Announcement[]>([])
  const [modal, setModal] = useState(false)
  const [editing, setEditing] = useState<Partial<Announcement> | null>(null)
  const [saving, setSaving] = useState(false)

  const load = useCallback(async () => {
    const { data } = await supabase.from('announcements').select('*').order('created_at', { ascending: false })
    setItems(data || [])
  }, [])
  useEffect(() => { load() }, [load])

  const save = async () => {
    if (!editing?.message?.trim()) return
    setSaving(true)
    const p = { message: editing.message.trim(), active: editing.active ?? true, link: editing.link?.trim() || null, link_text: editing.link_text?.trim() || null }
    if (editing.id) await supabase.from('announcements').update(p).eq('id', editing.id)
    else await supabase.from('announcements').insert(p)
    setSaving(false); setModal(false); load()
  }

  const toggle = async (id: string, active: boolean) => {
    await supabase.from('announcements').update({ active: !active }).eq('id', id)
    load()
  }

  const del = async (id: string) => {
    if (!confirm('Delete this announcement?')) return
    await supabase.from('announcements').delete().eq('id', id)
    load()
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h2 className="font-serif text-2xl font-bold text-ink-950">Announcements</h2>
        <button onClick={() => { setEditing({ message: '', active: true, link: '', link_text: '' }); setModal(true) }}
          className="flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold text-white" style={{ background: 'var(--amber)' }}>
          <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth={2.5} viewBox="0 0 24 24"><path d="M12 5v14M5 12h14" strokeLinecap="round" /></svg>
          New Banner
        </button>
      </div>
      <div className="space-y-3">
        {items.length === 0 && <p className="text-ink-400 text-sm font-sans py-8 text-center">No announcements yet. Create your first banner.</p>}
        {items.map(item => (
          <div key={item.id} className={`bg-white rounded-xl p-4 border flex items-start gap-4 transition-all ${item.active ? 'border-amber/40 shadow-sm' : 'border-ink-100 opacity-70'}`}>
            <span className="text-xl mt-0.5 flex-shrink-0">📣</span>
            <div className="flex-1 min-w-0">
              <p className="font-sans text-sm text-ink-800 line-clamp-2">{item.message}</p>
              {item.link && <a href={item.link} target="_blank" rel="noopener noreferrer" className="text-xs text-amber mt-1 block hover:underline">{item.link_text || item.link}</a>}
              <p className="text-xs text-ink-300 mt-1 font-mono">{new Date(item.created_at).toLocaleDateString()}</p>
            </div>
            <div className="flex items-center gap-2 flex-shrink-0">
              <button onClick={() => toggle(item.id, item.active)}
                className={`px-2.5 py-1 rounded-full text-xs font-mono font-bold uppercase tracking-wider transition-all ${item.active ? 'bg-green-100 text-green-700' : 'bg-ink-100 text-ink-500'}`}>
                {item.active ? '🟢 Live' : '⚫ Off'}
              </button>
              <button onClick={() => { setEditing({ ...item }); setModal(true) }} className="p-1.5 rounded text-ink-400 hover:text-amber hover:bg-amber/10 transition-colors">
                <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" /><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" /></svg>
              </button>
              <button onClick={() => del(item.id)} className="p-1.5 rounded text-ink-400 hover:text-red-500 hover:bg-red-50 transition-colors">
                <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24"><polyline points="3 6 5 6 21 6" /><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2" /></svg>
              </button>
            </div>
          </div>
        ))}
      </div>
      <AnimatePresence>
        {modal && editing && (
          <Modal title={editing.id ? 'Edit Announcement' : 'New Announcement'} onClose={() => setModal(false)}>
            <div className="space-y-4">
              <Field label="Message" required>
                <Textarea value={editing.message || ''} onChange={e => setEditing(p => ({ ...p, message: e.target.value }))} rows={3} placeholder="Announcement text shown at top of site…" />
              </Field>
              <div className="grid grid-cols-2 gap-4">
                <Field label="Link URL (optional)"><Input value={editing.link || ''} onChange={e => setEditing(p => ({ ...p, link: e.target.value }))} placeholder="https://..." /></Field>
                <Field label="Link Text (optional)"><Input value={editing.link_text || ''} onChange={e => setEditing(p => ({ ...p, link_text: e.target.value }))} placeholder="Learn more" /></Field>
              </div>
              <label className="flex items-center gap-2 cursor-pointer">
                <input type="checkbox" checked={editing.active ?? true} onChange={e => setEditing(p => ({ ...p, active: e.target.checked }))} className="w-4 h-4 accent-amber" />
                <span className="text-sm font-sans text-ink-700">Active — show on site immediately</span>
              </label>
              <div className="flex justify-end gap-3 pt-2">
                <button onClick={() => setModal(false)} className="px-5 py-2.5 rounded-lg border border-ink-200 text-sm text-ink-600">Cancel</button>
                <button onClick={save} disabled={saving || !editing.message?.trim()} className="px-6 py-2.5 rounded-lg text-sm font-bold text-white disabled:opacity-60" style={{ background: 'var(--amber)' }}>
                  {saving ? 'Saving…' : 'Save Banner'}
                </button>
              </div>
            </div>
          </Modal>
        )}
      </AnimatePresence>
    </div>
  )
}

// ── SETTINGS ───────────────────────────────────────────────────────────────
function SettingsSection() {
  const [vals, setVals] = useState<Record<string, string>>({})
  const [saving, setSaving] = useState<string | null>(null)
  const [saved, setSaved] = useState<string | null>(null)

  useEffect(() => {
    supabase.from('settings').select('*').then(({ data }) => {
      if (data) {
        const m: Record<string, string> = {}
        data.forEach((s: Setting) => { m[s.key] = s.value || '' })
        setVals(m)
      }
    })
  }, [])

  const saveSetting = async (key: string) => {
    setSaving(key)
    const { data } = await supabase.from('settings').select('id').eq('key', key).maybeSingle()
    if (data) {
      await supabase.from('settings').update({ value: vals[key] || '', updated_at: new Date().toISOString() }).eq('key', key)
    } else {
      await supabase.from('settings').insert({ key, value: vals[key] || '' })
    }
    setSaving(null); setSaved(key); setTimeout(() => setSaved(null), 2500)
  }

  const fields = [
    { key: 'site_description', label: 'Site Description', type: 'textarea', placeholder: 'Describe your platform…', rows: 2 },
    { key: 'help_email', label: 'Help / Contact Email', type: 'input', placeholder: 'help@yoursite.com' },
    { key: 'terms', label: 'Terms of Service (HTML)', type: 'textarea', placeholder: '<h2>Terms…</h2>', rows: 14 },
  ]

  return (
    <div>
      <h2 className="font-serif text-2xl font-bold text-ink-950 mb-6">Settings</h2>
      <div className="space-y-5">
        {fields.map(f => (
          <div key={f.key} className="bg-white rounded-xl border border-ink-100 p-5">
            <label className="block text-xs font-mono text-ink-400 uppercase tracking-wider mb-3">{f.label}</label>
            {f.type === 'input' ? (
              <Input value={vals[f.key] || ''} onChange={e => setVals(p => ({ ...p, [f.key]: e.target.value }))} placeholder={f.placeholder} />
            ) : (
              <Textarea value={vals[f.key] || ''} onChange={e => setVals(p => ({ ...p, [f.key]: e.target.value }))} rows={f.rows || 4} placeholder={f.placeholder}
                className={f.key === 'terms' ? 'font-mono text-xs' : ''} />
            )}
            <div className="flex items-center justify-end mt-3 gap-3">
              {saved === f.key && <span className="text-green-600 text-xs font-mono flex items-center gap-1">✓ Saved!</span>}
              <button onClick={() => saveSetting(f.key)} disabled={saving === f.key}
                className="px-5 py-2 rounded-lg text-xs font-bold text-white disabled:opacity-60 transition-all hover:scale-105"
                style={{ background: 'var(--amber)' }}>
                {saving === f.key ? 'Saving…' : 'Save'}
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

// ── MAIN ───────────────────────────────────────────────────────────────────
type Section = 'dashboard' | 'articles' | 'authors' | 'categories' | 'tags' | 'submissions' | 'achievements' | 'announcements' | 'settings'

const NAV: { key: Section; label: string; icon: string }[] = [
  { key: 'dashboard', label: 'Dashboard', icon: '📊' },
  { key: 'articles', label: 'Articles', icon: '📝' },
  { key: 'authors', label: 'Authors', icon: '✍️' },
  { key: 'categories', label: 'Categories', icon: '📂' },
  { key: 'tags', label: 'Tags', icon: '🏷️' },
  { key: 'submissions', label: 'Submissions', icon: '📬' },
  { key: 'achievements', label: 'Achievements', icon: '🏆' },
  { key: 'announcements', label: 'Announcements', icon: '📣' },
  { key: 'settings', label: 'Settings', icon: '⚙️' },
]

export default function AdminPage() {
  const [authed, setAuthed] = useState(false)
  const [checking, setChecking] = useState(true)
  const [section, setSection] = useState<Section>('dashboard')
  const [mobileOpen, setMobileOpen] = useState(false)

  useEffect(() => {
    if (sessionStorage.getItem('cc_admin') === '1') setAuthed(true)
    setChecking(false)
  }, [])

  const logout = () => { sessionStorage.removeItem('cc_admin'); sessionStorage.removeItem('cc_admin_user'); setAuthed(false) }

  const navigate = (s: Section) => { setSection(s); setMobileOpen(false) }

  if (checking) return (
    <div className="min-h-screen flex items-center justify-center" style={{ background: 'var(--cream)' }}>
      <div className="w-8 h-8 rounded-full border-2 border-amber border-t-transparent animate-spin" />
    </div>
  )

  if (!authed) return <LoginScreen onLogin={() => setAuthed(true)} />

  const content: Record<Section, React.ReactNode> = {
    dashboard: <Dashboard onNavigate={navigate} />,
    articles: <ArticlesSection />,
    authors: <AuthorsSection />,
    categories: <CategoriesSection />,
    tags: <TagsSection />,
    submissions: <SubmissionsSection />,
    achievements: <AchievementsSection />,
    announcements: <AnnouncementsSection />,
    settings: <SettingsSection />,
  }

  const Sidebar = () => (
    <aside className="w-56 flex-shrink-0 flex flex-col border-r border-ink-100 h-full" style={{ background: 'white' }}>
      <div className="px-4 py-5 border-b border-ink-100">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-md flex items-center justify-center flex-shrink-0" style={{ background: 'var(--amber)' }}>
            <span className="font-serif text-white font-bold text-sm">C</span>
          </div>
          <div>
            <span className="font-serif text-sm font-bold text-ink-950 block leading-none">Context Corner</span>
            <span className="font-mono text-[10px] text-amber">Admin Panel</span>
          </div>
        </div>
      </div>
      <nav className="flex-1 px-3 py-4 overflow-y-auto space-y-0.5">
        {NAV.map(item => (
          <button key={item.key} onClick={() => navigate(item.key)}
            className={`admin-nav-link w-full text-left ${section === item.key ? 'active' : ''}`}>
            <span className="text-base">{item.icon}</span>
            <span>{item.label}</span>
          </button>
        ))}
      </nav>
      <div className="px-3 py-4 border-t border-ink-100 space-y-1">
        <a href="/" target="_blank" rel="noopener noreferrer"
          className="flex items-center gap-2 px-3 py-2 rounded-lg text-xs font-sans text-ink-400 hover:text-amber hover:bg-amber/5 transition-colors">
          <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
            <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6" /><polyline points="15 3 21 3 21 9" /><line x1="10" y1="14" x2="21" y2="3" />
          </svg>
          View Site ↗
        </a>
        <button onClick={logout}
          className="flex items-center gap-2 px-3 py-2 rounded-lg text-xs font-sans text-ink-400 hover:text-red-500 hover:bg-red-50 transition-colors w-full">
          <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
            <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" /><polyline points="16 17 21 12 16 7" /><line x1="21" y1="12" x2="9" y2="12" />
          </svg>
          Sign Out
        </button>
      </div>
    </aside>
  )

  return (
    <div className="min-h-screen flex" style={{ background: 'var(--parchment)' }}>
      {/* Desktop sidebar */}
      <div className="hidden md:flex flex-col" style={{ width: 224, minHeight: '100vh', position: 'sticky', top: 0, maxHeight: '100vh' }}>
        <Sidebar />
      </div>

      {/* Mobile sidebar overlay */}
      <AnimatePresence>
        {mobileOpen && (
          <>
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              className="fixed inset-0 z-40 bg-black/40 md:hidden" onClick={() => setMobileOpen(false)} />
            <motion.div initial={{ x: -224 }} animate={{ x: 0 }} exit={{ x: -224 }} transition={{ type: 'spring', damping: 25 }}
              className="fixed inset-y-0 left-0 z-50 md:hidden flex flex-col" style={{ width: 224 }}>
              <Sidebar />
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Main content */}
      <div className="flex-1 flex flex-col min-w-0 min-h-screen">
        {/* Top bar */}
        <header className="bg-white border-b border-ink-100 px-4 md:px-6 py-4 flex items-center gap-4 sticky top-0 z-30">
          <button onClick={() => setMobileOpen(true)} className="md:hidden p-2 rounded-lg text-ink-400 hover:text-ink-950 hover:bg-ink-100 transition-colors">
            <svg className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
              <line x1="3" y1="12" x2="21" y2="12" /><line x1="3" y1="6" x2="21" y2="6" /><line x1="3" y1="18" x2="21" y2="18" />
            </svg>
          </button>
          <div className="flex items-center gap-3">
            <span className="text-xl">{NAV.find(n => n.key === section)?.icon}</span>
            <h1 className="font-serif font-bold text-lg text-ink-950">{NAV.find(n => n.key === section)?.label}</h1>
          </div>
          <div className="ml-auto flex items-center gap-2">
            <span className="hidden sm:block text-xs font-mono text-ink-400">
              {sessionStorage.getItem('cc_admin_user') || 'Admin'}
            </span>
            <button onClick={logout} className="p-2 rounded-lg text-ink-400 hover:text-red-500 hover:bg-red-50 transition-colors" title="Sign out">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
                <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" /><polyline points="16 17 21 12 16 7" /><line x1="21" y1="12" x2="9" y2="12" />
              </svg>
            </button>
          </div>
        </header>

        {/* Page content */}
        <main className="flex-1 p-4 md:p-8 overflow-y-auto">
          <AnimatePresence mode="wait">
            <motion.div key={section} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -6 }} transition={{ duration: 0.18 }}>
              {content[section]}
            </motion.div>
          </AnimatePresence>
        </main>
      </div>
    </div>
  )
}
