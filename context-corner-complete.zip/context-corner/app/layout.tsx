import type { Metadata } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: 'Context Corner — Premium Editorial Platform',
  description: 'A premium editorial platform for thoughtful perspectives, deep-dives, and cultural commentary.',
  openGraph: {
    title: 'Context Corner',
    description: 'Premium editorial platform for thoughtful perspectives.',
    type: 'website',
  },
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,600;0,700;0,900;1,400;1,600&family=DM+Sans:ital,wght@0,300;0,400;0,500;0,600;1,300;1,400&family=DM+Mono:wght@400;500&display=swap" rel="stylesheet" />
      </head>
      <body className="grain">
        {children}
      </body>
    </html>
  )
}
