'use client'

import { useState, useEffect, useCallback } from 'react'
import { useParams } from 'next/navigation'
import Link from 'next/link'
import { motion } from 'framer-motion'
import Navbar from '@/components/Navbar'
import ArticleCard from '@/components/ArticleCard'
import { supabase } from '@/lib/supabase'
import type { Article, Category } from '@/lib/supabase'

const ICONS: Record<string, string> = {
  Technology: '💻', Culture: '🎭', Politics: '⚖️', Science: '🔬',
  Arts: '🎨', Business: '📈', Health: '🌿', Environment: '🌍',
}
const PAGE = 9

export default function CategoryPage() {
  const { slug } = useParams<{ slug: string }>()
  const [cat, setCat] = useState<Category | null>(null)
  const [articles, setArticles] = useState<Article[]>([])
  const [loading, setLoading] = useState(true)
  const [page, setPage] = useState(0)
  const [hasMore, setHasMore] = useState(true)
  const [loadingMore, setLoadingMore] = useState(false)

  useEffect(() => {
    const init = async () => {
      const { data: catData } = await supabase.from('categories').select('*').eq('slug', slug).maybeSingle()
      setCat(catData)
      if (catData) {
        const { data } = await supabase.from('articles').select('*, authors(*), categories(*)')
          .eq('status', 'published').eq('category_id', catData.id)
          .order('created_at', { ascending: false }).range(0, PAGE - 1)
        setArticles(data || [])
        setHasMore((data?.length || 0) === PAGE)
      }
      setLoading(false)
    }
    init()
  }, [slug])

  const loadMore = async () => {
    if (!cat || !hasMore || loadingMore) return
    setLoadingMore(true)
    const next = page + 1
    const { data } = await supabase.from('articles').select('*, authors(*), categories(*)')
      .eq('status', 'published').eq('category_id', cat.id)
      .order('created_at', { ascending: false }).range(next * PAGE, (next + 1) * PAGE - 1)
    setArticles(prev => [...prev, ...(data || [])])
    setPage(next)
    setHasMore((data?.length || 0) === PAGE)
    setLoadingMore(false)
  }

  const SkRow = () => (
    <div className="rounded-xl overflow-hidden bg-white border border-ink-100">
      <div className="skeleton aspect-video" style={{ background: 'linear-gradient(90deg,#e8e0d6 25%,#f0e8de 50%,#e8e0d6 75%)', backgroundSize: '200% 100%' }} />
      <div className="p-4 space-y-2">
        <div className="skeleton h-3 w-16 rounded" style={{ background: 'linear-gradient(90deg,#e8e0d6 25%,#f0e8de 50%,#e8e0d6 75%)', backgroundSize: '200% 100%' }} />
        <div className="skeleton h-4 w-full rounded" style={{ background: 'linear-gradient(90deg,#e8e0d6 25%,#f0e8de 50%,#e8e0d6 75%)', backgroundSize: '200% 100%' }} />
        <div className="skeleton h-4 w-3/4 rounded" style={{ background: 'linear-gradient(90deg,#e8e0d6 25%,#f0e8de 50%,#e8e0d6 75%)', backgroundSize: '200% 100%' }} />
      </div>
    </div>
  )

  return (
    <div className="min-h-screen" style={{ background: 'var(--cream)' }}>
      <Navbar />
      <div className="pt-20 pb-12 border-b border-ink-100" style={{ background: 'var(--parchment)' }}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 pt-10">
          <div className="flex items-center gap-2 text-xs font-mono text-ink-400 mb-6">
            <Link href="/" className="hover:text-amber transition-colors">Home</Link>
            <span>/</span>
            <span className="text-ink-600">{cat?.name || slug}</span>
          </div>
          <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }}>
            <div className="flex items-center gap-5">
              <span className="text-5xl">{cat?.name ? (ICONS[cat.name] || cat?.icon || '📂') : '📂'}</span>
              <div>
                <p className="text-xs font-mono uppercase tracking-widest mb-1" style={{ color: 'var(--amber)' }}>Category</p>
                <h1 className="font-serif font-bold text-4xl md:text-5xl text-ink-950">{loading ? '…' : (cat?.name || slug)}</h1>
                {cat?.description && <p className="font-sans text-ink-500 mt-2 max-w-xl">{cat.description}</p>}
              </div>
            </div>
          </motion.div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-12 md:py-16">
        {loading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {Array(6).fill(0).map((_, i) => <SkRow key={i} />)}
          </div>
        ) : !cat ? (
          <div className="text-center py-24">
            <p className="text-5xl mb-4">🔍</p>
            <h2 className="font-serif text-2xl font-bold text-ink-800 mb-3">Category not found</h2>
            <Link href="/" className="text-amber hover:underline">← Back to Home</Link>
          </div>
        ) : articles.length === 0 ? (
          <div className="text-center py-24">
            <p className="text-5xl mb-4">📭</p>
            <h2 className="font-serif text-2xl font-bold text-ink-800 mb-2">No articles yet</h2>
            <p className="font-sans text-ink-400 mb-6">Be the first to write about this topic.</p>
            <Link href="/write" className="inline-flex items-center gap-2 px-6 py-2.5 rounded-full text-sm font-semibold text-white transition-all hover:scale-105" style={{ background: 'var(--amber)' }}>
              Write an article
            </Link>
          </div>
        ) : (
          <>
            <p className="font-mono text-xs text-ink-400 uppercase tracking-wider mb-8">{articles.length} article{articles.length !== 1 ? 's' : ''}</p>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {articles.map((a, i) => <ArticleCard key={a.id} article={a} variant="default" index={i} />)}
            </div>
            {hasMore && (
              <div className="text-center mt-12">
                <button onClick={loadMore} disabled={loadingMore}
                  className="px-8 py-3 rounded-full border border-ink-300 font-sans font-medium text-ink-700 hover:border-amber hover:text-amber transition-all hover:scale-105 disabled:opacity-60">
                  {loadingMore ? 'Loading…' : 'Load more articles'}
                </button>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  )
}
