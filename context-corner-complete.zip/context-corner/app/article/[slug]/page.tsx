'use client'

import { useState, useEffect, useCallback, useRef } from 'react'
import Link from 'next/link'
import { useParams } from 'next/navigation'
import { motion, AnimatePresence } from 'framer-motion'
import Navbar from '@/components/Navbar'
import ArticleCard from '@/components/ArticleCard'
import { supabase } from '@/lib/supabase'
import type { Article } from '@/lib/supabase'
import { formatDistanceToNow } from 'date-fns'

function getSession(): string {
  try {
    let id = localStorage.getItem('cc_session')
    if (!id) { id = Math.random().toString(36).slice(2) + Date.now().toString(36); localStorage.setItem('cc_session', id) }
    return id
  } catch { return 'anon' }
}

export default function ArticlePage() {
  const { slug } = useParams<{ slug: string }>()
  const [article, setArticle] = useState<(Article & { authors?: any; categories?: any }) | null>(null)
  const [related, setRelated] = useState<Article[]>([])
  const [moreFromAuthor, setMoreFromAuthor] = useState<Article[]>([])
  const [loading, setLoading] = useState(true)
  const [notFound, setNotFound] = useState(false)
  const [bookmarked, setBookmarked] = useState(false)
  const [liked, setLiked] = useState(false)
  const [clapped, setClapped] = useState(false)
  const [likesCount, setLikesCount] = useState(0)
  const [clapsCount, setClapsCount] = useState(0)
  const [shareOpen, setShareOpen] = useState(false)
  const [copied, setCopied] = useState(false)
  const reactionTimer = useRef<ReturnType<typeof setTimeout>>()
  const viewed = useRef(false)

  const load = useCallback(async () => {
    const { data } = await supabase
      .from('articles')
      .select('*, authors(*), categories(*)')
      .eq('slug', slug)
      .eq('status', 'published')
      .maybeSingle()

    if (!data) { setNotFound(true); setLoading(false); return }
    setArticle(data)
    setLikesCount(data.likes_count || 0)
    setClapsCount(data.claps_count || 0)
    setLoading(false)

    try {
      const b: string[] = JSON.parse(localStorage.getItem('cc_bookmarks') || '[]')
      setBookmarked(b.includes(data.id))
    } catch {}

    const sid = getSession()
    const { data: rxns } = await supabase.from('reactions').select('type').eq('article_id', data.id).eq('session_id', sid)
    if (rxns) { setLiked(rxns.some(r => r.type === 'like')); setClapped(rxns.some(r => r.type === 'clap')) }

    if (data.category_id) {
      const { data: rel } = await supabase.from('articles').select('*, authors(*), categories(*)')
        .eq('status', 'published').eq('category_id', data.category_id).neq('id', data.id).limit(3)
      setRelated(rel || [])
    }
    if (data.author_id) {
      const { data: more } = await supabase.from('articles').select('*, authors(*), categories(*)')
        .eq('status', 'published').eq('author_id', data.author_id).neq('id', data.id).limit(3)
      setMoreFromAuthor(more || [])
    }
    if (!viewed.current) {
      viewed.current = true
      await supabase.from('articles').update({ views_count: (data.views_count || 0) + 1 }).eq('id', data.id)
    }
  }, [slug])

  useEffect(() => {
    load()
    const ch = supabase.channel(`art-${slug}`)
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'articles', filter: `slug=eq.${slug}` },
        (p) => { if (p.new) { setLikesCount((p.new as any).likes_count || 0); setClapsCount((p.new as any).claps_count || 0) } })
      .subscribe()
    return () => { supabase.removeChannel(ch) }
  }, [load, slug])

  const react = useCallback(async (type: 'like' | 'clap') => {
    if (!article) return
    clearTimeout(reactionTimer.current)
    const isLike = type === 'like'
    const active = isLike ? liked : clapped
    const setActive = isLike ? setLiked : setClapped
    const setCount = isLike ? setLikesCount : setClapsCount
    setActive(!active)
    setCount(c => Math.max(0, c + (active ? -1 : 1)))
    reactionTimer.current = setTimeout(async () => {
      const sid = getSession()
      const col = isLike ? 'likes_count' : 'claps_count'
      const cur = isLike ? article.likes_count : article.claps_count
      if (active) {
        await supabase.from('reactions').delete().eq('article_id', article.id).eq('type', type).eq('session_id', sid)
        await supabase.from('articles').update({ [col]: Math.max(0, (cur || 0) - 1) }).eq('id', article.id)
      } else {
        await supabase.from('reactions').upsert({ article_id: article.id, type, session_id: sid })
        await supabase.from('articles').update({ [col]: (cur || 0) + 1 }).eq('id', article.id)
      }
    }, 600)
  }, [article, liked, clapped])

  const toggleBookmark = () => {
    if (!article) return
    try {
      const b: string[] = JSON.parse(localStorage.getItem('cc_bookmarks') || '[]')
      const updated = bookmarked ? b.filter(id => id !== article.id) : [...b, article.id]
      localStorage.setItem('cc_bookmarks', JSON.stringify(updated))
      setBookmarked(!bookmarked)
      window.dispatchEvent(new Event('bookmarks-changed'))
    } catch {}
  }

  const copyLink = () => {
    navigator.clipboard.writeText(window.location.href).then(() => { setCopied(true); setTimeout(() => setCopied(false), 2000) })
  }

  if (loading) return (
    <div className="min-h-screen" style={{ background: 'var(--cream)' }}>
      <Navbar />
      <div className="pt-24 max-w-3xl mx-auto px-4 sm:px-6">
        <div className="space-y-4 mt-8">
          {[24, 40, 32, 500].map((h, i) => (
            <div key={i} className="skeleton rounded-xl" style={{ height: h, background: 'linear-gradient(90deg,#e8e0d6 25%,#f0e8de 50%,#e8e0d6 75%)', backgroundSize: '200% 100%' }} />
          ))}
        </div>
      </div>
    </div>
  )

  if (notFound) return (
    <div className="min-h-screen" style={{ background: 'var(--cream)' }}>
      <Navbar />
      <div className="pt-40 text-center px-4">
        <p className="text-6xl mb-4">📭</p>
        <h1 className="font-serif text-4xl font-bold text-ink-950 mb-3">Article Not Found</h1>
        <p className="text-ink-400 font-sans mb-8">This article may have been removed or the link is incorrect.</p>
        <Link href="/" className="inline-flex items-center gap-2 px-6 py-2.5 rounded-full text-sm font-semibold text-white transition-all hover:scale-105"
          style={{ background: 'var(--amber)' }}>← Back to Home</Link>
      </div>
    </div>
  )

  return (
    <div className="min-h-screen" style={{ background: 'var(--cream)' }}>
      <Navbar />
      {article?.cover_image && (
        <div className="relative w-full overflow-hidden mt-16" style={{ maxHeight: '55vh' }}>
          <img src={article.cover_image} alt={article.title} className="w-full h-full object-cover" style={{ maxHeight: '55vh' }} />
          <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-cream" />
        </div>
      )}

      <div className={`max-w-3xl mx-auto px-4 sm:px-6 ${article?.cover_image ? 'pt-6' : 'pt-28'} pb-20`}>
        <motion.article initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4 }}>
          {/* Tags + category */}
          <div className="flex flex-wrap items-center gap-2 mb-5">
            {article?.categories && (
              <Link href={`/category/${article.categories.slug}`}
                className="px-3 py-1 rounded-full text-xs font-mono font-bold uppercase tracking-wider text-white"
                style={{ background: 'var(--amber)' }}>
                {article.categories.name}
              </Link>
            )}
            {(article?.tags || []).slice(0, 4).map(tag => (
              <Link key={tag} href={`/tag/${encodeURIComponent(tag.toLowerCase().replace(/\s+/g, '-'))}`}
                className="px-2.5 py-1 rounded-full text-xs font-mono text-ink-500 border border-ink-200 hover:border-amber hover:text-amber transition-colors">
                #{tag}
              </Link>
            ))}
          </div>

          <h1 className="font-serif font-bold text-3xl md:text-5xl text-ink-950 leading-tight mb-5">
            {article?.title}
          </h1>

          {article?.excerpt && (
            <p className="font-sans text-lg text-ink-500 leading-relaxed mb-7 pl-4 border-l-2" style={{ borderColor: 'var(--amber)' }}>
              {article.excerpt}
            </p>
          )}

          {/* Meta row */}
          <div className="flex items-center justify-between py-5 border-y border-ink-100 mb-10">
            {article?.authors ? (
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 rounded-full overflow-hidden bg-parchment flex-shrink-0">
                  {article.authors.avatar_url
                    ? <img src={article.authors.avatar_url} alt={article.authors.name} className="w-full h-full object-cover" />
                    : <div className="w-full h-full flex items-center justify-center font-serif text-xl font-bold" style={{ color: 'var(--amber)' }}>{article.authors.name?.[0]}</div>
                  }
                </div>
                <div>
                  <p className="font-sans font-semibold text-sm text-ink-900">{article.authors.name}</p>
                  <div className="flex items-center gap-2 text-xs text-ink-400 mt-0.5">
                    <span>{article.reading_time} min read</span>
                    <span>·</span>
                    <span>{article?.created_at ? formatDistanceToNow(new Date(article.created_at), { addSuffix: true }) : ''}</span>
                    <span>·</span>
                    <span>{(article?.views_count || 0).toLocaleString()} views</span>
                  </div>
                </div>
              </div>
            ) : <div />}

            <div className="flex items-center gap-2">
              <button onClick={toggleBookmark}
                className={`p-2.5 rounded-full border transition-all hover:scale-105 ${bookmarked ? 'border-amber text-amber bg-amber/10' : 'border-ink-200 text-ink-400 hover:border-amber hover:text-amber'}`}>
                <svg className="w-4 h-4" fill={bookmarked ? 'currentColor' : 'none'} stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
                  <path d="m19 21-7-4-7 4V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v16z" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
              </button>
              <div className="relative">
                <button onClick={() => setShareOpen(!shareOpen)}
                  className="p-2.5 rounded-full border border-ink-200 text-ink-400 hover:border-amber hover:text-amber transition-all hover:scale-105">
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
                    <circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/>
                    <line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/>
                  </svg>
                </button>
                <AnimatePresence>
                  {shareOpen && (
                    <motion.div initial={{ opacity: 0, scale: 0.9, y: 8 }} animate={{ opacity: 1, scale: 1, y: 0 }} exit={{ opacity: 0, scale: 0.9, y: 8 }}
                      className="absolute right-0 top-full mt-2 bg-white rounded-xl shadow-xl border border-ink-100 p-2 min-w-[170px] z-20">
                      <button onClick={copyLink} className="flex items-center gap-2 w-full px-3 py-2 text-sm text-ink-600 hover:text-amber hover:bg-parchment rounded-lg transition-colors">
                        {copied ? '✅ Copied!' : '🔗 Copy link'}
                      </button>
                      <a href={`https://twitter.com/intent/tweet?text=${encodeURIComponent(article?.title || '')}&url=${encodeURIComponent(typeof window !== 'undefined' ? window.location.href : '')}`}
                        target="_blank" rel="noopener noreferrer"
                        className="flex items-center gap-2 w-full px-3 py-2 text-sm text-ink-600 hover:text-amber hover:bg-parchment rounded-lg transition-colors">
                        🐦 Share on X
                      </a>
                      <a href={`https://wa.me/?text=${encodeURIComponent((article?.title || '') + ' ' + (typeof window !== 'undefined' ? window.location.href : ''))}`}
                        target="_blank" rel="noopener noreferrer"
                        className="flex items-center gap-2 w-full px-3 py-2 text-sm text-ink-600 hover:text-amber hover:bg-parchment rounded-lg transition-colors">
                        💬 Share on WhatsApp
                      </a>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </div>
          </div>

          {/* Article content */}
          <div className="article-content"
            dangerouslySetInnerHTML={{ __html: article?.content || '<p>Content loading…</p>' }} />

          {/* Reactions */}
          <div className="flex items-center justify-center gap-8 py-12 my-12 border-y border-ink-100">
            <div className="text-center">
              <motion.button onClick={() => react('like')} whileTap={{ scale: 0.75 }}
                className={`w-14 h-14 rounded-full flex items-center justify-center text-2xl border-2 transition-all mx-auto mb-1 ${liked ? 'border-red-400 bg-red-50 shadow-md' : 'border-ink-200 hover:border-red-300 hover:bg-red-50/50'}`}>
                {liked ? '❤️' : '🤍'}
              </motion.button>
              <p className="text-sm font-mono font-bold text-ink-600">{likesCount}</p>
              <p className="text-xs text-ink-400 mt-0.5">Like</p>
            </div>
            <div className="w-px h-14 bg-ink-100" />
            <div className="text-center">
              <motion.button onClick={() => react('clap')} whileTap={{ scale: 0.75, rotate: -15 }}
                className={`w-14 h-14 rounded-full flex items-center justify-center text-2xl border-2 transition-all mx-auto mb-1 ${clapped ? 'border-amber bg-amber/10 shadow-md' : 'border-ink-200 hover:border-amber/50 hover:bg-amber/5'}`}>
                👏
              </motion.button>
              <p className="text-sm font-mono font-bold text-ink-600">{clapsCount}</p>
              <p className="text-xs text-ink-400 mt-0.5">Clap</p>
            </div>
          </div>

          {/* Author bio */}
          {article?.authors && (
            <div className="rounded-2xl p-6 mb-10" style={{ background: 'var(--parchment)' }}>
              <div className="flex items-start gap-4">
                <div className="w-16 h-16 rounded-full overflow-hidden bg-ink-200 flex-shrink-0">
                  {article.authors.avatar_url
                    ? <img src={article.authors.avatar_url} alt={article.authors.name} className="w-full h-full object-cover" />
                    : <div className="w-full h-full flex items-center justify-center font-serif text-2xl font-bold" style={{ color: 'var(--amber)' }}>{article.authors.name?.[0]}</div>
                  }
                </div>
                <div>
                  <p className="text-xs font-mono uppercase tracking-wider mb-1" style={{ color: 'var(--amber)' }}>About the author</p>
                  <h3 className="font-serif font-bold text-lg text-ink-950">{article.authors.name}</h3>
                  {article.authors.role && <p className="text-xs font-mono text-ink-400 uppercase tracking-wider my-1">{article.authors.role}</p>}
                  {article.authors.bio && <p className="font-sans text-sm text-ink-600 leading-relaxed mt-1">{article.authors.bio}</p>}
                </div>
              </div>
            </div>
          )}
        </motion.article>

        {/* More from author */}
        {moreFromAuthor.length > 0 && (
          <section className="mb-14">
            <div className="ornamental-divider mb-8">
              <span className="font-mono text-xs uppercase tracking-widest text-amber px-4">More from {article?.authors?.name}</span>
            </div>
            <div>
              {moreFromAuthor.map((a, i) => <ArticleCard key={a.id} article={a} variant="compact" index={i} />)}
            </div>
          </section>
        )}

        {/* Related */}
        {related.length > 0 && (
          <section className="mb-16">
            <div className="ornamental-divider mb-8">
              <span className="font-mono text-xs uppercase tracking-widest text-amber px-4">Related Stories</span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
              {related.map((a, i) => <ArticleCard key={a.id} article={a} variant="featured" index={i} />)}
            </div>
          </section>
        )}
      </div>
    </div>
  )
}
