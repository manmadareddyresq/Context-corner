'use client'

import { useState, useEffect, useCallback } from 'react'
import Link from 'next/link'
import { motion } from 'framer-motion'
import Navbar from '@/components/Navbar'
import ArticleCard from '@/components/ArticleCard'
import { supabase } from '@/lib/supabase'
import type { Article } from '@/lib/supabase'

export default function BookmarksPage() {
  const [articles, setArticles] = useState<Article[]>([])
  const [loading, setLoading] = useState(true)

  const loadBookmarks = useCallback(async () => {
    try {
      const ids: string[] = JSON.parse(localStorage.getItem('cc_bookmarks') || '[]')
      if (!Array.isArray(ids) || ids.length === 0) { setLoading(false); return }
      const { data } = await supabase.from('articles').select('*, authors(*), categories(*)')
        .in('id', ids).eq('status', 'published')
      if (data) {
        // Remove stale bookmarks (deleted articles)
        const valid = ids.filter(id => data.some(a => a.id === id))
        localStorage.setItem('cc_bookmarks', JSON.stringify(valid))
        window.dispatchEvent(new Event('bookmarks-changed'))
        setArticles(data)
      } else {
        localStorage.removeItem('cc_bookmarks')
      }
    } catch {}
    setLoading(false)
  }, [])

  useEffect(() => {
    loadBookmarks()
    window.addEventListener('bookmarks-changed', loadBookmarks)
    return () => window.removeEventListener('bookmarks-changed', loadBookmarks)
  }, [loadBookmarks])

  const clearAll = () => {
    localStorage.removeItem('cc_bookmarks')
    setArticles([])
    window.dispatchEvent(new Event('bookmarks-changed'))
  }

  return (
    <div className="min-h-screen" style={{ background: 'var(--cream)' }}>
      <Navbar />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 pt-28 pb-20">
        <div className="flex items-center gap-2 text-xs font-mono text-ink-400 mb-8">
          <Link href="/" className="hover:text-amber transition-colors">Home</Link>
          <span>/</span>
          <span className="text-ink-600">Bookmarks</span>
        </div>

        <div className="flex items-center justify-between mb-10">
          <div>
            <p className="text-xs font-mono uppercase tracking-widest mb-2" style={{ color: 'var(--amber)' }}>Saved</p>
            <h1 className="font-serif font-bold text-4xl text-ink-950">Your Bookmarks</h1>
            {articles.length > 0 && (
              <p className="font-sans text-sm text-ink-400 mt-1">{articles.length} article{articles.length !== 1 ? 's' : ''} saved</p>
            )}
          </div>
          {articles.length > 0 && (
            <button onClick={clearAll} className="text-sm font-sans text-ink-400 hover:text-red-400 transition-colors">
              Clear all
            </button>
          )}
        </div>

        {loading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {Array(3).fill(0).map((_, i) => (
              <div key={i} className="h-64 rounded-xl skeleton" style={{ background: 'linear-gradient(90deg,#e8e0d6 25%,#f0e8de 50%,#e8e0d6 75%)', backgroundSize: '200% 100%' }} />
            ))}
          </div>
        ) : articles.length === 0 ? (
          <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} className="text-center py-24">
            <p className="text-6xl mb-4">🔖</p>
            <h2 className="font-serif text-2xl font-bold text-ink-800 mb-3">No bookmarks yet</h2>
            <p className="font-sans text-ink-400 mb-8 max-w-sm mx-auto">
              Tap the bookmark icon on any article to save it here for later.
            </p>
            <Link href="/" className="inline-flex items-center gap-2 px-6 py-2.5 rounded-full text-sm font-semibold text-white transition-all hover:scale-105"
              style={{ background: 'var(--amber)' }}>
              Explore articles
            </Link>
          </motion.div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {articles.map((a, i) => <ArticleCard key={a.id} article={a} variant="default" index={i} />)}
          </div>
        )}
      </div>
    </div>
  )
}
