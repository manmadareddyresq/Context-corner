'use client'

import { useState, useEffect, useRef } from 'react'
import Link from 'next/link'
import { motion, useScroll, useTransform, AnimatePresence } from 'framer-motion'
import Navbar from '@/components/Navbar'
import ArticleCard from '@/components/ArticleCard'
import { supabase } from '@/lib/supabase'
import type { Article, Category, Achievement, Announcement } from '@/lib/supabase'

function SkeletonCard() {
  return (
    <div className="rounded-xl overflow-hidden bg-white border border-ink-100">
      <div className="skeleton aspect-[16/9] w-full" />
      <div className="p-4 space-y-2">
        <div className="skeleton h-3 w-16 rounded" />
        <div className="skeleton h-4 w-full rounded" />
        <div className="skeleton h-4 w-3/4 rounded" />
      </div>
    </div>
  )
}

function HeroSection({ article }: { article: (Article & { authors?: any; categories?: any }) | null }) {
  const ref = useRef<HTMLDivElement>(null)
  const { scrollYProgress } = useScroll({ target: ref, offset: ['start start', 'end start'] })
  const y = useTransform(scrollYProgress, [0, 1], ['0%', '30%'])
  const opacity = useTransform(scrollYProgress, [0, 0.7], [1, 0])

  if (!article) return null

  return (
    <div ref={ref} className="relative min-h-[85vh] flex items-end overflow-hidden">
      <motion.div className="absolute inset-0" style={{ y }}>
        {article.cover_image ? (
          <img src={article.cover_image} alt={article.title} className="w-full h-full object-cover scale-110" />
        ) : (
          <div className="w-full h-full" style={{ background: 'linear-gradient(135deg,#1a1714 0%,#4a4137 50%,#9b7228 100%)' }} />
        )}
        <div className="absolute inset-0" style={{ background: 'linear-gradient(to top,rgba(15,14,13,0.95) 0%,rgba(15,14,13,0.5) 50%,rgba(15,14,13,0.2) 100%)' }} />
      </motion.div>

      <motion.div style={{ opacity }} className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 pb-16 md:pb-24 w-full">
        <motion.div initial={{ opacity: 0, y: 40 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8, ease: [0.25, 0.46, 0.45, 0.94], delay: 0.2 }}>
          <div className="flex items-center gap-3 mb-6">
            <span className="px-3 py-1 rounded-full text-xs font-mono font-bold uppercase tracking-widest text-white" style={{ background: 'var(--amber)' }}>
              Featured
            </span>
            {article.categories && <span className="text-sm font-sans text-white/70">{article.categories.name}</span>}
          </div>
          <Link href={`/article/${article.slug}`}>
            <h1 className="font-serif font-bold text-4xl md:text-6xl lg:text-7xl text-white leading-tight max-w-4xl mb-6 hover:text-amber transition-colors duration-300 cursor-pointer">
              {article.title}
            </h1>
          </Link>
          {article.excerpt && (
            <p className="font-sans text-lg md:text-xl text-white/70 max-w-2xl leading-relaxed mb-8">{article.excerpt}</p>
          )}
          <div className="flex flex-wrap items-center gap-6">
            {article.authors && (
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full overflow-hidden border-2 border-white/30">
                  {article.authors.avatar_url ? (
                    <img src={article.authors.avatar_url} alt={article.authors.name} className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center font-serif font-bold text-amber" style={{ background: 'rgba(255,255,255,0.1)' }}>
                      {article.authors.name?.[0]}
                    </div>
                  )}
                </div>
                <div>
                  <p className="text-white font-medium text-sm">{article.authors.name}</p>
                  <p className="text-white/50 text-xs">{article.reading_time} min read</p>
                </div>
              </div>
            )}
            <Link href={`/article/${article.slug}`}
              className="flex items-center gap-2 px-6 py-2.5 rounded-full font-sans font-semibold text-white text-sm transition-all hover:scale-105 active:scale-95"
              style={{ background: 'var(--amber)' }}>
              Read Article
              <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth={2.5} viewBox="0 0 24 24">
                <path d="M5 12h14M12 5l7 7-7 7" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            </Link>
          </div>
        </motion.div>
      </motion.div>
    </div>
  )
}

export default function HomePage() {
  const [announcement, setAnnouncement] = useState<Announcement | null>(null)
  const [heroArticle, setHeroArticle] = useState<(Article & { authors?: any; categories?: any }) | null>(null)
  const [featuredArticles, setFeaturedArticles] = useState<Article[]>([])
  const [trending, setTrending] = useState<Article[]>([])
  const [latest, setLatest] = useState<Article[]>([])
  const [categories, setCategories] = useState<Category[]>([])
  const [achievements, setAchievements] = useState<Achievement[]>([])
  const [allTags, setAllTags] = useState<string[]>([])
  const [loading, setLoading] = useState(true)
  const [announcementDismissed, setAnnouncementDismissed] = useState(false)

  const fetchData = async () => {
    try {
      const [annRes, articlesRes, trendingRes, latestRes, catsRes, achRes] = await Promise.all([
        supabase.from('announcements').select('*').eq('active', true).order('created_at', { ascending: false }).limit(1).maybeSingle(),
        supabase.from('articles').select('*, authors(*), categories(*)').eq('status', 'published').eq('featured', true).order('created_at', { ascending: false }).limit(5),
        supabase.from('articles').select('*, authors(*), categories(*)').eq('status', 'published').order('views_count', { ascending: false }).limit(5),
        supabase.from('articles').select('*, authors(*), categories(*)').eq('status', 'published').order('created_at', { ascending: false }).limit(9),
        supabase.from('categories').select('*').limit(8),
        supabase.from('achievements').select('*').limit(6),
      ])

      if (annRes.data) setAnnouncement(annRes.data)
      if (articlesRes.data && articlesRes.data.length > 0) {
        setHeroArticle(articlesRes.data[0])
        setFeaturedArticles(articlesRes.data.slice(1))
      } else if (latestRes.data && latestRes.data.length > 0) {
        // fallback: use latest if no featured
        setHeroArticle(latestRes.data[0])
      }
      if (trendingRes.data) setTrending(trendingRes.data)
      if (latestRes.data) {
        setLatest(latestRes.data)
        const tags = latestRes.data.flatMap((a: Article) => a.tags || [])
        setAllTags(Array.from(new Set(tags)).slice(0, 20))
      }
      if (catsRes.data) setCategories(catsRes.data)
      if (achRes.data) setAchievements(achRes.data)
    } catch (e) {
      console.error('Fetch error:', e)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchData()
    const dismissed = sessionStorage.getItem('announcement_dismissed')
    if (dismissed) setAnnouncementDismissed(true)

    const channel = supabase.channel('homepage-realtime')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'articles' }, fetchData)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'announcements' }, fetchData)
      .subscribe()

    return () => { supabase.removeChannel(channel) }
  }, [])

  const dismissAnnouncement = () => {
    setAnnouncementDismissed(true)
    sessionStorage.setItem('announcement_dismissed', '1')
  }

  const categoryIcons: Record<string, string> = {
    Technology: '💻', Culture: '🎭', Politics: '⚖️', Science: '🔬',
    Arts: '🎨', Business: '📈', Health: '🌿', Environment: '🌍',
  }

  return (
    <div className="min-h-screen" style={{ background: 'var(--cream)' }}>
      <Navbar />

      {/* Announcement Banner */}
      <AnimatePresence>
        {announcement && !announcementDismissed && (
          <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }}
            className="announcement-banner overflow-hidden">
            <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between gap-4">
              <div className="flex items-center gap-3 flex-1 min-w-0">
                <span className="text-amber text-sm flex-shrink-0">📣</span>
                <p className="text-white/90 text-sm font-sans truncate">{announcement.message}</p>
                {announcement.link && (
                  <Link href={announcement.link} className="flex-shrink-0 text-amber text-sm font-medium hover:underline">
                    {announcement.link_text || 'Learn more'} →
                  </Link>
                )}
              </div>
              <button onClick={dismissAnnouncement} className="text-white/50 hover:text-white transition-colors flex-shrink-0">
                <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
                  <path d="M18 6L6 18M6 6l12 12" strokeLinecap="round" />
                </svg>
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Hero */}
      <div className="pt-16">
        {loading ? (
          <div className="min-h-[85vh] flex items-center justify-center" style={{ background: 'linear-gradient(135deg,#1a1714,#332e28)' }}>
            <div className="w-8 h-8 rounded-full border-2 border-amber border-t-transparent animate-spin" />
          </div>
        ) : heroArticle ? (
          <HeroSection article={heroArticle} />
        ) : (
          <div className="min-h-[85vh] flex items-center justify-center" style={{ background: 'linear-gradient(135deg,#1a1714,#332e28)' }}>
            <div className="text-center px-4">
              <h1 className="font-serif text-5xl font-bold text-white mb-4">Welcome to Context Corner</h1>
              <p className="font-sans text-white/60 text-lg mb-8">Premium editorial platform for thoughtful perspectives.</p>
              <Link href="/write" className="inline-flex items-center gap-2 px-8 py-3.5 rounded-full font-bold text-ink-950"
                style={{ background: 'var(--amber)' }}>Start Writing</Link>
            </div>
          </div>
        )}
      </div>

      {/* Featured Articles */}
      {(featuredArticles.length > 0 || loading) && (
        <section className="max-w-7xl mx-auto px-4 sm:px-6 py-16 md:py-24">
          <div className="flex items-center justify-between mb-10">
            <div>
              <p className="text-xs font-mono text-amber uppercase tracking-widest mb-2">Handpicked</p>
              <h2 className="font-serif text-3xl md:text-4xl font-bold text-ink-950">Featured Stories</h2>
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {loading ? Array(4).fill(0).map((_, i) => <SkeletonCard key={i} />) :
              featuredArticles.map((article, i) => (
                <ArticleCard key={article.id} article={article} variant="featured" index={i} />
              ))}
          </div>
        </section>
      )}

      {/* Divider */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="ornamental-divider"><span className="text-amber text-xl">✦</span></div>
      </div>

      {/* Trending + Sidebar */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 py-16 md:py-24">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          {/* Trending */}
          <div className="lg:col-span-2">
            <div className="flex items-center gap-2 mb-2">
              <svg className="w-4 h-4 text-amber" fill="currentColor" viewBox="0 0 24 24">
                <path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z" />
              </svg>
              <span className="text-xs font-mono text-amber uppercase tracking-widest">Trending Now</span>
            </div>
            <h2 className="font-serif text-2xl font-bold text-ink-950 mb-8">Most Read This Week</h2>
            <div>
              {loading ? Array(5).fill(0).map((_, i) => (
                <div key={i} className="py-4 border-b border-ink-100 flex gap-4">
                  <div className="skeleton w-8 h-6 rounded" />
                  <div className="flex-1 space-y-2">
                    <div className="skeleton h-4 w-full rounded" />
                    <div className="skeleton h-3 w-1/2 rounded" />
                  </div>
                </div>
              )) : trending.map((article, i) => (
                <motion.div key={article.id} initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.08 }} className="group">
                  <Link href={`/article/${article.slug}`} className="flex items-start gap-4 py-5 border-b border-ink-100 hover:bg-parchment/30 transition-colors -mx-3 px-3 rounded-lg">
                    <span className="font-mono font-bold text-2xl text-amber/30 leading-none mt-1 w-8 text-right flex-shrink-0">
                      {String(i + 1).padStart(2, '0')}
                    </span>
                    <div className="flex-1 min-w-0">
                      {(article as any).categories && (
                        <span className="text-xs font-mono text-amber uppercase tracking-wider">{(article as any).categories.name}</span>
                      )}
                      <h3 className="font-serif font-bold text-base text-ink-900 group-hover:text-amber transition-colors leading-snug mt-0.5 line-clamp-2">{article.title}</h3>
                      <div className="flex items-center gap-2 mt-1.5 text-xs text-ink-400">
                        {(article as any).authors && <span>{(article as any).authors.name}</span>}
                        <span>·</span>
                        <span className="flex items-center gap-1">
                          <svg className="w-3 h-3" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
                            <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" /><circle cx="12" cy="12" r="3" />
                          </svg>
                          {(article.views_count || 0).toLocaleString()} views
                        </span>
                      </div>
                    </div>
                    {article.cover_image && (
                      <div className="w-16 h-12 rounded-lg overflow-hidden flex-shrink-0 bg-ink-100">
                        <img src={article.cover_image} alt={article.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                      </div>
                    )}
                  </Link>
                </motion.div>
              ))}
              {!loading && trending.length === 0 && (
                <p className="text-ink-400 text-sm py-8 text-center font-sans">No trending articles yet. Publish some articles to get started!</p>
              )}
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-10">
            {/* Categories */}
            <div>
              <p className="text-xs font-mono text-amber uppercase tracking-widest mb-2">Explore</p>
              <h2 className="font-serif text-2xl font-bold text-ink-950 mb-6">Categories</h2>
              <div className="space-y-2">
                {loading ? Array(5).fill(0).map((_, i) => (
                  <div key={i} className="skeleton h-12 rounded-lg" />
                )) : categories.length === 0 ? (
                  <p className="text-ink-400 text-sm font-sans">No categories yet.</p>
                ) : categories.map((cat, i) => (
                  <motion.div key={cat.id} initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.06 }}>
                    <Link href={`/category/${cat.slug}`}
                      className="flex items-center justify-between p-3 rounded-xl border border-ink-100 bg-white hover:border-amber/30 hover:bg-parchment/50 transition-all group">
                      <div className="flex items-center gap-3">
                        <span className="text-xl">{categoryIcons[cat.name] || cat.icon || '📂'}</span>
                        <div>
                          <p className="font-sans font-semibold text-sm text-ink-800 group-hover:text-amber transition-colors">{cat.name}</p>
                          {cat.description && <p className="text-xs text-ink-400 line-clamp-1">{cat.description}</p>}
                        </div>
                      </div>
                      <svg className="w-4 h-4 text-ink-300 group-hover:text-amber transition-colors" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
                        <path d="M9 18l6-6-6-6" strokeLinecap="round" strokeLinejoin="round" />
                      </svg>
                    </Link>
                  </motion.div>
                ))}
              </div>
            </div>

            {/* Achievements */}
            {achievements.length > 0 && (
              <div>
                <p className="text-xs font-mono text-amber uppercase tracking-widest mb-2">Milestones</p>
                <h2 className="font-serif text-2xl font-bold text-ink-950 mb-6">Achievements</h2>
                <div className="space-y-3">
                  {achievements.map((ach, i) => (
                    <motion.div key={ach.id} initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: i * 0.07 }}
                      className="flex items-center gap-3 p-3 rounded-xl border border-ink-100 bg-white">
                      <div className="w-10 h-10 rounded-full flex items-center justify-center text-xl flex-shrink-0"
                        style={{ background: ach.color ? `${ach.color}20` : 'var(--parchment)' }}>
                        {ach.icon || '🏆'}
                      </div>
                      <div>
                        <p className="font-sans font-semibold text-sm text-ink-800">{ach.title}</p>
                        {ach.description && <p className="text-xs text-ink-400 line-clamp-1">{ach.description}</p>}
                      </div>
                    </motion.div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Latest Articles */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 py-8 md:py-16">
        <div className="mb-10">
          <p className="text-xs font-mono text-amber uppercase tracking-widest mb-2">Fresh</p>
          <h2 className="font-serif text-3xl md:text-4xl font-bold text-ink-950">Latest Articles</h2>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {loading ? Array(6).fill(0).map((_, i) => <SkeletonCard key={i} />) :
            latest.length === 0 ? (
              <div className="col-span-3 text-center py-16">
                <p className="text-5xl mb-4">📝</p>
                <p className="font-serif text-xl font-bold text-ink-800 mb-2">No articles yet</p>
                <p className="font-sans text-ink-400 mb-6">Go to <Link href="/admin" className="text-amber hover:underline">/admin</Link> and publish your first article!</p>
              </div>
            ) : latest.map((article, i) => (
              <ArticleCard key={article.id} article={article} variant="default" index={i} />
            ))}
        </div>
      </section>

      {/* Tags Cloud */}
      {allTags.length > 0 && (
        <section className="max-w-7xl mx-auto px-4 sm:px-6 py-12 md:py-16">
          <div className="ornamental-divider mb-12"><span className="text-amber text-xl">✦</span></div>
          <div className="text-center mb-8">
            <p className="text-xs font-mono text-amber uppercase tracking-widest mb-2">Discover</p>
            <h2 className="font-serif text-3xl font-bold text-ink-950">Explore by Topic</h2>
          </div>
          <div className="flex flex-wrap justify-center gap-3">
            {allTags.map((tag, i) => (
              <motion.div key={tag} initial={{ opacity: 0, scale: 0.8 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: i * 0.04 }}>
                <Link href={`/tag/${encodeURIComponent(tag.toLowerCase().replace(/\s+/g, '-'))}`}
                  className="inline-flex items-center px-4 py-2 rounded-full border border-ink-200 bg-white font-sans text-sm text-ink-600 hover:border-amber hover:text-amber hover:bg-parchment transition-all duration-200 hover:scale-105">
                  #{tag}
                </Link>
              </motion.div>
            ))}
          </div>
        </section>
      )}

      {/* Write CTA */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 py-12 md:py-20">
        <motion.div initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.6 }}
          className="relative overflow-hidden rounded-2xl p-10 md:p-16 text-center"
          style={{ background: 'linear-gradient(135deg,#1a1714 0%,#332e28 50%,#4a4137 100%)' }}>
          <div className="absolute top-0 right-0 w-64 h-64 rounded-full opacity-10"
            style={{ background: 'var(--amber)', filter: 'blur(80px)', transform: 'translate(30%,-30%)' }} />
          <div className="relative z-10">
            <p className="text-xs font-mono text-amber uppercase tracking-widest mb-4">Your Voice Matters</p>
            <h2 className="font-serif text-4xl md:text-5xl font-bold text-white mb-4">Have a Story to Tell?</h2>
            <p className="font-sans text-lg text-white/60 max-w-xl mx-auto mb-8 leading-relaxed">
              Share your perspective with the Context Corner community. No login required.
            </p>
            <Link href="/write"
              className="inline-flex items-center gap-2 px-8 py-3.5 rounded-full font-sans font-bold text-ink-950 transition-all hover:scale-105 active:scale-95 shadow-lg"
              style={{ background: 'linear-gradient(135deg,var(--amber-light),var(--amber))' }}>
              <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth={2.5} viewBox="0 0 24 24">
                <path d="M12 5v14M5 12h14" strokeLinecap="round" />
              </svg>
              Start Writing
            </Link>
          </div>
        </motion.div>
      </section>

      {/* Footer */}
      <footer className="border-t border-ink-200/50 mt-8" style={{ background: '#0f0e0d' }}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-12">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-10">
            <div className="md:col-span-2">
              <div className="flex items-center gap-2 mb-4">
                <div className="w-8 h-8 rounded-sm flex items-center justify-center" style={{ background: 'var(--amber)' }}>
                  <span className="font-serif text-white font-bold text-sm">C</span>
                </div>
                <span className="font-serif text-xl font-bold text-white">Context Corner</span>
              </div>
              <p className="font-sans text-sm text-white/40 leading-relaxed max-w-xs">
                A premium editorial platform for thoughtful perspectives, cultural commentary, and deep-dives.
              </p>
            </div>
            <div>
              <h4 className="font-mono text-xs text-amber uppercase tracking-wider mb-4">Explore</h4>
              <ul className="space-y-2.5">
                {[['Home', '/'], ['Write', '/write'], ['Terms', '/terms']].map(([item, href]) => (
                  <li key={item}>
                    <Link href={href} className="font-sans text-sm text-white/40 hover:text-amber transition-colors">{item}</Link>
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <h4 className="font-mono text-xs text-amber uppercase tracking-wider mb-4">Categories</h4>
              <ul className="space-y-2.5">
                {categories.slice(0, 4).map(cat => (
                  <li key={cat.id}>
                    <Link href={`/category/${cat.slug}`} className="font-sans text-sm text-white/40 hover:text-amber transition-colors">{cat.name}</Link>
                  </li>
                ))}
              </ul>
            </div>
          </div>
          <div className="border-t border-white/10 pt-8 flex flex-col md:flex-row items-center justify-between gap-4">
            <p className="text-xs font-mono text-white/25">© {new Date().getFullYear()} Context Corner. All rights reserved.</p>
            <Link href="/admin" className="text-xs font-mono text-white/20 hover:text-amber transition-colors">Admin ↗</Link>
          </div>
        </div>
      </footer>
    </div>
  )
}
