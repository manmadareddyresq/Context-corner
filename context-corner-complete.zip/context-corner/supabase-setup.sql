-- ============================================================
-- CONTEXT CORNER — Complete Database Setup
-- Run this ENTIRE file in Supabase SQL Editor → Run
-- ============================================================

-- Drop existing tables (clean slate)
drop table if exists reactions cascade;
drop table if exists articles cascade;
drop table if exists submissions cascade;
drop table if exists authors cascade;
drop table if exists categories cascade;
drop table if exists tags cascade;
drop table if exists achievements cascade;
drop table if exists announcements cascade;
drop table if exists settings cascade;
drop table if exists admin cascade;

-- ── CREATE TABLES ─────────────────────────────────────────────

create table authors (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  bio text,
  avatar_url text,
  role text,
  social_links jsonb,
  created_at timestamptz default now()
);

create table categories (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  slug text unique not null,
  description text,
  color text,
  icon text,
  created_at timestamptz default now()
);

create table tags (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  slug text unique not null,
  created_at timestamptz default now()
);

create table articles (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  slug text unique not null,
  excerpt text,
  content text,
  cover_image text,
  author_id uuid references authors(id) on delete set null,
  category_id uuid references categories(id) on delete set null,
  status text default 'draft' check (status in ('draft','published')),
  featured boolean default false,
  views_count integer default 0,
  likes_count integer default 0,
  claps_count integer default 0,
  reading_time integer default 5,
  tags text[] default '{}',
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create table submissions (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  content text not null,
  author_name text not null,
  author_email text not null,
  status text default 'pending' check (status in ('pending','approved','rejected')),
  tags text[] default '{}',
  created_at timestamptz default now()
);

create table reactions (
  id uuid primary key default gen_random_uuid(),
  article_id uuid references articles(id) on delete cascade,
  type text check (type in ('like','clap')),
  session_id text not null,
  created_at timestamptz default now(),
  unique(article_id, type, session_id)
);

create table achievements (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text,
  icon text,
  color text,
  created_at timestamptz default now()
);

create table announcements (
  id uuid primary key default gen_random_uuid(),
  message text not null,
  active boolean default true,
  link text,
  link_text text,
  created_at timestamptz default now()
);

create table settings (
  id uuid primary key default gen_random_uuid(),
  key text unique not null,
  value text,
  updated_at timestamptz default now()
);

create table admin (
  id uuid primary key default gen_random_uuid(),
  username text unique not null,
  password text not null,
  created_at timestamptz default now()
);

-- ── SEED: ADMIN ───────────────────────────────────────────────
insert into admin (username, password) values ('Manmada', 'Abc123');

-- ── SEED: AUTHORS ─────────────────────────────────────────────
insert into authors (id, name, bio, role, avatar_url) values
  ('a1000000-0000-0000-0000-000000000001', 'Arjun Mehta', 'Senior technology journalist covering AI, startups, and the future of work. Previously at The Hindu and TechCrunch India.', 'Senior Technology Writer', 'https://i.pravatar.cc/150?img=11'),
  ('a1000000-0000-0000-0000-000000000002', 'Priya Nair', 'Cultural critic and essayist. Writes about cinema, literature, and identity in contemporary India. Author of two books.', 'Culture Editor', 'https://i.pravatar.cc/150?img=47'),
  ('a1000000-0000-0000-0000-000000000003', 'Rahul Sharma', 'Environmental journalist and policy analyst. Covers climate change, renewable energy, and South Asian politics.', 'Environment Correspondent', 'https://i.pravatar.cc/150?img=15'),
  ('a1000000-0000-0000-0000-000000000004', 'Kavitha Iyer', 'Science communicator and researcher. PhD in molecular biology, now making complex science accessible to everyone.', 'Science Editor', 'https://i.pravatar.cc/150?img=48');

-- ── SEED: CATEGORIES ──────────────────────────────────────────
insert into categories (id, name, slug, description, icon, color) values
  ('c1000000-0000-0000-0000-000000000001', 'Technology', 'technology', 'Exploring the frontiers of digital innovation and AI', '💻', '#3b82f6'),
  ('c1000000-0000-0000-0000-000000000002', 'Culture', 'culture', 'Art, cinema, literature, and the human experience', '🎭', '#8b5cf6'),
  ('c1000000-0000-0000-0000-000000000003', 'Science', 'science', 'Discoveries shaping our understanding of the world', '🔬', '#06b6d4'),
  ('c1000000-0000-0000-0000-000000000004', 'Environment', 'environment', 'Climate, sustainability, and the future of our planet', '🌍', '#22c55e'),
  ('c1000000-0000-0000-0000-000000000005', 'Politics', 'politics', 'Analysis of power, policy, and governance', '⚖️', '#ef4444'),
  ('c1000000-0000-0000-0000-000000000006', 'Arts', 'arts', 'Creativity, design, and visual expression', '🎨', '#f59e0b');

-- ── SEED: TAGS ────────────────────────────────────────────────
insert into tags (name, slug) values
  ('artificial intelligence', 'artificial-intelligence'),
  ('climate change', 'climate-change'),
  ('startups', 'startups'),
  ('books', 'books'),
  ('film', 'film'),
  ('policy', 'policy'),
  ('renewable energy', 'renewable-energy'),
  ('genetics', 'genetics'),
  ('opinion', 'opinion'),
  ('deep dive', 'deep-dive');

-- ── SEED: ARTICLES ────────────────────────────────────────────
insert into articles (title, slug, excerpt, content, cover_image, author_id, category_id, status, featured, views_count, likes_count, claps_count, reading_time, tags) values

-- Article 1 (featured hero)
(
  'The Quiet Revolution: How AI Is Reshaping Indian Startups',
  'ai-reshaping-indian-startups',
  'From Bengaluru to Hyderabad, a new generation of founders is embedding AI not as a feature — but as the very foundation of their businesses. What does this mean for India''s startup decade?',
  '<p>Walk into any co-working space in Bengaluru today and you will hear the same word repeated like a mantra: <em>AI-first</em>. But unlike the buzzword cycles of the past — blockchain, metaverse, Web3 — this one feels different. The founders building here are not bolting AI onto existing products. They are designing entire businesses around it from day one.</p><h2>The Infrastructure Shift</h2><p>When Riya Desai co-founded her legal-tech startup in 2023, she made a decision that would have seemed reckless two years earlier: she hired no junior lawyers. Instead, her team of eight engineers built a document analysis system that could review contracts in seconds. Her first enterprise client was a Fortune 500 company that had previously employed twelve full-time contract reviewers.</p><blockquote>We are not replacing lawyers. We are replacing the parts of legal work that were never meant to be done by lawyers in the first place.</blockquote><p>This philosophy — automation of the mechanical to elevate the human — is becoming the defining ethos of India''s third startup wave. And it is happening faster than anyone predicted.</p><h2>The Funding Picture</h2><p>According to data from Tracxn, AI-native startups in India raised over $4.2 billion in 2024, a 340% increase from 2022. More significantly, the average seed round size has more than doubled — a sign that investors are willing to bet bigger, earlier, on teams with genuine technical depth.</p><p>But the money is only part of the story. The real revolution is in the talent pool. India now produces more machine learning engineers than any country except the United States. Many of them, having spent years at Google, Meta, and OpenAI, are returning home — not for lack of options abroad, but because they see something extraordinary happening here.</p><h2>What This Means for India</h2><p>The implications extend far beyond Silicon Valley envy. AI-native companies in agriculture, healthcare, and vernacular education are tackling problems that have resisted solutions for decades. A startup in Pune is using computer vision to detect crop diseases before they are visible to the naked eye. Another in Chennai is building diagnostic tools for rural health workers with no formal medical training.</p><p>This is not just India catching up to the West. It is India potentially leapfrogging it — building AI solutions for problems the West does not have, at a scale the West cannot imagine.</p>',
  'https://images.unsplash.com/photo-1485827404703-89b55fcc595e?w=1200&q=80',
  'a1000000-0000-0000-0000-000000000001',
  'c1000000-0000-0000-0000-000000000001',
  'published', true, 4821, 312, 589, 7,
  ARRAY['artificial intelligence', 'startups', 'deep dive']
),

-- Article 2
(
  'The Grammar of Silence: Reading Chitra Banerjee Divakaruni''s New Novel',
  'grammar-of-silence-divakaruni',
  'Her new novel arrives at a moment when Indian diaspora fiction is being asked harder questions than ever. Divakaruni''s answer is to go quieter, slower — and more devastating.',
  '<p>There is a particular kind of grief that does not announce itself. It does not tear through you like the grief of sudden loss. It settles. It becomes the wallpaper of your interior life, so familiar you stop seeing it. Chitra Banerjee Divakaruni''s new novel is about that grief — the grief of a life almost chosen, a self almost lived.</p><h2>The Story</h2><p>Set across three decades and two continents, the novel follows Malati, a classical dancer who emigrates from Kolkata to California in the 1990s. The novel''s architecture is deceptively simple: alternating chapters move between Malati''s past in India and her present in America, slowly revealing why she stopped dancing — and what it cost her.</p><p>Divakaruni''s prose has always been precise, but here it achieves something rarer: a luminous restraint. Entire emotional landscapes are conveyed through what characters do not say. A mother''s pride in her daughter''s art. A husband''s discomfort with her ambitions. The slow negotiation between love and self-erasure that Divakaruni renders with painful accuracy.</p><blockquote>She had learned early that the loudest things in a room are often the silences — the words swallowed before they could do damage, or be damaged.</blockquote><h2>The Diaspora Question</h2><p>Indian diaspora fiction is at an inflection point. After decades of novels about identity, belonging, and the hyphen between two cultures, readers and critics are asking: what comes after? Divakaruni''s answer, implicitly, is that the questions themselves were never about geography. They were always about power — who gets to define themselves, who must translate themselves for others'' comfort.</p><p>Malati''s dance is not simply a metaphor for cultural identity. It is a practice of radical presence — a way of insisting that her body, her art, her interiority matter on their own terms. When she stops, the novel asks: who took that from her? And how do you recover what was never exactly stolen, only slowly, consensually surrendered?</p>',
  'https://images.unsplash.com/photo-1481627834876-b7833e8f5570?w=1200&q=80',
  'a1000000-0000-0000-0000-000000000002',
  'c1000000-0000-0000-0000-000000000002',
  'published', true, 3241, 201, 445, 6,
  ARRAY['books', 'opinion', 'deep dive']
),

-- Article 3
(
  'India''s Solar Bet: Can Rajasthan Power the Subcontinent?',
  'india-solar-bet-rajasthan',
  'The Thar Desert has become the unlikely centrepiece of India''s most ambitious energy transition. But the distance between government targets and ground reality remains vast.',
  '<p>From the air, the Bhadla Solar Park looks like a mistake — a vast dark rectangle dropped into the pale geometry of the Thar Desert. Up close, it is more unsettling and more beautiful: 10,000 hectares of photovoltaic panels tilted toward the sun in perfect mathematical rows, generating enough electricity to power a small country.</p><p>This is where India''s energy future is being written — and where its contradictions are most visible.</p><h2>The Target</h2><p>India has committed to 500 gigawatts of renewable energy capacity by 2030, of which solar will account for 300 GW. As of early 2025, installed capacity stands at roughly 90 GW — impressive growth, but less than a third of the target with five years remaining.</p><p>The arithmetic of what remains is staggering. India would need to add, on average, more than 40 GW of solar capacity per year — roughly the total installed capacity of a country like Spain — every year until 2030.</p><h2>The Infrastructure Gap</h2><p>The challenge is not simply one of building panels. Every gigawatt of solar generation requires transmission lines to carry power to cities, storage systems to manage the intermittency of sunlight, and grid infrastructure to balance supply and demand across a subcontinent-scale network.</p><blockquote>We are building the plane while flying it. The grid was designed for coal. Retrofitting it for distributed renewable generation is an engineering problem of extraordinary complexity.</blockquote><p>The person speaking is a senior engineer at Power Grid Corporation of India, who asked not to be named. Her frustration is palpable — and widely shared among professionals who understand both the ambition and the constraints.</p>',
  'https://images.unsplash.com/photo-1509391366360-2e959784a276?w=1200&q=80',
  'a1000000-0000-0000-0000-000000000003',
  'c1000000-0000-0000-0000-000000000004',
  'published', true, 5103, 289, 612, 8,
  ARRAY['climate change', 'renewable energy', 'policy']
),

-- Article 4
(
  'What CRISPR Can and Cannot Fix: A Molecular Biologist Explains',
  'crispr-what-it-can-cannot-fix',
  'Gene editing has moved from science fiction to clinical reality in under a decade. But the gap between what CRISPR can do in the lab and what it can do for patients remains enormous.',
  '<p>In December 2023, the FDA approved the first CRISPR-based therapy for sickle cell disease. It was a milestone that scientists had been working toward for more than a decade — and a moment that the popular press treated as the beginning of a gene-editing revolution.</p><p>The reality, as with most scientific revolutions, is considerably more complicated.</p><h2>What CRISPR Actually Does</h2><p>CRISPR-Cas9 is, at its most basic, a molecular scissors system borrowed from bacteria. Bacteria use it to cut apart the DNA of invading viruses. Scientists have repurposed it to cut specific sequences of DNA in any organism, including humans.</p><p>The precision is genuinely remarkable. A CRISPR guide RNA can find and cut a specific sequence of twenty base pairs among the three billion base pairs in the human genome. That is roughly equivalent to finding and removing a single sentence from a library of ten thousand books.</p><blockquote>The precision is real. What is also real is that cutting is the easy part. What happens after the cut — how the cell repairs itself, what errors creep in — that is where most of the complexity lives.</blockquote><h2>The Delivery Problem</h2><p>Getting CRISPR into the right cells in the right tissue in a living human being remains the central unsolved problem of the field. The sickle cell therapy works by removing a patient''s own blood stem cells, editing them outside the body, and reinfusing them. This is enormously expensive, available at only a handful of specialised centres, and not applicable to diseases where the target tissue cannot be removed and reinfused.</p><p>For diseases of the brain, heart, or liver — organs that cannot simply be taken out, edited, and returned — the delivery challenge is far harder.</p>',
  'https://images.unsplash.com/photo-1559757148-5c350d0d3c56?w=1200&q=80',
  'a1000000-0000-0000-0000-000000000004',
  'c1000000-0000-0000-0000-000000000003',
  'published', true, 2987, 178, 334, 7,
  ARRAY['genetics', 'deep dive']
),

-- Article 5
(
  'The Attention Economy''s Next Frontier: Inside India''s Creator Wars',
  'india-creator-wars-attention-economy',
  'YouTube, Instagram, and now a dozen homegrown platforms are competing for the time of 800 million Indian internet users. For creators, the gold rush has a dark side.',
  '<p>Tanmay Singh makes videos about personal finance for an audience that has never seen a financial advisor. His 4.3 million subscribers are mostly first-generation earners — young Indians who grew up in households where money was not discussed openly and investment was something that happened to other people.</p><p>He posts three times a week, works fourteen-hour days, and earns more than he ever did as a chartered accountant. He is also, he admits, exhausted in ways that no amount of sleep seems to fix.</p><h2>The Creator Trap</h2><p>The Indian creator economy is estimated at $30 billion and growing at 25% annually. But the distribution of that wealth is, like most economies, profoundly unequal. The top 1% of creators capture roughly 60% of total revenue. The vast middle — creators with between 10,000 and 500,000 followers — typically earn between ₹20,000 and ₹2,00,000 per month, often with no stability, no benefits, and no separation between self and brand.</p><blockquote>My audience does not follow a channel. They follow me. Which means I can never be sick. I can never be boring. I can never have a bad day in public. That is not sustainable, but I do not know how to stop.</blockquote>',
  'https://images.unsplash.com/photo-1611162617213-7d7a39e9b1d7?w=1200&q=80',
  'a1000000-0000-0000-0000-000000000001',
  'c1000000-0000-0000-0000-000000000002',
  'published', false, 3756, 234, 401, 6,
  ARRAY['opinion', 'deep dive']
),

-- Article 6
(
  'Monsoon Politics: How Water Is Becoming India''s Most Contested Resource',
  'monsoon-politics-water-india',
  'Inter-state river disputes have existed for decades. But as groundwater depletes and rainfall patterns shift, water conflicts are moving from courtrooms to streets.',
  '<p>The Cauvery river has been disputed for over a century. The Mahadayi has been in litigation for decades. The Krishna, the Godavari, the Narmada — India''s great rivers are also its great arguments, contested between states, between farmers and cities, between present needs and future survival.</p><p>Water scarcity is not new to India. What is new is its geography. Regions that were once reliably wet are experiencing multi-year droughts. The Indo-Gangetic Plain, which feeds a third of the country, is depleting its groundwater at rates that scientists describe as a slow-motion catastrophe.</p><h2>The Numbers</h2><p>India has approximately 4% of the world''s freshwater resources but 18% of its population. Per capita water availability has fallen by nearly 70% since 1951. By 2030, according to NITI Aayog projections, demand will exceed supply by a factor of two.</p><p>These numbers are abstract until they are not. In the summer of 2024, Chennai''s reservoirs fell to 0.3% capacity. Farmers in Marathwada watched their bore wells fail for the third consecutive year. In Delhi, tanker mafias controlled access to water in neighborhoods where pipes ran dry for sixteen hours a day.</p>',
  'https://images.unsplash.com/photo-1516912481808-3406841bd33c?w=1200&q=80',
  'a1000000-0000-0000-0000-000000000003',
  'c1000000-0000-0000-0000-000000000004',
  'published', false, 2134, 156, 267, 6,
  ARRAY['climate change', 'policy']
),

-- Article 7 (draft - can be deleted later)
(
  'DRAFT: The Rise of Vernacular Internet in India',
  'draft-vernacular-internet-india',
  'As 4G penetration reaches tier-3 cities, the next billion Indian internet users will engage primarily in languages other than English. What does this mean for the web?',
  '<p>This is a draft article. You can edit or delete it from the admin panel.</p><p>The story of India''s internet has largely been told in English — by English-speaking journalists, about English-speaking startups, for English-speaking investors. But the actual internet of India, the one that 700 million people use daily, is increasingly vernacular.</p><p>More content is consumed in Hindi, Tamil, Telugu, Kannada, and Marathi than in English. More searches happen in regional languages. More commerce is conducted via voice, in mother tongues.</p>',
  'https://images.unsplash.com/photo-1551650975-87deedd944c3?w=1200&q=80',
  'a1000000-0000-0000-0000-000000000001',
  'c1000000-0000-0000-0000-000000000001',
  'draft', false, 0, 0, 0, 4,
  ARRAY['opinion']
);

-- ── SEED: SUBMISSIONS ─────────────────────────────────────────
insert into submissions (title, content, author_name, author_email, status, tags) values
(
  'Why Indian Classical Music Deserves a Streaming Revolution',
  '<p>Carnatic and Hindustani music are among the most sophisticated musical traditions on earth. Yet they remain trapped in a distribution model that has not changed since the 1980s.</p><p>Streaming has transformed Western pop, hip-hop, jazz, and even classical music. But Indian classical music sits in a strange liminal space — too niche for the major platforms to curate well, too vast and complex for casual discovery.</p><p>What would a streaming platform built specifically for Indian classical music look like? And who would build it?</p>',
  'Meera Krishnaswamy',
  'meera.k@gmail.com',
  'pending',
  ARRAY['opinion', 'arts']
),
(
  'The Untold Story of India''s Women Coders',
  '<p>India produces more female engineering graduates than almost any country in the world. Yet women remain dramatically underrepresented in the country''s tech leadership.</p><p>This is not a pipeline problem. It is a culture problem. And it is one that the industry has been reluctant to examine honestly.</p>',
  'Anjali Bose',
  'anjali.bose@outlook.com',
  'pending',
  ARRAY['opinion', 'deep dive']
),
(
  'A Week Without My Smartphone: What I Learned',
  '<p>I am a technology journalist. I have written about digital addiction, attention fragmentation, and the psychological costs of always-on connectivity for years. I have never actually tried to disconnect.</p><p>Last month, I did. For seven days, I put my smartphone in a drawer and used only a basic feature phone for calls. Here is what happened.</p>',
  'Vikram Rao',
  'vikram.rao@proton.me',
  'approved',
  ARRAY['opinion']
);

-- ── SEED: ACHIEVEMENTS ────────────────────────────────────────
insert into achievements (title, description, icon, color) values
  ('100 Stories Published', 'A century of thoughtful, in-depth journalism and cultural commentary.', '🏆', '#c8973a'),
  ('500,000 Readers', 'Half a million people have read our work. Thank you.', '🌟', '#3b82f6'),
  ('Best Editorial Platform 2024', 'Recognised by the Digital Media Alliance for editorial excellence.', '🥇', '#22c55e'),
  ('10 Countries Reached', 'Our stories have found readers across ten countries on three continents.', '🌍', '#8b5cf6'),
  ('Community Choice Award', 'Voted best independent editorial platform by our readers.', '❤️', '#ef4444');

-- ── SEED: ANNOUNCEMENTS ───────────────────────────────────────
insert into announcements (message, active, link, link_text) values
  ('🎉 Context Corner is now live! Share your story with the world — no account needed.', true, '/write', 'Start Writing'),
  ('📚 We are now accepting long-form essays and investigative pieces. Up to 5,000 words.', false, '/write', 'Submit now');

-- ── SEED: SETTINGS ────────────────────────────────────────────
insert into settings (key, value) values
  ('site_description', 'A premium editorial platform for thoughtful perspectives, deep-dives, and cultural commentary from South Asia and beyond.'),
  ('help_email', 'hello@contextcorner.in'),
  ('terms', '<h2>Terms of Service</h2><p><em>Last updated: January 2025</em></p><h3>1. Acceptance of Terms</h3><p>By accessing or using Context Corner, you agree to be bound by these Terms of Service and all applicable laws. If you do not agree with any of these terms, please do not use the platform.</p><h3>2. Content Submission</h3><p>When you submit content to Context Corner, you grant us a non-exclusive, worldwide, royalty-free licence to publish, display, and distribute your content across our platform and promotional materials. You retain ownership of your work.</p><h3>3. Editorial Standards</h3><p>All submissions are reviewed by our editorial team. We may edit for clarity, grammar, length, or compliance with our guidelines. We reserve the right to decline any submission without explanation.</p><h3>4. Prohibited Content</h3><p>You may not submit content that: infringes intellectual property rights; contains defamatory or false statements; promotes illegal activities; constitutes harassment, hate speech, or targeted abuse; or violates any applicable laws or regulations.</p><h3>5. Intellectual Property</h3><p>The Context Corner name, logo, and original platform content are protected by applicable intellectual property laws. You may not reproduce or distribute our proprietary materials without prior written consent.</p><h3>6. Privacy</h3><p>We collect minimal personal information. Submitted email addresses are used only for editorial correspondence and are not shared with third parties or used for marketing without explicit consent.</p><h3>7. Limitation of Liability</h3><p>Context Corner is provided in good faith but without warranties of any kind. We are not liable for any indirect or consequential damages arising from use of the platform.</p><h3>8. Changes to Terms</h3><p>We reserve the right to modify these terms at any time. Continued use of the platform after changes constitutes acceptance of the updated terms.</p><h3>9. Contact</h3><p>For questions about these Terms, please contact us at hello@contextcorner.in</p>');

-- ── ENABLE REALTIME ───────────────────────────────────────────
alter publication supabase_realtime add table articles;
alter publication supabase_realtime add table submissions;
alter publication supabase_realtime add table announcements;
alter publication supabase_realtime add table reactions;

-- ── ROW LEVEL SECURITY ────────────────────────────────────────
alter table articles enable row level security;
alter table authors enable row level security;
alter table categories enable row level security;
alter table tags enable row level security;
alter table submissions enable row level security;
alter table reactions enable row level security;
alter table achievements enable row level security;
alter table announcements enable row level security;
alter table settings enable row level security;
alter table admin enable row level security;

-- Allow all operations via anon key (admin validates credentials in app)
create policy "Allow all" on articles for all using (true) with check (true);
create policy "Allow all" on authors for all using (true) with check (true);
create policy "Allow all" on categories for all using (true) with check (true);
create policy "Allow all" on tags for all using (true) with check (true);
create policy "Allow all" on submissions for all using (true) with check (true);
create policy "Allow all" on reactions for all using (true) with check (true);
create policy "Allow all" on achievements for all using (true) with check (true);
create policy "Allow all" on announcements for all using (true) with check (true);
create policy "Allow all" on settings for all using (true) with check (true);
create policy "Allow select" on admin for select using (true);

-- ── DONE ──────────────────────────────────────────────────────
-- Verify: select count(*) from articles;  -- should return 7
-- Verify: select * from admin;            -- should show Manmada
