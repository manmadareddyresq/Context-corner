'use client'

import { useState, useEffect, useRef, useCallback } from 'react'
import { motion } from 'framer-motion'
import Link from 'next/link'
import { supabase } from '@/lib/supabase'
import type { Article } from '@/lib/supabase'

interface SearchProps {
  onClose: () => void
}

export default function Search({ onClose }: SearchProps) {
  const [query, setQuery] = useState('')
  const [results, setResults] = useState<Article[]>([])
  const [loading, setLoading] = useState(false)
  const inputRef = useRef<HTMLInputElement>(null)
  const timeoutRef = useRef<ReturnType<typeof setTimeout>>()

  useEffect(() => {
    setTimeout(() => inputRef.current?.focus(), 50)
    document.body.style.overflow = 'hidden'
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose() }
    window.addEventListener('keydown', onKey)
    return () => {
      window.removeEventListener('keydown', onKey)
      document.body.style.overflow = ''
    }
  }, [onClose])

  const search = useCallback(async (q: string) => {
    if (!q.trim()) { setResults([]); return }
    setLoading(true)
    try {
      const { data } = await supabase
        .from('articles')
        .select('*, authors(name, avatar_url), categories(name, slug)')
        .eq('status', 'published')
        .or(`title.ilike.%${q}%,excerpt.ilike.%${q}%`)
        .limit(8)
      setResults(data || [])
    } catch { setResults([]) }
    finally { setLoading(false) }
  }, [])

  useEffect(() => {
    clearTimeout(timeoutRef.current)
    timeoutRef.current = setTimeout(() => search(query), 250)
    return () => clearTimeout(timeoutRef.current)
  }, [query, search])

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[100] flex items-start justify-center pt-[10vh] px-4"
      style={{ background: 'rgba(15,14,13,0.88)', backdropFilter: 'blur(14px)' }}
      onClick={e => { if (e.target === e.currentTarget) onClose() }}
    >
      <motion.div
        initial={{ opacity: 0, y: -20, scale: 0.97 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, y: -20, scale: 0.97 }}
        transition={{ duration: 0.22 }}
        className="w-full max-w-2xl rounded-2xl overflow-hidden shadow-2xl"
        style={{ background: 'var(--cream)' }}
      >
        {/* Input row */}
        <div className="flex items-center gap-3 px-5 py-4 border-b border-ink-100">
          <svg className="w-5 h-5 text-ink-400 flex-shrink-0" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
            <circle cx="11" cy="11" r="8" /><path d="m21 21-4.35-4.35" strokeLinecap="round" />
          </svg>
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={e => setQuery(e.target.value)}
            placeholder="Search articles, topics, authors…"
            className="flex-1 bg-transparent font-sans text-base text-ink-900 placeholder-ink-300 focus:outline-none"
          />
          {loading && <div className="w-4 h-4 rounded-full border-2 border-amber border-t-transparent animate-spin flex-shrink-0" />}
          <kbd onClick={onClose}
            className="hidden sm:flex items-center gap-0.5 px-2 py-1 rounded border border-ink-200 text-xs font-mono text-ink-400 cursor-pointer hover:border-ink-400 transition-colors">
            ESC
          </kbd>
        </div>

        {/* Results */}
        <div className="max-h-[60vh] overflow-y-auto">
          {query && results.length === 0 && !loading && (
            <div className="px-5 py-12 text-center">
              <p className="text-4xl mb-3">🔍</p>
              <p className="text-ink-500 font-sans text-sm">No results for <strong className="text-ink-700">"{query}"</strong></p>
              <p className="text-ink-400 font-sans text-xs mt-1">Try different keywords</p>
            </div>
          )}

          {results.length > 0 && (
            <div className="py-2">
              <p className="px-5 py-2 text-xs font-mono text-ink-400 uppercase tracking-wider">
                {results.length} result{results.length !== 1 ? 's' : ''}
              </p>
              {results.map((article, i) => (
                <motion.div key={article.id}
                  initial={{ opacity: 0, x: -8 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.04 }}>
                  <Link href={`/article/${article.slug}`} onClick={onClose}
                    className="flex items-center gap-4 px-5 py-3 hover:bg-parchment transition-colors group">
                    <div className="w-16 h-12 rounded-lg overflow-hidden flex-shrink-0 bg-ink-100">
                      {article.cover_image
                        ? <img src={article.cover_image} alt={article.title} className="w-full h-full object-cover" />
                        : <div className="w-full h-full flex items-center justify-center text-2xl bg-parchment">📄</div>
                      }
                    </div>
                    <div className="flex-1 min-w-0">
                      {(article as any).categories && (
                        <p className="text-xs font-mono text-amber mb-0.5">{(article as any).categories.name}</p>
                      )}
                      <p className="font-serif font-semibold text-sm text-ink-900 group-hover:text-amber transition-colors truncate">{article.title}</p>
                      <p className="text-xs text-ink-400 mt-0.5">
                        {(article as any).authors?.name && <span>{(article as any).authors.name} · </span>}
                        {article.reading_time} min read
                      </p>
                    </div>
                    <svg className="w-4 h-4 text-ink-300 group-hover:text-amber transition-colors flex-shrink-0" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
                      <path d="M9 18l6-6-6-6" strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                  </Link>
                </motion.div>
              ))}
            </div>
          )}

          {!query && (
            <div className="px-5 py-10 text-center">
              <p className="text-ink-200 font-mono text-xs uppercase tracking-wider mb-2">Search Context Corner</p>
              <p className="text-ink-400 font-sans text-sm">Type anything to discover articles</p>
            </div>
          )}
        </div>
      </motion.div>
    </motion.div>
  )
}
